<?php
// exit("___");
phpinfo();
exit;

	header("Location:http://thienanhminh-vpls.blogspot.com") ;
	exit() ;
?>