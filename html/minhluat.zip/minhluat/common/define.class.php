<?php
/*--------------------------------------------------------
@Author : Nguyen Dang Hien
@Description : define some constrant
@Date   : 2012/07/17
@Copyright by DAHI
--------------------------------------------------------*/
define("ADODB_DNS", "mysql:dbname=minhluat_db;host=localhost") ;
define("ADODB_USER", "minhluat_user") ;
define("ADODB_PASS", "ufy76hg%62#jsdGHds") ;

define("CONFIG_CLASS", "libs/config/config.class.php") ;
define("MD5_CLASS", "libs/md5/md5.class.php") ;
define("TEMPLATE_CLASS", "libs/xtemplate/xtemplate.class.php") ;
define("MVC_CLASS", "libs/mvc/mvc.class.php") ;
define("COMMON_CLASS", "common/common.class.php") ;
define("JS_PATH", "js") ;
define("SESSION_CLASS", "libs/session/session.class.php") ;
define("LOGIN_CLASS", "common/login.class.php") ;
define("UPLOAD_CLASS", "libs/upload/upload.class.php") ;
define("IMAGE_CLASS", "libs/image/image.class.php") ;
define("LOG_CLASS", "libs/log/log.class.php") ;
define("LIBS", "libs") ;
define("COMMON", "common") ;
define("CONFIG", "config") ;
define("TPL", ".tpl") ;
define("XTPL", ".xtpl") ;
define("XTPL", ".xtpl") ;
define("CLIENT", "modules/client/") ;
define("CLIENT_HEADER", "modules/client/common/header.xtpl") ;
define("CLIENT_FOOTER", "modules/client/common/footer.xtpl") ;
define("CLIENT_LEFT", "modules/client/common/left.xtpl") ;
define("CLIENT_RIGHT", "modules/client/common/right.xtpl") ;
define("ADMIN_HEADER", "modules/sogun/common/header.xtpl") ;
define("ADMIN_FOOTER", "modules/sogun/common/footer.xtpl") ;
define("ADMIN_MENU", "modules/sogun/common/menu.xtpl") ;
define("LINK_HEADER", "modules/client/common/") ;
define("UPLOAD_DIR", "compiler/upload/") ;
define("UPLOAD_LOG_DIR", "compiler/log/upload/") ;
define("MAX_IMAGES_SIZE", 1024*768*3 ) ;
define("MAX_VIDEO_SIZE", 1024*1024*4 ) ;
define("IMAGES_WIDTH_NEWS", 300);
define("IMAGES_SANPHAM_FOLDER", "compiler/upload/products/" ) ;
define("IMAGES_SANPHAMFLASH_FOLDER", "compiler/upload/products_flash/" ) ;
define("BANNER_TOP", "images/flash/banner.swf" ) ;
define("BANNER_CENTER", "images/flash/banner_center.swf" ) ;

define("ADMIN", "modules/admin/") ;
define("SOGUN", "modules/sogun/") ;

define("PAGING_PAGE", 3) ;
define("PAGING_ROW", 4) ;

define("KEY_ADMIN", "adminmllogin");
define("KEY_CLIENT", "usermllogin");
define("DOCUMENT_ROOT", "http://minhluat.net");
//define("DOCUMENT_ROOT", "http://localhost/minhluat");
define("DOMAIN_ROOT", "minhluat.net");
define("TITLE_SITE_DEFAULT", "MINH LUAT");

define("MAILADMINACC", "support@minhluat.net");
define("MAILADMINPASS", "g4;NWG#MHJic");

?>