<?php
/*
@Author : Nguyen Dang Hien
@Class  : common.class.php
@Description : all usefull function
*/

class commonClass {				
	//variable
	private $strcat, $allList, $strcat1 ;
	
	//construct and destruct
	public function __construct() {		
		$this->strcat = "" ;
		$this->strcat1 = "" ;
		$this->allList = array() ;
	}
	
	public function __destruct() {		
		unset( $this->strcat ) ;
		unset( $this->strcat1 ) ;
		unset( $this->allList ) ;
	}
	
	public function __toString() {
		return get_class(__CLASS__) ;
	}
	
	public function __wakeup()
	{
  		$class = get_class($this);
  		new $class;
	}	
	function cutnchar($str,$n){
		if(strlen($str)<$n) return $str;
		$html    = substr($str,0,$n);
		$html    = substr($html,0,strrpos($html,' '));
		return $html.'...';
	}
	public function Url_sid($s,$mod_rewrite = 0 ) 
	{ 
		$urlin = array(
		"'(?<!/)index.php'",
		"'(?<!/)\?gfx=gfx&random_num=([0-9]*)'",
		"'(?<!/)main.html\?mod=([a-zA-Z]*)'",
		"'(?<!/)&go=([a-zA-Z]*)'",
		"'(?<!/)&page=([0-9]*)'"
		);
		$urlout = array(
		"main.html",
		",hash-\\1",
		"\\1.html",
		",\\1",
		",p\\1"
		);
		if($mod_rewrite == 1) {
		$s = preg_replace($urlin, $urlout, $s); 
		}
		return $s; 
	}
	//CHECK HTML CATEGORY FILE
	private function isHTMLCat($file ) {		
		if( file_exists( $file ) ){
			return true ;
		}		
		return false ;
	}
	public function convdate($str,$type="/"){
		if($type=="-")
			$ar = explode("-",$str) ;
		elseif($type=="/")
			$ar = explode("/",$str) ;
		return mktime(0, 0, 0, intval($ar[1]),intval($ar[0]), intval($ar[2]));
	}	
	public function allLoaiSanPhamSelect (&$connect, &$md5Class, $nccid=0)						
	{						 
			$file = "compiler/cache/html/loaisp/options_loaisp_s".$nccid.".db" ;
			$options = "" ;		
			if( $this->isHTMLCat( $file ) ) {
			$options = @file_get_contents( $file ) ;			
			}
			else {			
			$SQL="SELECT A.loaisp_id, B.loaisp_ten 
					FROM ml_loai_sanpham A, ml_loai_sanpham_des B  
					WHERE A.loaisp_id = B.loaisp_id 
					ORDER BY A.loaisp_thutu ASC";
			$stmt = $connect->prepare( $SQL );
			$stmt->execute( array());			
			if ( $stmt ) {	
				$allList = $stmt->fetchAll();												
				if( count( $allList ) > 0 ){
					foreach( $allList as $k => $v ){						
						if($nccid==$v['loaisp_id']){
							 $slt=" selected=\"selected\""	;
							
							 
						}else $slt=""	;
						$options .="<option $slt ";												
						$options .=" value=\"".
										$md5Class->encodeStatic( $v["loaisp_id"] ) .
										"\" >";								
						$options .= $v["loaisp_ten"];
						$options .= "</option>";	
					}			
				}	
			}										
			//WRITE FILE
			if( !empty( $options ) ) {
				@file_put_contents( $file, $options ) ;
			}			
			}
			return $options ;		
		}
	//KIEU TIEN
	public function money($number,$ex=1,$de=',',$co='.')
	{
		global $money_de, $money_co;
		if(round($number) != $number)
			$ex = 1;
		else $ex = 0;
		return number_format($number, $ex, $de, $co);
	}
	// LAY CHUOI NGAY THEO DINH DANG
	public function myday($number,$sf='')
	{		
		if($sf=='')
		$sf="d-m-Y";
		if ($this->isInt($number))
			return date($sf,$number);
		else 
			return $number;
	}
	//reload pages
	public function reload($url='http://minhluat.net',  $delay=0)	  
	{
		echo "<META HTTP-EQUIV=\"refresh\" content=\"$delay;URL=".$url."\">";
		exit;
	}
	//feed back
	public function feed_back($content)
	{
		echo "<br><span style=\"color:blue;font-weight:bold;text-decoration:underline\">Lưu Ý:</span><div style='color:red;padding-left:50px;'>";
		if(is_array($content)){
			$idx = 1;
			foreach ($content as $acomment){
				echo "<br>$idx. ".$acomment;
				$idx++;
			}
		}else echo $content;
		echo "</div>";
		
	}
	public function isInt($value) 
	{
		return 1 === preg_match('/^[+-]?[0-9]+$/', $value);
	}	
	// xem hinh
	public function showIMG($url,$w=90,$h=90)
	{

		if(!file_exists($url))
		return false;		
		$extimg="jpg,jpe,peg,fif,png,gif,bmp";
		if(stristr($extimg, substr($url,-3,3))){
			$h=empty($h) ? "" : ' height="'.$h.'"';
			$w=empty($w) ? "" : ' width="'.$w.'"';
			$img='<img src="http://thegioivoxe.com/'.$url.'" '.$w. $h .' border="0" />';
		}
		$extvideo="swf,wmv,wav";
		if(stristr($extvideo, substr($url,-3,3))){
			$img='<embed name="flash"  src="http://thegioivoxe.com/'. $url.'" quality="high" bgcolor="#96BCE3" z-index="0" '
			.'wmode="transparent" width="'.$w.'" height="'.$h.'" type="application/x-shockwave-'
			.'flash" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?'
			.'P1_Prod_Version=ShockwaveFlash"></embed>';
		}
		//file flash movie
		if(substr($url,-3,3)=="flv"){
			$img='<embed src="flvplayer.swf" z-index="0" wmode="transparent"  type="application/x-shockwave-flash" flashvars="file='
			. $url.'&image=images/waitting.gif;location=flvplayer.swf&amp;autostart=false" '
			.'allowfullscreen="true" height="'.$h.'" width="'.$w.'"></embed>';		
		}
		return $img;
	}
	//kiem tra chuoi co1 phai la email ko
	public	function check_isemail($str)
	{
		if (empty($str) || !is_string($str)) return FALSE;
		if (eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)+$", $str)) return TRUE;
		else return FALSE;
	}	
	// kiem tra số diện thoại
	public function check_isphone($str){
		if(ereg("^([ \t\.0-9-]{6,15})$",$str)){
			return 1;
			} else {
			return 0;
		}
	}
	//kiem tra file
	public function upload_exit($filename="file", $extfile="jpg,jpe,peg,fif,png,gif,bmp")								
	{
		$fn=$_FILES[$filename]["name"];	
		if((strlen($fn)<4 || stristr($extfile, substr($_FILES[$filename]["name"],-3,3)))=="") 
			return "Tên quá ngắn hoặc trùng file.";
		else return "";
	}
	public function delcache($dir="compiler/cache/html/tuyenxe")
	{
		if ($handle = opendir($dir)) {
				while (false !== ($file = readdir($handle))) {
					if(strlen($file)>4 && file_exists($dir.'/'.$file)){
						chmod($dir.'/'.$file,0777);
						unlink($dir.'/'.$file);
					}				
			}
		}
	}
	public function FixQuotes ($what = "") 
	{
		$what = ereg_replace("'","''",$what);
		while (eregi("\\\\'", $what)) {
			$what = ereg_replace("\\\\'","'",$what);
		}
		return $what;	
	}
	
	//lay quang cao 
	public function getQuangCao(&$connect, $pos, $module)
	{
		$SQL = "SELECT qc_ten, qc_hinh, qc_link, qc_batdau, qc_thoigian, qc_module FROM `quangcao` WHERE qc_vitri = $pos AND qc_active = 1 AND qc_module = '$module' ORDER BY qc_thutu ASC "; 					        
		$stmt = $connect->prepare($SQL);
		$stmt->execute();
		$row = $stmt->fetchall();
		return $row;
	}
	//lay thong tin cua cong ty
	public function getThongtin(&$connect, $chuoi)
	{
		$SQL = "SELECT $chuoi as obj  FROM thongtinchung  WHERE id = 1 LIMIT 1"; 
		$stmt = $connect->prepare($SQL);
		$stmt->execute();
		list($obj)=$stmt->fetch();
		return $obj;
	}	
		
	// send email
	function send_mail( $to, $subject, $message, $headers = '' ) 
	{
		global $phpmailer,$datafold;
		// (Re)create it, if it's gone missing
		if (file_exists("includes/class-phpmailer.php")) {
			include_once ("includes/class-phpmailer.php");
		}
		if (file_exists("includes/class-smtp.php")) {
			include_once ("includes/class-smtp.php");
		}
		$phpmailer = new PHPMailer();
		//Headers
		if ( empty( $headers )){
			$headers = array();
		} elseif ( !is_array( $headers )){
			// Explode the headers out, so this function can take both
			// string headers and an array of headers.
			$tempheaders = (array) explode( "\n", $headers );
			$headers = array();
			// If it's actually got contents
			if ( !empty( $tempheaders ) ) {
				// Iterate through the raw headers
				foreach ( $tempheaders as $header ) {
					if ( strpos($header, ':') === false )
						continue;
					// Explode them out
					list( $name, $content ) = explode( ':', trim( $header ), 2 );
	
					// Cleanup crew
					$name = trim( $name );
					$content = trim( $content );
	
					// Mainly for legacy -- process a From: header if it's there
					if ( 'from' == strtolower($name) ) {
						if ( strpos($content, '<' ) !== false ) {
							// So... making my life hard again?
							$from_name = substr( $content, 0, strpos( $content, '<' ) - 1 );
							$from_name = str_replace( '"', '', $from_name );
							$from_name = trim( $from_name );
	
							$from_email = substr( $content, strpos( $content, '<' ) + 1 );
							$from_email = str_replace( '>', '', $from_email );
							$from_email = trim( $from_email);
						} else {
							$from_name = trim( $content );
						}
					} elseif ( 'content-type' == strtolower($name) ) {
						if ( strpos( $content,';' ) !== false ) {
							list( $type, $charset ) = explode( ';', $content );
							$content_type = trim( $type );
							$charset = trim( str_replace( array( 'charset=', '"' ), '', $charset ) );
						} else {
							$content_type = trim( $content );
						}
					} else {
						// Add it to our grand headers array
						$headers[trim( $name )] = trim( $content );
					}
				}
			}
		}
	
		// Empty out the values that may be set
		$phpmailer->ClearAddresses();
		$phpmailer->ClearAllRecipients();
		$phpmailer->ClearAttachments();
		$phpmailer->ClearBCCs();
		$phpmailer->ClearCCs();
		$phpmailer->ClearCustomHeaders();
		$phpmailer->ClearReplyTos();
	
		// From email and name
		// If we don't have a name from the input headers
		if ( !isset( $from_name ) ) {
			$from_name = 'Minh Luat';
		}
	
		// If we don't have an email from the input headers
		if ( !isset( $from_email ) ) {
			// Get the site domain and get rid of www.
			$sitename = strtolower( $_SERVER['SERVER_NAME'] );
			if ( substr( $sitename, 0, 4 ) == 'www.' ) {
				$sitename = substr( $sitename, 4 );
			}
			$from_email = 'support@' . $sitename;
		}
	
		//Set email admin
		$phpmailer->Username = MAILADMINACC;
		// $phpmailer->Username = 'support@minhluat.net';
		$phpmailer->Password = MAILADMINPASS;
		// $phpmailer->Password = 'g4;NWG#MHJic';
	
		// Set the from name and email
		$phpmailer->From =  $from_email;
		$phpmailer->FromName = $from_name;
	
		// Set destination address
		$phpmailer->AddAddress( $to );
	
		// Set cc destination address
		$phpmailer->AddCC( 'danghienkhtn@yahoo.com','Dang Hien' );
		$phpmailer->AddCC( 'thienanhminh.vpls@gmail.com','Thien Anh Minh' );
	
		// Set mail's subject and body
		$phpmailer->Subject = $subject;
		$phpmailer->Body = $message;
	
		// Set to use PHP's mail()
		// $phpmailer->IsMail();
		
		// Set to use SMTP
		
		$phpmailer->IsSMTP();
	
		// Set Content-Type and charset
		// If we don't have a content-type from the input headers
		if ( !isset( $content_type ) ) {
			$content_type = 'text/plain';
		}
	
		$content_type =$content_type;
	
		// Set whether it's plaintext or not, depending on $content_type
		if ( $content_type == 'text/html' ) {
			$phpmailer->IsHTML( true );
		} else {
			$phpmailer->IsHTML( false );
		}	
		// Set the content-type and charset
		$phpmailer->CharSet = "UTF-8";
	
		// Set custom headers
		if ( !empty( $headers ) ) {
			foreach ( $headers as $name => $content ) {
				$phpmailer->AddCustomHeader( sprintf( '%1$s: %2$s', $name, $content ) );
			}
		}
	
	//	do_action_ref_array( 'phpmailer_init', array( &$phpmailer ) );
	
		// Send!
		$result = @$phpmailer->Send();
		return $result;
	}
		
//--------------------------------tinh so truy cap site -----------------------------------
	public function ThemLuotTruyCap($connect, $ip, $time, $lasttime)
	{		
		$SQL = "
				REPLACE INTO online( `ol_ip` , `ol_time` , `ol_lasttime` )
				VALUES( ?, ?, ? );				
			   ";
		$connect->beginTransaction();
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array( $ip, $time, $lasttime ) );  

		if ( !$stmt ) {				
			$connect->rollBack();			
			return false ;
		}
		$connect->commit();			
		return true ;
		
	}
	public function ThongTinTruyCap( &$connect,	  $vis_ip) 
	{		                                                
	    $oneList = 0 ;     
		$SQL = "
				SELECT * 
				FROM online 
				WHERE ol_ip= ?
				";		
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array($vis_ip) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetch();	   		
		}			
		return $oneList ;
	}
	//cap nhat lan truy cap cuoi
	public function CapNhatThongTinTruyCap($connect, $ip, $time)
	{				
		$SQL = "
				UPDATE `online` SET `ol_time` = '". time() ."', 
	`ol_lasttime` ='".$time."' WHERE ol_ip='".$ip."'				
			   ";
		$connect->beginTransaction();
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array() );  

		if ( !$stmt ) {				
			$connect->rollBack();			
			return false ;
		}
		$connect->commit();			
		return true ;
		
	}
	// Xoa cac lan truy cap truoc
	public function XoaThongTinTruyCap($connect, $tframe)
	{				
		$SQL = "DELETE FROM `online` WHERE ol_time <=".(time() - (2 * $tframe))			
			   ;
		$connect->beginTransaction();
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array() );  

		if ( !$stmt ) {				
			$connect->rollBack();			
			return false ;
		}
		$connect->commit();			
		return true ;
		
	}
	// LAY SO USER ONLINE
	public function DemSoOnline( &$connect ) 
	{
	    $SQL = "
				SELECT COUNT(ol_ip) 
				FROM online
			   ";	
	    $stmt = $connect->prepare( $SQL );
		$stmt->execute( array( ) );
		
		if ( $stmt ) {
		   	$kv_name = $stmt->fetchColumn();	   		
		   				   		
		   	if( $kv_name == FALSE ) {
		   		$kv_name = "" ;
		   	}
		}	
		
		return $kv_name ;
	}	
		
	public function allCategory( &$connect, $loai_id)
	{			 
		$file = "compiler/cache/html/loaisp/category_".$loai_id.".db" ;
		$options = '' ;		
		if( $this->isHTMLCat( $file ) ) {
		$options = @file_get_contents( $file ) ;			
		}
		else {	
			$SQL="SELECT A.*, B.* 
				  FROM ml_loai_sanpham A, ml_loai_sanpham_des B 
				  WHERE A.loaisp_id = B.loaisp_id 
				  AND lang_id = 1 "
				." ORDER BY loaisp_thutu ASC";			
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array());			
		if ( $stmt ) {
			$allList = $stmt->fetchAll();
											
			if( count( $allList ) > 0 ){						
				foreach( $allList as $k => $v ){
					$options .='<li><a href="'.DOCUMENT_ROOT.'/quanao/'.$v["loaisp_id"].'" class="mainlevel" ';												
					if($v["loaisp_id"] == $loai_id)
						$options .=' id="active_menu"';											
					$options .=' >'.$v["loaisp_ten"].'</a></li>';											
				}			
			}	
		}										
		//WRITE FILE
		if( !empty( $options ) ) {
			@file_put_contents( $file, $options ) ;
		}			
		}
		return $options ;		
	
	}        
	public function getListAdvertProduct( &$connect)
	{			 
//		$now = mktime();
//		$today = date("dmy",$now);
		$file = "compiler/cache/html/sanphamquangcao/listadvertproduct.tpl" ;
		$options = '' ;		
		if( $this->isHTMLCat( $file ) ) {
		$options = @file_get_contents( $file ) ;			
		}
		else {	
//			$yesterday = date("dmy",$now - 86400);
//			if(file_exists("compiler/cache/html/tintuc/listlatest_".$yesterday.".db")) unlink("compiler/cache/html/tintuc/listlatest_".$yesterday.".db");
			$SQL = "SELECT A.sp_id, B.sp_ten, A.sp_hinh, A.sp_donvi, A.sp_giaban, A.sp_giacu, A.sp_khuyenmai
					FROM `ml_sanpham` A, `ml_sanpham_des` B
					WHERE A.sp_id = B.sp_id
					AND sp_quangcao = 1
					AND (SELECT SUM(C.sp_soluong) FROM ml_sanpham_size C WHERE C.sp_id = A.sp_id) > 0
					ORDER BY A.sp_ngaydang DESC
					LIMIT 10;"; 					        			
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array());			
		if ( $stmt ) {
			$allList = $stmt->fetchAll();
											
			if( count( $allList ) > 0 ){						
				foreach( $allList as $k => $v ){
					$options .='<a href="'.DOCUMENT_ROOT.'/quanaoct/'.$v["sp_id"].'"';												
					$options .=' ><img border="0" width="140px" src="'.DOCUMENT_ROOT.'/'.$v["sp_hinh"].'"/>';
					$options .='<br /><strong>'.$v["sp_ten"].'</strong>';
					if($v["sp_khuyenmai"])
					{
						$options .='	<br/>
									Giá cũ: <del>'.$this->money($v["sp_giacu"]).'</del>&nbsp;VNĐ
									<br />
									Giá km: <strong style="font-size:12pt;">'.$v["sp_giaban"].'&nbsp;VNĐ</strong>'.$v["tin_tieude"].'</a>';								
					}
					else 
					{
						$options .= '<br />
									Giá bán: <strong>'.$this->money($v["sp_giaban"]).'&nbsp;VNĐ</strong></a>';
					}
				}			
			}	
		}										
		//WRITE FILE
		if( !empty( $options ) ) {
			@file_put_contents( $file, $options ) ;
		}			
		}
		return $options ;		
	
	}         
	public function allNewsLater( &$connect)
	{			 
		$now = mktime();
		$today = date("dmy",$now);
		$file = "compiler/cache/html/tintuc/listlatestnews_".$today.".db" ;
		$options = '' ;		
		if( $this->isHTMLCat( $file ) ) {
		$options = @file_get_contents( $file ) ;			
		}
		else {	
			$yesterday = date("dmy",$now - 86400);
			if(file_exists("compiler/cache/html/tintuc/listlatest_".$yesterday.".db")) unlink("compiler/cache/html/tintuc/listlatest_".$yesterday.".db");
			$SQL = "SELECT tin_id, tin_tieude 
					FROM `tintuc` 
					ORDER BY tin_ngaydang DESC
					LIMIT 5;"; 					        			
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array());			
		if ( $stmt ) {
			$allList = $stmt->fetchAll();
											
			if( count( $allList ) > 0 ){						
				foreach( $allList as $k => $v ){
					$options .='<li><a href="'.DOCUMENT_ROOT.'/tintuc/'.$v["tin_id"].'" class="mainlevel" ';												
					$options .=' >'.$v["tin_tieude"].'</a></li>';											
				}			
			}	
		}										
		//WRITE FILE
		if( !empty( $options ) ) {
			@file_put_contents( $file, $options ) ;
		}			
		}
		return $options ;		
	
	}
	//lay tin tuc moi nhat 
	public function getTinmoinhat(&$connect, $limit)
	{
		$SQL = "SELECT tin_id, tin_tieude FROM `tintuc`  ORDER BY tin_ngaydang DESC LIMIT ".$limit; 					        
		$stmt = $connect->prepare($SQL);
		$stmt->execute();
		$row = $stmt->fetchall();
		return $row;
	}
	/////////////////////////////////////CATERGORY//////////////////////
	//GET ALL CATEGORY TO OPTION
	public function allCategoty(&$connect,
		                        &$md5Class		                       
		                       ) {
		$file = "compiler/cache/html/category/options.db" ;
		$options = "" ;
				
		if( $this->isHTMLCat( $file ) ) {
			$options = @file_get_contents( $file ) ;			
		}
		else {							
			$options .= $this->reCategory( $connect, $md5Class ) ;											
			//WRITE FILE
			if( !empty( $options ) ) {
				@file_put_contents( $file, $options ) ;
				unset( $this->strcat ) ;
			}			
		}
		return $options ;
	}
	//GET ALL CATEGORY TO OPTION
	public function allCategotySelected(&$connect,
		                        &$md5Class,	
		                        $currentid = 0,	                        
		                        $lang_id = 1,		                        
		                        $pid = -1,
		                        $level = 0		                       
		                       ) {
		$file = "compiler/cache/html/category/options_".$currentid.".db" ;
		$options = "" ;
				
		if( $this->isHTMLCat( $file ) ) {
			$options = @file_get_contents( $file ) ;			
		}
		else {							
			$options .= $this->reCategory( $connect, $md5Class, $lang_id, $currentid, $pid, $level ) ;
			//WRITE FILE
			if( !empty( $options ) ) {
				@file_put_contents( $file, $options ) ;
				unset( $this->strcat ) ;
			}			
		}
		return $options ;
	}
	//LOOP CATEGORY
	public function reCategory(&$connect,
		                        &$md5Class,
		                        $lang_id = 1,
		                        $currentid=0,	                       
		                        $pid = -1,
		                        $level = 0) {
			$spechar = " -- ";				
			$SQL = "
					SELECT SQL_CACHE B.loaisp_ten, 
					       A.loaisp_id, A.loaisp_cap
					FROM ml_loai_sanpham A, ml_loai_sanpham_des B
					WHERE A.loaisp_id = B.loaisp_id
					AND A.loaisp_id_parent = ?					
					AND B.lang_id = ?
					ORDER BY A.loaisp_thutu ASC
				   ";
//			echo $SQL."_".$pid."_".$lang_id;exit;	
			$stmt = $connect->prepare( $SQL );
			$stmt->execute( array( $pid, $lang_id ) );
			
			if ( $stmt ) {
			   	$allList = $stmt->fetchAll();
			   				   					
			   	if( count( $allList ) > 0 ){						
					foreach( $allList as $k => $v ){
						$this->strcat .="<option";
						if( $v["loaisp_id"] == $currentid ) {
							$this->strcat .= " selected ";	
						}
						
						$this->strcat .=" value=\"".
						                $md5Class->encodeStatic( $v["loaisp_id"] ) .
						                "\" >&nbsp;&nbsp;";		
						$this->strcat .= str_repeat( $spechar, $level );
						$this->strcat .= $v["loaisp_ten"]."&nbsp;&nbsp;&nbsp;-----> Cấp ".$v["loaisp_cap"];
						$this->strcat .= "</option>";	
									
						$this->reCategory( $connect,
					                       $md5Class,
					                       $lang_id,
					                       $currentid,					                      
					                       $v["loaisp_id"],
					                       $level+1
					                      );
					}			
				}	
			}	
			return $this->strcat ;
	}
	/***********************13/08/2012*******************************/	
	//GET ALL CATEGORY TO OPTION
	public function allCategotyLVB(&$connect,
		                        &$md5Class,
		                        $lang_id = 1		                       
		                       ) {
		$file = "compiler/cache/html/category/lvb/options_".$lang_id.".db" ;
		$options = "" ;
				
		if( $this->isHTMLCat( $file ) ) {
			$options = @file_get_contents( $file ) ;			
		}
		else {							
			$options .= $this->reCategoryLVB( $connect, $md5Class ) ;											
			//WRITE FILE
			if( !empty( $options ) ) {
				@file_put_contents( $file, $options ) ;
				unset( $this->strcat ) ;
			}			
		}
		return $options ;
	}
	//LOOP CATEGORY
	public function reCategoryLVB(&$connect,
		                        &$md5Class,
		                        $lang_id = 1,
		                        $currentid=0,	                       
		                        $pid = -1,
		                        $level = 0) {
			$spechar = " -- ";				
			$SQL = "
					SELECT SQL_CACHE B.loaivb_ten, 
					       A.loaivb_id, A.loaivb_cap
					FROM ml_loai_vanban A, ml_loai_vanban_des B
					WHERE A.loaivb_id = B.loaivb_id
					AND A.loaivb_id_parent = ?					
					AND B.lang_id = ?
					ORDER BY A.loaivb_thutu ASC
				   ";
//			echo $SQL."_".$pid."_".$lang_id;exit;	
			$stmt = $connect->prepare( $SQL );
			$stmt->execute( array( $pid, $lang_id ) );
			
			if ( $stmt ) {
			   	$allList = $stmt->fetchAll();
			   				   					
			   	if( count( $allList ) > 0 ){						
					foreach( $allList as $k => $v ){
						$this->strcat .="<option";
						if( $v["loaivb_id"] == $currentid ) {
							$this->strcat .= " selected ";	
						}
						
						$this->strcat .=" value=\"".
						                $md5Class->encodeStatic( $v["loaivb_id"] ) .
						                "\" >&nbsp;&nbsp;";		
						$this->strcat .= str_repeat( $spechar, $level );
						$this->strcat .= $v["loaivb_ten"]."&nbsp;&nbsp;&nbsp;-----> Cấp ".$v["loaivb_cap"];
						$this->strcat .= "</option>";	
									
						$this->reCategoryLVB( $connect,
					                       $md5Class,
					                       $lang_id,
					                       $currentid,					                      
					                       $v["loaivb_id"],
					                       $level+1
					                      );
					}			
				}	
			}	
			return $this->strcat ;
	}
	//GET ALL CATEGORY LVB TO OPTION
	public function allCategotyLVBSelected(&$connect,
		                        &$md5Class,	
		                        $currentid = 0,	                        
		                        $lang_id = 1,		                        
		                        $pid = -1,
		                        $level = 0		                       
		                       ) {
		$file = "compiler/cache/html/category/lvb/options_".$lang_id."_".$currentid.".db" ;
		$options = "" ;
				
		if( $this->isHTMLCat( $file ) ) {
			$options = @file_get_contents( $file ) ;			
		}
		else {							
			$options .= $this->reCategoryLVB( $connect, $md5Class, $lang_id, $currentid, $pid, $level ) ;
			//WRITE FILE
			if( !empty( $options ) ) {
				@file_put_contents( $file, $options ) ;
				unset( $this->strcat ) ;
			}			
		}
		return $options ;
	}
	public function CategoryLVBListId(&$connect,
								$lvbid,
								$pid,
		                        $lang_id = 1
		                        ) {
			$spechar = ",";			
			$this->strcat1 .= $lvbid.$spechar;	
			$SQL = "
					SELECT SQL_CACHE B.loaivb_ten, A.loaivb_id, A.loaivb_cap
					FROM ml_loai_vanban A, ml_loai_vanban_des B
					WHERE A.loaivb_id = B.loaivb_id
					AND A.loaivb_id_parent = ?					
					AND B.lang_id = ?
				   ";
			$stmt = $connect->prepare( $SQL );
			$stmt->execute( array( $lvbid, $lang_id ) );		   		
			if ( $stmt ) {
			   	$allList = $stmt->fetchAll();
			   	if( count( $allList ) > 0 ){	
			   		foreach ($allList as $k=>$v)					
			   		{
			   			$this->CategoryLVBListId($connect,
											$v['loaivb_id'],
											$v['loaivb_id'],
					                        $lang_id
					                        );
			   		}                       
				}	
			}	
			return $this->strcat1 ;
	}
	/************************END 13/08/2012*****************************/
	/************************Start 19/10/2012*****************************/
	//GET ALL CATEGORY TO OPTION
	public function allCategotyLTV(&$connect,
		                        &$md5Class,
		                        $lang_id = 1		                       
		                       ) {
		$file = "compiler/cache/html/category/ltv/options_".$lang_id.".db" ;
		$options = "" ;
				
		if( $this->isHTMLCat( $file ) ) {
			$options = @file_get_contents( $file ) ;			
		}
		else {							
			$options .= $this->reCategoryLTV( $connect, $md5Class ) ;											
			//WRITE FILE
			if( !empty( $options ) ) {
				@file_put_contents( $file, $options ) ;
				unset( $this->strcat ) ;
			}			
		}
		return $options ;
	}
	//LOOP CATEGORY
	public function reCategoryLTV(&$connect,
		                        &$md5Class,
		                        $lang_id = 1,
		                        $currentid=0,	                       
		                        $pid = -1,
		                        $level = 0) {
			$spechar = " -- ";				
			$SQL = "
					SELECT SQL_CACHE B.loaitv_ten, 
					       A.loaitv_id, A.loaitv_cap
					FROM ml_loai_tuvan A, ml_loai_tuvan_des B
					WHERE A.loaitv_id = B.loaitv_id
					AND A.loaitv_id_parent = ?					
					AND B.lang_id = ?
					ORDER BY A.loaitv_thutu ASC
				   ";
//			echo $SQL."_".$pid."_".$lang_id;exit;	
			$stmt = $connect->prepare( $SQL );
			$stmt->execute( array( $pid, $lang_id ) );
			
			if ( $stmt ) {
			   	$allList = $stmt->fetchAll();
			   				   					
			   	if( count( $allList ) > 0 ){						
					foreach( $allList as $k => $v ){
						$this->strcat .="<option";
						if( $v["loaitv_id"] == $currentid ) {
							$this->strcat .= " selected ";	
						}
						
						$this->strcat .=" value=\"".
						                $md5Class->encodeStatic( $v["loaitv_id"] ) .
						                "\" >&nbsp;&nbsp;";		
						$this->strcat .= str_repeat( $spechar, $level );
						$this->strcat .= $v["loaitv_ten"]."&nbsp;&nbsp;&nbsp;-----> Cấp ".$v["loaitv_cap"];
						$this->strcat .= "</option>";	
									
						$this->reCategoryLTV( $connect,
					                       $md5Class,
					                       $lang_id,
					                       $currentid,					                      
					                       $v["loaitv_id"],
					                       $level+1
					                      );
					}			
				}	
			}	
			return $this->strcat ;
	}
	//GET ALL CATEGORY LVB TO OPTION
	public function allCategotyLTVSelected(&$connect,
		                        &$md5Class,	
		                        $currentid = 0,	                        
		                        $lang_id = 1,		                        
		                        $pid = -1,
		                        $level = 0		                       
		                       ) {
		$file = "compiler/cache/html/category/ltv/options_".$lang_id."_".$currentid.".db" ;
		$options = "" ;
				
		if( $this->isHTMLCat( $file ) ) {
			$options = @file_get_contents( $file ) ;			
		}
		else {							
			$options .= $this->reCategoryLTV( $connect, $md5Class, $lang_id, $currentid, $pid, $level ) ;
			//WRITE FILE
			if( !empty( $options ) ) {
				@file_put_contents( $file, $options ) ;
				unset( $this->strcat ) ;
			}			
		}
		return $options ;
	}
	public function CategoryLTVListId(&$connect,
								$lvbid,
								$pid,
		                        $lang_id = 1
		                        ) {
			$spechar = ",";			
			$this->strcat1 .= $lvbid.$spechar;	
			$SQL = "
					SELECT SQL_CACHE B.loaitv_ten, A.loaitv_id, A.loaitv_cap
					FROM ml_loai_tuvan A, ml_loai_tuvan_des B
					WHERE A.loaitv_id = B.loaitv_id
					AND A.loaitv_id_parent = ?					
					AND B.lang_id = ?
				   ";
			$stmt = $connect->prepare( $SQL );
			$stmt->execute( array( $lvbid, $lang_id ) );		   		
			if ( $stmt ) {
			   	$allList = $stmt->fetchAll();
			   	if( count( $allList ) > 0 ){	
			   		foreach ($allList as $k=>$v)					
			   		{
			   			$this->CategoryLTVListId($connect,
											$v['loaitv_id'],
											$v['loaitv_id'],
					                        $lang_id
					                        );
			   		}                       
				}	
			}	
			return $this->strcat1 ;
	}
	public function DanhMucLoaiTuVanCapMot( &$connect, $lang_id = 1 ) {	
	    $now = mktime();
		$SQL = "SELECT A.loaitv_id, B.loaitv_ten, B.loaitv_ghichu
				FROM `ml_loai_tuvan` A, `ml_loai_tuvan_des` B
				WHERE A.loaitv_id = B.loaitv_id
				AND A.loaitv_id_parent = -1					
				AND B.lang_id = ?
				ORDER BY `loaitv_thutu` ASC;				
			   ";	
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array( $lang_id ) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetchAll();	   				   
		}	
		return $oneList ;
	}
	public function TaoFileCacheDanhMucTuVanCapMot( &$connect, $lang_id = 1 )
	{			 
		$now = mktime();
		$today = date("dmy",$now);
		$file = "compiler/cache/html/category/ltv/danh_muc_cap_1_tu_van_".$today.".php" ;
		$content = '' ;		
		if( !$this->isHTMLCat( $file ) ) {
			$yesterday = date("dmy",$now - 86400);
			if(file_exists("compiler/cache/html/category/ltv/danh_muc_cap_1_tu_van_".$yesterday.".php")) unlink("compiler/cache/html/category/ltv/danh_muc_cap_1_tu_van_".$yesterday.".php");
			$arr_ltv = $this->DanhMucLoaiTuVanCapMot($connect, $lang_id);
			$content = "<?php\n\n";
			$fmtime = date("d-m-Y H:i:s");
			$content .= "// File: danh_muc_cap_1_tu_van_".$today.".php\n// Created: $fmtime.\n// Do not change anything in this file!\n\n";
			$content .= "if (!defined('ATN_ADMIN')) {\n";
			$content .= "die('Stop!!!');\n";
			$content .= "}\n";
			$content .= "\n";
			if( count( $arr_ltv ) > 0 )
			{				
				$i=0;
				$module = "";
				foreach( $arr_ltv as $values ){
					
					list($loaitv_id, $loaitv_ten, $loaitv_ghichu) = $values;
					$content .= "\$loaituvan['".$i."'] = array('loaitv_id'=>'$loaitv_id', 'loaitv_ten'=>'$loaitv_ten', 'loaitv_ghichu'=>'$loaitv_ghichu');\n";
					$i++;
				}	
			}	
			$content .= "\n";
			$content .= "?>";
			//WRITE FILE
			if( !empty( $content ) ) {
				@file_put_contents( $file, $content ) ;
				return true ;
			}
			else return false ;		
		}				
		else return true;						
	}							
	/************************END 19/10/2012*****************************/
	public function CreatMenuLeft(&$connect,
		                        &$md5Class,	
		                        $lang_id = 1,		                        
		                        $pid = -1,
		                        $level = 1		                       
		                       ) {
		$now = mktime();
		$today = date("dmy",$now);                       	
		$file = "compiler/cache/html/category/category_".$today.".xtpl" ;
		$file_js = "compiler/cache/html/category/category_js_".$today.".xtpl" ;
				
		if( $this->isHTMLCat( $file ) ) {
			$options = @file_get_contents( $file ) ;			
		}
		else {							
			list($html, $js) = $this->CategoryByLevel( $connect, $md5Class, $lang_id, $pid, $level ) ;
			//WRITE FILE
			if( !empty( $html ) ) {
				@file_put_contents( $file, $html ) ;
				unset( $this->strcat ) ;
			}	
			if( !empty( $js ) ) {
				@file_put_contents( $file_js, $js ) ;
				unset( $this->strcat1 ) ;
			}		
		}
	}
	public function CategoryByLevel(&$connect,
		                        &$md5Class,
		                        $lang_id = 1,
		                        $pid = -1,
		                        $level = 1) {
			$spechar = " -- ";				
			$SQL = "
					SELECT SQL_CACHE B.loaisp_ten, 
					       A.loaisp_id
					FROM ml_loai_sanpham A, ml_loai_sanpham_des B
					WHERE A.loaisp_id = B.loaisp_id
					AND A.loaisp_id_parent = ?					
					AND B.lang_id = ?
					AND A.loaisp_cap = ?
					ORDER BY A.loaisp_thutu ASC
				   ";
			$stmt = $connect->prepare( $SQL );
			$stmt->execute( array( $pid, $lang_id, $level ) );
			
			if ( $stmt ) {
			   	$allList = $stmt->fetchAll();
			   				   					
			   	if( count( $allList ) > 0 ){						
					foreach( $allList as $k => $v ){
						switch($level)
						{
							case 1:
								$this->strcat .='<div style="clear:left;">
									                   <span><img src="{DOCUMENT_ROOT}/images/icon_sp.gif" border="0" align="absmiddle" />&nbsp;'.$v["loaisp_ten"].'</span>';
								$this->CategoryByLevel( $connect,
					                       $md5Class,
					                       $lang_id,
					                       $v["loaisp_id"],
					                       $level+1
					                      );
								$this->strcat .='<br />
								                  </div>';
								break;
							case 2:
								$this->strcat .='<a href="#" target="_self"  id="menu'.$v['loaisp_id'].'"><img src="images/icon_arrow.gif" align="absmiddle" border="0" />&nbsp;'.$v['loaisp_ten'].'</a>';
								$this->strcat1 .= 'var tmenu'.$v["loaisp_id"].' = ms.addMenu(document.getElementById("menu'.$v["loaisp_id"].'"));';
								$this->CategoryByLevel( $connect,
					                       $md5Class,
					                       $lang_id,
					                       $v["loaisp_id"],
					                       $level+1
					                      );
								break;
							case 3:
								$this->strcat1 .= 'tmenu'.$pid.'.addItem("'.$v["loaisp_ten"].'", "{DOCUMENT_ROOT}/sanpham/'.$v["loaisp_id"].'", 0, 0);';													
								break;
										
						}
					}			
				}	
			}	
			return array($this->strcat, $this->strcat1) ;
	}
	/*
	
	*/
	//LOOP CATEGORY
	public function CreatMenuLeftNew(&$connect,
		                        $lang_id = 1,		                        
		                        $pid = -1,
		                        $level = 1		                       
		                       ) {
		$file = "compiler/cache/html/category/category.xtpl" ;
		$options = "" ;
				
		if( $this->isHTMLCat( $file ) ) {
			$options = @file_get_contents( $file ) ;			
		}
		else {							
			$options .= $this->CategoryByLevelNew( $connect, $lang_id, $pid, $level ) ;
			//WRITE FILE
			if( !empty( $options ) ) {
				@file_put_contents( $file, $options ) ;
				unset( $this->strcat ) ;
			}			
		}
		return $options ;
	}
	public function CategoryByLevelNew(&$connect,
		                        $lang_id = 1,
		                        $pid = -1,
		                        $level = 1) {
			$spechar = " -- ";				
			$SQL = "
					SELECT SQL_CACHE B.loaisp_ten, 
					       A.loaisp_id
					FROM ml_loai_sanpham A, ml_loai_sanpham_des B
					WHERE A.loaisp_id = B.loaisp_id
					AND A.loaisp_id_parent = ?					
					AND B.lang_id = ?
					AND A.loaisp_cap = ?
					ORDER BY A.loaisp_thutu ASC
				   ";
			$stmt = $connect->prepare( $SQL );
			$stmt->execute( array( $pid, $lang_id, $level ) );
			
			if ( $stmt ) {
			   	$allList = $stmt->fetchAll();
			   				   					
			   	if( count( $allList ) > 0 ){						
			   		$this->strcat .='<ul>';
					foreach( $allList as $k => $v ){
						$this->strcat .='<li><a href="{DOCUMENT_ROOT}/sanpham/'.$v['loaisp_id'].'">'.$v["loaisp_ten"].'</a>';
						 $this->CategoryByLevelNew( $connect,
					                       $lang_id,
					                       $v["loaisp_id"],
					                       $level+1
					                      );
					     $this->strcat .= '</li>';
					}	
					$this->strcat .='</ul>';		
				}	
			}	
			return $this->strcat ;
	}
	public function CategoryText(&$connect,
								$lspid,
		                        $lang_id = 1
		                        ) {
			$spechar = " --> ";				
			$SQL = "
					SELECT SQL_CACHE B.loaisp_ten, A.loaisp_id, A.loaisp_id_parent, A.loaisp_cap
					FROM ml_loai_sanpham A, ml_loai_sanpham_des B
					WHERE A.loaisp_id = B.loaisp_id
					AND A.loaisp_id = ?					
					AND B.lang_id = ?
					LIMIT 1;
				   ";
			$stmt = $connect->prepare( $SQL );
			$stmt->execute( array( $lspid, $lang_id ) );
			
			if ( $stmt ) {
			   	$allList = $stmt->fetch();
			   				   					
			   	if( count( $allList ) > 0 ){						
			   		if($allList['loaisp_cap'] > 1)
			   		{
			   			$this->CategoryText( $connect,
			   								$allList["loaisp_id_parent"],
							                $lang_id
							                      );
			   		}
			   		if($allList['loaisp_cap'] > 1)
			   			$this->strcat .= $spechar."<a href='".DOCUMENT_ROOT."/sanpham/".$lspid."'>".$allList['loaisp_ten']."</a>";
			   		else $this->strcat .= "<a href='".DOCUMENT_ROOT."/sanpham/".$lspid."'>".$allList['loaisp_ten']."</a>";
				}	
			}	
			return $this->strcat ;
	}
	public function CategoryListId(&$connect,
								$lspid,
								$pid,
		                        $lang_id = 1
		                        ) {
			$spechar = ",";			
			$this->strcat1 .= $lspid.$spechar;	
			$SQL = "
					SELECT SQL_CACHE B.loaisp_ten, A.loaisp_id, A.loaisp_cap
					FROM ml_loai_sanpham A, ml_loai_sanpham_des B
					WHERE A.loaisp_id = B.loaisp_id
					AND A.loaisp_id_parent = ?					
					AND B.lang_id = ?
				   ";
			$stmt = $connect->prepare( $SQL );
			$stmt->execute( array( $lspid, $lang_id ) );		   		
			if ( $stmt ) {
			   	$allList = $stmt->fetchAll();
			   	if( count( $allList ) > 0 ){	
			   		foreach ($allList as $k=>$v)					
			   		{
			   			$this->CategoryListId($connect,
											$v['loaisp_id'],
											$v['loaisp_id'],
					                        $lang_id
					                        );
			   		}                       
				}	
			}	
			return $this->strcat1 ;
	}
	//---------------------------NEW---------------------------------//
	public function checkThanhVien( &$connect,
	                             $username
	                            ) {	
	    $oneList = 0 ;     
		$SQL = "
				SELECT hv_matkhau
				FROM ml_hoivien
				WHERE hv_email = ?	
				LIMIT 1;      
			   ";					   
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array( $username ) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetchColumn();	   		
		   				   		
		   	if( $oneList == FALSE ) {
		   		$oneList = "" ;
		   	}
		}	
		
		return $oneList ;
	}
	public function getThanhVien( &$connect,
	                             $username,
	                             $password ) {	
		$SQL = "
				SELECT *
				FROM ml_hoivien 
				WHERE hv_email = ?
				      AND hv_matkhau = ?
				      AND hv_tinhtrang = 1	
				LIMIT 1;      
			   ";	
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array( $username, $password ) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetch();	   				   
		}	
		
		return $oneList ;
	}
	
	public function getMemberInfo( &$connect,
	                             $memid ) {	
		$SQL = "
				SELECT *
				FROM ml_hoivien 
				WHERE hv_id = ?	
				LIMIT 1;      
			   ";	
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array( $memid ) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetch();	   				   
		}	
		
		return $oneList ;
	}
								 							 
	public function getVideoRandom( &$connect ) {	
		$SQL = "
				SELECT `video_tieude` , `video_ghichu` , `video_link` , `video_hinhdaidien`
				FROM `ml_video`
				WHERE `video_tinhtrang` = 1
				ORDER BY RAND( )
				LIMIT 1 ;      
			   ";	
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array(  ) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetch();	   				   
		}	
		
		return $oneList ;
	}
	public function getSanPhamTop( &$connect, &$oneList ) {	
		$SQL = "SELECT A.`sp_id` , A.`sp_ma` , A.`sp_hinh` , A.`sp_giacu` , A.`sp_giaban` , A.`sp_donvi`, A.`sp_loai_id` , B.`sp_ten`
				FROM `ml_sanpham` A, `ml_sanpham_des` B
				WHERE A.`sp_top` = 1
				AND A.`sp_conhang` = 1
				AND A.`sp_status` = 1
				AND A.`sp_id` = B.`sp_id`
				ORDER BY ( A.`sp_tongdiembc` / A.`sp_solanbc`) DESC
				LIMIT 0 , 6 ;
			   ";	
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array(  ) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetchAll();
		   	if(count($oneList)) return true;	   				   
		}	
		return false ;
	}
	public function getSanPhamMoi( &$connect, $start = 0, $end = 5 ) {		      
		$SQL = "SELECT A.`sp_id` , A.`sp_ma` , A.`sp_hinh` , A.`sp_giacu` , A.`sp_giaban` , A.`sp_donvi`, A.`sp_conhang`, A.`sp_loai_id` , B.`sp_ten`, C.`loaisp_ten`, C.`loaisp_id`
				FROM `ml_sanpham` A, `ml_sanpham_des` B, `ml_loai_sanpham_des` C
				WHERE A.`sp_top` = 0
				AND A.`sp_quangcao` = 0
				AND A.`sp_banchay` = 0
				AND A.`sp_conhang` = 1
				AND A.`sp_status` = 1
				AND A.`sp_id` = B.`sp_id`
				AND A.sp_loai_id = C.loaisp_id
				ORDER BY A.`sp_id` DESC
				LIMIT $start , $end ;
			   ";	
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array(  ) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetchAll();	   				   
		}	
		return $oneList ;
	}
	public function getSanPhamQuangCao( &$connect, $start = 0, $end = 10 ) {		      
		$SQL = "SELECT A.`sp_id` , A.`sp_ma` , A.`sp_hinh` , A.`sp_giacu` , A.`sp_giaban` , A.`sp_donvi`, A.`sp_conhang`, A.`sp_loai_id` , B.`sp_ten`, C.`loaisp_ten`, C.`loaisp_id`
				FROM `ml_sanpham` A, `ml_sanpham_des` B, `ml_loai_sanpham_des` C
				WHERE A.`sp_quangcao` = 1
				AND A.`sp_status` = 1
				AND A.`sp_id` = B.`sp_id`
				AND A.sp_loai_id = C.loaisp_id
				ORDER BY A.`sp_id` DESC
				LIMIT $start , $end ;
			   ";	
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array(  ) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetchAll();	   				   
		}	
		return $oneList ;
	}
	public function getListNewQuangCao( &$connect ) {	
	    $now = mktime();
		$SQL = "SELECT *
				FROM `quangcao` 
				WHERE `qc_active` = 1
				AND (`qc_batdau` + `qc_thoigian`*86400) > ?
				ORDER BY `qc_module` ASC, `qc_vitri` ASC, `qc_thutu` ASC
				;
			   ";	
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array( $now ) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetchAll();	   				   
		}	
		return $oneList ;
	}
	public function TaoFileCacheQuangCao( &$connect)
	{			 
		$now = mktime();
		$today = date("dmy",$now);
		$file = "compiler/cache/html/quangcao/quangcao_".$today.".php" ;
		$content = '' ;		
		if( !$this->isHTMLCat( $file ) ) {
			$yesterday = date("dmy",$now - 86400);
			if(file_exists("compiler/cache/html/quangcao/quangcao_".$yesterday.".php")) unlink("compiler/cache/html/quangcao/quangcao_".$yesterday.".php");
			$arr_qc = $this->getListNewQuangCao($connect);
			$content = "<?php\n\n";
			$fmtime = date("d-m-Y H:i:s");
			$content .= "// File: quangcao_".$today.".php\n// Created: $fmtime.\n// Do not change anything in this file!\n\n";
			$content .= "if (!defined('ATN_ADMIN')) {\n";
			$content .= "die('Stop!!!');\n";
			$content .= "}\n";
			$content .= "\n";
			if( count( $arr_qc ) > 0 )
			{				
				$i=0;
				$module = "";
				foreach( $arr_qc as $values ){
					
					list($qc_id, $qc_ten, $qc_hinh, $qc_link, $qc_batdau, $qc_thoigian, $qc_active, $qc_module, $qc_thutu, $qc_vitri) = $values;
					$content .= "\$banner_list['".$qc_module."'][".intval($qc_vitri)."][".intval($qc_thutu)."] = array('name'=>'$qc_ten', 'img'=>'$qc_hinh', 'url'=>'$qc_link');\n";
				}	
			}	
			$content .= "\n";
			$content .= "?>";
			//WRITE FILE
			if( !empty( $content ) ) {
				@file_put_contents( $file, $content ) ;
				return true ;
			}
			else return false ;		
		}				
		else return true;						
	}
	
	public function getThongTinChung( &$connect ) {	
	    $now = mktime();
		$SQL = "SELECT *
				FROM `thongtinchung` 
				WHERE 1 = 1
				LIMIT 1
				;
			   ";	
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array( ) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetch();	   				   
		}	
		return $oneList ;
	}
	public function TaoFileCacheThôngTinChung( &$connect )
	{			 
		/*$now = mktime();
		$today = date("dmy",$now);*/
		$file = "compiler/cache/html/quangcao/thongtinchung.php" ;
		$content = '' ;		
		if( !$this->isHTMLCat( $file ) ) {
			$arr_tt = $this->getThongTinChung($connect);
			$content = "<?php\n\n";
			$fmtime = date("d-m-Y H:i:s");
			$content .= "// File: thongtinchung.php\n// Created: $fmtime.\n// Do not change anything in this file!\n\n";
			$content .= "if (!defined('ATN_ADMIN')) {\n";
			$content .= "die('Stop!!!');\n";
			$content .= "}\n";
			$content .= "\n";
			if( is_array( $arr_tt ) )
			{				
				$content .= "\$thongtinchung['tencongty'] = '".addslashes($arr_tt['tencongty'])."';\n";
				$content .= "\$thongtinchung['diachi'] = '".addslashes($arr_tt['diachi'])."';\n";
				$content .= "\$thongtinchung['dienthoai'] = '".addslashes($arr_tt['dienthoai'])."';\n";
				$content .= "\$thongtinchung['didong'] = '".addslashes($arr_tt['didong'])."';\n";
				$content .= "\$thongtinchung['fax'] = '".addslashes($arr_tt['fax'])."';\n";
				$content .= "\$thongtinchung['nick'] = '".addslashes($arr_tt['nick'])."';\n";
				$content .= "\$thongtinchung['email'] = '".$arr_tt['email']."';\n";
				$content .= "\$thongtinchung['gioithieu'] = '".addslashes($arr_tt['gioithieu'])."';\n";
				$content .= "\$thongtinchung['dichvu'] = '".addslashes($arr_tt['dichvu'])."';\n";
				$content .= "\$thongtinchung['bando'] = '".addslashes($arr_tt['bando'])."';\n";
			}
			else 
			{
				$content .= "\$thongtinchung['tencongty'] = '';\n";
				$content .= "\$thongtinchung['diachi'] = '';\n";
				$content .= "\$thongtinchung['dienthoai'] = '';\n";
				$content .= "\$thongtinchung['didong'] = '';\n";
				$content .= "\$thongtinchung['fax'] = '';\n";
				$content .= "\$thongtinchung['nick'] = '';\n";
				$content .= "\$thongtinchung['email'] = '';\n";
				$content .= "\$thongtinchung['gioithieu'] = '';\n";
				$content .= "\$thongtinchung['dichvu'] = '';\n";
				$content .= "\$thongtinchung['bando'] = '';\n";
			}
			$content .= "\n";
			$content .= "?>";
			//WRITE FILE
			if( !empty( $content ) ) {
				@file_put_contents( $file, $content ) ;
				return true ;
			}
			else return false ;		
		}				
		else return true;						
	}
	public function ChiTietBinhChon( &$connect,
	                             &$oneList                           
	                            ) {	
	    $oneList = array() ;     
	 	$SQL = "
				SELECT  *
				FROM ml_binhchonchung 				
				LIMIT 1;
			   ";	
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array( ) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetch();
		   	return  true;	   		
		}			
		return false ;
	}
	public function BinhChon( &$connect, $set ) {		    
	$SQL = "
				UPDATE ml_binhchonchung 							  
				SET  $set, bbc_tongsolan = bbc_tongsolan + 1;
			   ";
		$connect->beginTransaction();
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( );  

		if ( !$stmt ) {				
			$connect->rollBack();			
			return false ;
		}
				
		$connect->commit();			
		return true ;
	}
	public function TaoFileCacheBinhChonChung( &$connect )
	{			 
		$file = "compiler/cache/html/quangcao/binhchonchung.php" ;
		$content = '' ;		
		if( !$this->isHTMLCat( $file ) ) {
			$check = $this->ChiTietBinhChon($connect, $arr_tt);
			$content = "<?php\n\n";
			$fmtime = date("d-m-Y H:i:s");
			$content .= "// File: binhchonchung.php\n// Created: $fmtime.\n// Do not change anything in this file!\n\n";
			$content .= "if (!defined('ATN_ADMIN')) {\n";
			$content .= "die('Stop!!!');\n";
			$content .= "}\n";
			$content .= "\n";
			if( $check )
			{				
				$content .= "\$binhchonchung['bbc_chude'] = '".addslashes($arr_tt['bbc_chude'])."';\n";
				$content .= "\$binhchonchung['bbc_luachon1'] = '".addslashes($arr_tt['bbc_luachon1'])."';\n";
				$content .= "\$binhchonchung['bbc_luachon2'] = '".addslashes($arr_tt['bbc_luachon2'])."';\n";
				$content .= "\$binhchonchung['bbc_luachon3'] = '".addslashes($arr_tt['bbc_luachon3'])."';\n";
				$content .= "\$binhchonchung['bbc_luachon4'] = '".addslashes($arr_tt['bbc_luachon4'])."';\n";
				$content .= "\$binhchonchung['bbc_tinhtrang'] = '".addslashes($arr_tt['bbc_tinhtrang'])."';\n";
				$content .= "\$binhchonchung['bbc_solan1'] = '".addslashes($arr_tt['bbc_solan1'])."';\n";
				$content .= "\$binhchonchung['bbc_solan2'] = '".addslashes($arr_tt['bbc_solan2'])."';\n";
				$content .= "\$binhchonchung['bbc_solan3'] = '".addslashes($arr_tt['bbc_solan3'])."';\n";
				$content .= "\$binhchonchung['bbc_solan4'] = '".addslashes($arr_tt['bbc_solan4'])."';\n";
				$content .= "\$binhchonchung['bbc_tongsolan'] = '".addslashes($arr_tt['bbc_tongsolan'])."';\n";
			}
			else 
			{
				$content .= "\$binhchonchung['bbc_chude'] = '';\n";
				$content .= "\$binhchonchung['bbc_luachon1'] = '';\n";
				$content .= "\$binhchonchung['bbc_luachon2'] = '';\n";
				$content .= "\$binhchonchung['bbc_luachon3'] = '';\n";
				$content .= "\$binhchonchung['bbc_luachon4'] = '';\n";
				$content .= "\$binhchonchung['bbc_tinhtrang'] = 0;\n";
				$content .= "\$binhchonchung['bbc_solan1'] = 0;\n";
				$content .= "\$binhchonchung['bbc_solan2'] = 0;\n";
				$content .= "\$binhchonchung['bbc_solan3'] = 0;\n";
				$content .= "\$binhchonchung['bbc_solan4'] = 0;\n";
				$content .= "\$binhchonchung['bbc_tongsolan'] = 0;\n";
			}
			$content .= "\n";
			$content .= "?>";
			//WRITE FILE
			if( !empty( $content ) ) {
				@file_put_contents( $file, $content ) ;
				return true ;
			}
			else return false ;		
		}				
		else return true;						
	}
	public function TaoFileCacheSanPhamMoi( &$connect )
	{			 
		$file = "compiler/cache/html/quangcao/sanphammoi.php" ;
		$content = '' ;		
		if( !$this->isHTMLCat( $file ) ) {
			$array_spm = $this->getSanPhamMoi($connect, 0, 5);
			$content = "<?php\n\n";
			$fmtime = date("d-m-Y H:i:s");
			$content .= "// File: sanphammoi.php\n// Created: $fmtime.\n// Do not change anything in this file!\n\n";
			$content .= "if (!defined('ATN_ADMIN')) {\n";
			$content .= "die('Stop!!!');\n";
			$content .= "}\n";
			$content .= "\n";
			if( count($array_spm) )
			{				
				$i = 0;
				foreach ($array_spm as $values)
				{
					$content .= "\$sanphammoi[".$i."]['sp_id'] = '".$values['sp_id']."';\n";
					$content .= "\$sanphammoi[".$i."]['sp_ma'] = '".addslashes($values['sp_ma'])."';\n";
					$content .= "\$sanphammoi[".$i."]['sp_hinh'] = '".$values['sp_hinh']."';\n";
					$content .= "\$sanphammoi[".$i."]['sp_ten'] = '".addslashes($values['sp_ten'])."';\n";
					$content .= "\$sanphammoi[".$i."]['sp_giaban'] = '".$values['sp_giaban']."';\n";
					$content .= "\$sanphammoi[".$i."]['sp_giacu'] = '".$values['sp_giacu']."';\n";
					$content .= "\$sanphammoi[".$i."]['sp_donvi'] = '".$values['sp_donvi']."';\n";
					$content .= "\$sanphammoi[".$i."]['sp_loai_id'] = '".$values['sp_loai_id']."';\n";
					$i++;
				}	
			}
			$content .= "\n";
			$content .= "?>";
			//WRITE FILE
			if( !empty( $content ) ) {
				@file_put_contents( $file, $content ) ;
				return true ;
			}
			else return false ;		
		}				
		else return true;						
	}
	public function TaoFileCacheSanPhamTop( &$connect )
	{			 
		$file = "compiler/cache/html/quangcao/sanphamtop.php" ;
		$content = '' ;		
		if( !$this->isHTMLCat( $file ) ) {
			$check_spt = $this->getSanPhamTop($connect, $array_spt);
			$content = "<?php\n\n";
			$fmtime = date("d-m-Y H:i:s");
			$content .= "// File: sanphamtop.php\n// Created: $fmtime.\n// Do not change anything in this file!\n\n";
			$content .= "if (!defined('ATN_ADMIN')) {\n";
			$content .= "die('Stop!!!');\n";
			$content .= "}\n";
			$content .= "\n";
			if( $check_spt && count($array_spt) )
			{				
				$i = 0;
				foreach ($array_spt as $values)
				{
					$content .= "\$sanphamtop[".$i."]['sp_id'] = '".$values['sp_id']."';\n";
					$content .= "\$sanphamtop[".$i."]['sp_ma'] = '".addslashes($values['sp_ma'])."';\n";
					$content .= "\$sanphamtop[".$i."]['sp_hinh'] = '".$values['sp_hinh']."';\n";
					$content .= "\$sanphamtop[".$i."]['sp_ten'] = '".addslashes($values['sp_ten'])."';\n";
					$content .= "\$sanphamtop[".$i."]['sp_giaban'] = '".$values['sp_giaban']."';\n";
					$content .= "\$sanphamtop[".$i."]['sp_giacu'] = '".$values['sp_giacu']."';\n";
					$content .= "\$sanphamtop[".$i."]['sp_donvi'] = '".$values['sp_donvi']."';\n";
					$content .= "\$sanphamtop[".$i."]['sp_loai_id'] = '".$values['sp_loai_id']."';\n";
					$i++;
				}	
			}
			$content .= "\n";
			$content .= "?>";
			//WRITE FILE
			if( !empty( $content ) ) {
				@file_put_contents( $file, $content ) ;
				return true ;
			}
			else return false ;		
		}				
		else return true;						
	}
	public function TaoFileCacheSanPhamQuangCao( &$connect )
	{			 
		$file = "compiler/cache/html/quangcao/sanphamquangcaotrai.php" ;
		$content = '' ;		
		if( !$this->isHTMLCat( $file ) ) {
			$array_spm = $this->getSanPhamQuangCao($connect);
			$content = "<?php\n\n";
			$fmtime = date("d-m-Y H:i:s");
			$content .= "// File: sanphamquangcaotrai.php\n// Created: $fmtime.\n// Do not change anything in this file!\n\n";
			$content .= "if (!defined('ATN_ADMIN')) {\n";
			$content .= "die('Stop!!!');\n";
			$content .= "}\n";
			$content .= "\n";
			if( count($array_spm) )
			{				
				$i = 0;
				foreach ($array_spm as $values)
				{
					$content .= "\$sanphamquangcaotrai[".$i."]['sp_id'] = '".$values['sp_id']."';\n";
					$content .= "\$sanphamquangcaotrai[".$i."]['sp_ma'] = '".addslashes($values['sp_ma'])."';\n";
					$content .= "\$sanphamquangcaotrai[".$i."]['sp_hinh'] = '".$values['sp_hinh']."';\n";
					$content .= "\$sanphamquangcaotrai[".$i."]['sp_ten'] = '".addslashes($values['sp_ten'])."';\n";
					$content .= "\$sanphamquangcaotrai[".$i."]['sp_giaban'] = '".$values['sp_giaban']."';\n";
					$content .= "\$sanphamquangcaotrai[".$i."]['sp_giacu'] = '".$values['sp_giacu']."';\n";
					$content .= "\$sanphamquangcaotrai[".$i."]['sp_donvi'] = '".$values['sp_donvi']."';\n";
					$content .= "\$sanphamquangcaotrai[".$i."]['sp_loai_id'] = '".$values['sp_loai_id']."';\n";
					$i++;
				}	
			}
			$content .= "\n";
			$content .= "?>";
			//WRITE FILE
			if( !empty( $content ) ) {
				@file_put_contents( $file, $content ) ;
				return true ;
			}
			else return false ;		
		}				
		else return true;						
	}
	public function TaoFileCacheSanPhamFlash( &$connect )
	{			 
		$file = "compiler/cache/html/quangcao/sanphamflash.php" ;
		$content = '' ;		
		if( !$this->isHTMLCat( $file ) ) {
			$check = $this->ChiTietSanPhamFlash($connect, $values);
			$content = "<?php\n\n";
			$fmtime = date("d-m-Y H:i:s");
			$content .= "// File: sanphamflash.php\n// Created: $fmtime.\n// Do not change anything in this file!\n\n";
			$content .= "if (!defined('ATN_ADMIN')) {\n";
			$content .= "die('Stop!!!');\n";
			$content .= "}\n";
			$content .= "\n";
			if( $check )
			{				
				$content .= "\$sanphamflash['sp_id'] = '".$values['sp_id']."';\n";
				$content .= "\$sanphamflash['sp_ma'] = '".addslashes($values['sp_ma'])."';\n";
				$content .= "\$sanphamflash['sp_hinh'] = '".$values['sp_hinh']."';\n";
				$content .= "\$sanphamflash['sp_ten'] = '".addslashes($values['sp_ten'])."';\n";
				$content .= "\$sanphamflash['sp_giaban'] = '".$values['sp_giaban']."';\n";
				$content .= "\$sanphamflash['sp_giacu'] = '".$values['sp_giacu']."';\n";
				$content .= "\$sanphamflash['sp_donvi'] = '".$values['sp_donvi']."';\n";
				$content .= "\$sanphamflash['sp_mota'] = '".str_replace("'","\'", $values['sp_mota'])."';\n";
				$content .= "\$sanphamflash['sp_soluong'] = '".$values['sp_soluong']."';\n";
				$content .= "\$sanphamflash['sp_khuyenmai'] = '".$values['sp_khuyenmai']."';\n";
					
			}
			$content .= "\n";
			$content .= "?>";
			//WRITE FILE
			if( !empty( $content ) ) {
				@file_put_contents( $file, $content ) ;
				return true ;
			}
			else return false ;		
		}				
		else return true;						
	}
	public function ChiTietSanPhamFlash( &$connect,
	                             &$oneList	                             
	                            ) {	
	    $oneList = 0 ;     
	 	$SQL = "
				SELECT *
				FROM ml_sanpham_flash
				WHERE sp_status = 1
				ORDER BY sp_ngaydang DESC
				LIMIT 1;
			   ";	
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array( ) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetch();
		   	if(count($oneList))
		   		return  true;	   		
		}			
		return false ;
	}
	public function check_dathangflash( &$connect,
	                             $hv_id,
	                             $spflash_id
	                            ) {	
	    $oneList = 0 ;     
		$SQL = "
				SELECT ddh_id
				FROM ml_dondathang_flash
				WHERE hv_id = ?	
				AND sp_flash_id = ?
				LIMIT 1;      
			   ";					   
		$stmt = $connect->prepare( $SQL );
		$stmt->execute( array( $hv_id, $spflash_id ) );
		
		if ( $stmt ) {
		   	$oneList = $stmt->fetchColumn();	   		
		   				   		
		   	if( $oneList == FALSE ) {
		   		$oneList = "" ;
		   	}
		}	
		
		return $oneList ;
	}
								
								
	/*
	 * SMTP Mail
	 */							
								
	// define('SMTP_INCLUDED', 1);
	//
	// This function has been modified as provided
	// by SirSir to allow multiline responses when
	// using SMTP Extensions
	//
	private function server_parse($socket, $response)
	{
	   $server_response = '';
	   while ( substr($server_response,3,1) != ' ' )
	   {
	      if( !( $server_response = fgets($socket, 256) ) )
	      {
	         echo "Couldn't get mail server response codes";
	      }
	   }
	
	   if( !( substr($server_response, 0, 3) == $response ) )
	   {
	      echo "Ran into problems sending Mail. Response: $server_response";
	   }
	}
	
	/****************************************************************************
	*        Function:                 smtpmail
	*        Description:         This is a functional replacement for php's builtin mail
	*                                                function, that uses smtp.
	*        Usage:                        The usage for this function is identical to that of php's
	*                                                built in mail function.
	****************************************************************************/
	private function smtpmail($mail_to, $subject, $message, $headers='',$smtp_host, $smtp_username, $smtp_password,  $admin_email)
	{
	//global $smtp_host, $smtp_username, $smtp_password, $admin_email;
	//echo $to_mail.$subject.$message.$headers.$smtp_host.$smtp_username.$smtp_password;
	
	        //
	        // Fix any bare linefeeds in the message to make it RFC821 Compliant.
	        //
	        $message = preg_replace("/(?<!\r)\n/si", "\r\n", $message);
	   /*echo "SMTP_HOST".$smtp_host;
	   echo "<br>\nSMTP_USER".$smtp_user;
	   echo "<br>\nSMTP_PW".$smtp_password;
	   echo "<br>\nADMIN".$admin_email; */
	
	        if ($headers != "")
	        {
	                if(is_array($headers))
	                {
	                        if(sizeof($headers) > 1)
	                        {
	                                $headers = join("\r\n", $headers);
	                        }
	                        else
	                        {
	                                $headers = $headers[0];
	                        }
	                }
	                $headers = chop($headers);
	
	                //
	                // Make sure there are no bare linefeeds in the headers
	                //
	                $headers = preg_replace("/(?<!\r)\n/si", "\r\n", $headers);
	                //
	                // Ok this is rather confusing all things considered,
	                // but we have to grab bcc and cc headers and treat them differently
	                // Something we really didn't take into consideration originally
	                //
	                $header_array = explode("\r\n", $headers);
	                @reset($header_array);
	                $headers = "";
	                $cc = '';
	                $bcc = '';
	                while( list(, $header) = each($header_array) )
	                {
	                        if( preg_match("/^cc:/si", $header) )
	                        {
	                                $cc = preg_replace("/^cc:(.*)/si", "\\1", $header);
	                        }
	                        else if( preg_match("/^bcc:/si", $header ))
	                        {
	                                $bcc = preg_replace("/^bcc:(.*)/si", "\\1", $header);
	                                $header = "";
	                        }
	                        $headers .= $header . "\r\n";
	                }
	                $headers = chop($headers);
	                $cc = explode(",", $cc);
	                $bcc = explode(",", $bcc);
	        }
	
	
	        if(trim($mail_to) == "")
	        {
	                exit();
	        }
	        if(trim($subject) == "")
	        {
	                die("No email Subject specified");
	        }
	
	        $mail_to_array = explode(",", $mail_to);
	
	        //
	        // Ok we have error checked as much as we can to this point let's get on
	        // it already.
	        //
	        if( !$socket = fsockopen($smtp_host, 25, $errno, $errstr, 20) )
	        {
	                die("Could not connect to smtp host : $errno : $errstr");
	        }
	        $this -> server_parse($socket, "220");
	
	        if( !empty($smtp_username) && !empty($smtp_password) )
	        {
	                // Send the RFC2554 specified EHLO.
	                // This improved as provided by SirSir to accomodate
	                // both SMTP AND ESMTP capable servers
	                fputs($socket, "EHLO " . $smtp_host . "\r\n");
	                $this -> server_parse($socket, "250");
	
	                fputs($socket, "AUTH LOGIN\r\n");
	                $this -> server_parse($socket, "334");
	                fputs($socket, base64_encode($smtp_username) . "\r\n");
	                $this-> server_parse($socket, "334");
	                fputs($socket, base64_encode($smtp_password) . "\r\n");
	                $this -> server_parse($socket, "235");
	        }
	        else
	        {
	                // Send the RFC821 specified HELO.
	                fputs($socket, "HELO " . $smtp_host . "\r\n");
	                $this -> server_parse($socket, "250");
	        }
	
	        // From this point onward most server response codes should be 250
	        // Specify who the mail is from....
	        fputs($socket, "MAIL FROM: <" . $admin_email . ">\r\n");
	        $this -> server_parse($socket, "250");
	
	        // Specify each user to send to and build to header.
	        $to_header = "To: ";
	        @reset( $mail_to_array );
	        while( list( , $mail_to_address ) = each( $mail_to_array ))
	        {
	                //
	                // Add an additional bit of error checking to the To field.
	                //
	                $mail_to_address = trim($mail_to_address);
	                if ( preg_match('/[^ ]+\@[^ ]+/', $mail_to_address) )
	                {
	                        fputs( $socket, "RCPT TO: <$mail_to_address>\r\n" );
	                        $this -> server_parse( $socket, "250" );
	                }
	                $to_header .= "<$mail_to_address>, ";
	        }
	        // Ok now do the CC and BCC fields...
	        @reset( $bcc );
	        while( list( , $bcc_address ) = each( $bcc ))
	        {
	                //
	                // Add an additional bit of error checking to bcc header...
	                //
	                $bcc_address = trim( $bcc_address );
	                if ( preg_match('/[^ ]+\@[^ ]+/', $bcc_address) )
	                {
	                        fputs( $socket, "RCPT TO: <$bcc_address>\r\n" );
	                        $this -> server_parse( $socket, "250" );
	                }
	        }
	        @reset( $cc );
	        while( list( , $cc_address ) = each( $cc ))
	        {
	                //
	                // Add an additional bit of error checking to cc header
	                //
	                $cc_address = trim( $cc_address );
	                if ( preg_match('/[^ ]+\@[^ ]+/', $cc_address) )
	                {
	                        fputs($socket, "RCPT TO: <$cc_address>\r\n");
	                        $this -> server_parse($socket, "250");
	                }
	        }
	        // Ok now we tell the server we are ready to start sending data
	        fputs($socket, "DATA\r\n");
	
	        // This is the last response code we look for until the end of the message.
	        $this -> server_parse($socket, "354");
	
	        // Send the Subject Line...
	        fputs($socket, "Subject: $subject\r\n");
	
	        // Now the To Header.
	        fputs($socket, "$to_header\r\n");
	
	        // Now any custom headers....
	        fputs($socket, "$headers\r\n\r\n");
	
	        // Ok now we are ready for the message...
	        fputs($socket, "$message\r\n");
	
	        // Ok the all the ingredients are mixed in let's cook this puppy...
	        fputs($socket, ".\r\n");
	        $this -> server_parse($socket, "250");
	
	        // Now tell the server we are done and close the socket...
	        fputs($socket, "QUIT\r\n");
	        fclose($socket);
	
	        return TRUE;
	}
	public function SendMailSMTP($frommail,$tomail,$subject,$message,$fromfullname="Sindre Design")
	{
	
	
	      $from= $fromfullname." <".$frommail.">";
	      $headers ="Return-Path: ".$fromfullname." <".$frommail.">\r\n";
	      $headers.="From: $from\nX-Mailer: ".$fromfullname."\r\n";
	      $headers .="Mime-Version: 1.0\r\n";
	      $headers .="Content-type: text/html; charset=utf-8\r\n";
	      $smtp_host ='minhluat.net';//Dia chi mail server
	      $admin_email = 'support@minhluat.net';//User duoc khai bao tren mail server
	      $smtp_username = 'support@minhluat.net';//User duoc khai bao tren mail server
	      $smtp_password = 'g4;NWG#MHJic';//Pass cua email nay
	      $result = $this -> smtpmail($tomail,$subject,$message,$headers,$smtp_host, $smtp_username, $smtp_password,  $admin_email);
	
	}
	
	//Test send mail
	// SendMail("support@pavietnam.com","support@pavietnam.com","Details of Booking Form","Content Testing");							
								
}	
?>