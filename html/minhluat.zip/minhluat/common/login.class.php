<?php
/*
@Author : Nguyen Dang Hien
@Class  : login.class.php
@Description : all login information
*/
class loginClass extends sessionClass {				
	//variable
		
	//construct and destruct
	public function __construct() {		
		parent::__construct() ;
	}
	
	public function __destruct() {		
		parent::__destruct() ;
	}
	
	public function __toString() {
		return get_class(__CLASS__) ;
	}
	function __wakeup()
	{
  		$class = get_class($this);
  		new $class;
	}	
	public function getAll($key) {
		$array = array() ;
		$string = $this->getKey($key) ;					
		$array = explode(">>>",$string) ;
		return $array ;
	}
	
	public function isLogin($key) {
		$array = $this->getAll($key) ;		
		if((count($array)>0)&&(!empty($array[0]))){			
			return true ;
		}
		return false ;
	}	
	
	public function getID($key) {
		if($this->isLogin($key)) {
			$array = $this->getAll($key) ;
			return $array[0] ;
		}
		return "" ;
	}
			
	public function getUserName($key) {
		if($this->isLogin($key)) {
			$array = $this->getAll($key) ;
			return $array[1] ;
		}
		return "" ;
	}
		
	public function getPassword($key) {
		if($this->isLogin($key)) {
			$array = $this->getAll($key) ;
			return $array[2] ;
		}
		return "" ;
	}
	
	public function getLastLogin($key) {
		if($this->isLogin($key)) {
			$array = $this->getAll($key) ;
			return $array[3] ;
		}
		return "" ;
	}
	
	public function getEmail($key) {
		if($this->isLogin($key)) {
			$array = $this->getAll($key) ;
			return $array[4] ;
		}
		return "" ;
	}	
	
	public function getIsAdmin($key) {
		if($this->isLogin($key)) {
			$array = $this->getAll($key) ;
			return $array[5] ;
		}
		return "" ;
	}	
	public function getLastIp($key) {
		if($this->isLogin($key)) {
			$array = $this->getAll($key) ;
			return $array[6] ;
		}
		return "" ;
	}	
	
	public function getAll_sogun() {
		$array = array() ;
		$string = $this->getKey("adminlogin") ;					
		$array = explode(">>>",$string) ;
		return $array ;
	}
	
	public function isLogin_sogun() {
		$array = $this->getAll_sogun() ;		
		if((count($array)>0)&&(!empty($array[0]))){
			return true ;
		}
		return false ;
	}	
	
	
}
?>