﻿var isIE = (navigator.userAgent.indexOf('MSIE') != -1);
if (window.parent!=window)
 { 
  alert('Trang web ban dang vao khong phai la website chinh thuc cua Tuoi Tre. Tuoi Tre khong chiu trach nhiem ve tinh chinh xac cua thong tin cung do an toan cua trang web nay.\r\nVui long nhan OK de quay lai trang chinh thuc www.tuoitre.com.vn');
  window.open(location.href, '_top', '');
 }
 
// channelSampleToday.ascx
function boldStr( srcStr,splitStr )
{
	var splitPosition = srcStr.indexOf(splitStr);
	
	if (splitPosition != -1)
	{		
		var lastIndex = srcStr.lastIndexOf(' ');				
		var stop = srcStr.charAt(lastIndex+1);
		while( stop != '' )
		{
			lastIndex++;
			stop = srcStr.charAt(lastIndex);
		}		
		
		var firstStr = srcStr.substring(0, splitPosition);		
		var lastStr = srcStr.substring(splitPosition, lastIndex);		
		srcStr = "<b>" + firstStr + "</b>" + lastStr;				
	}
	
	document.write(srcStr);			
}

//Media
//function changeSource( strSource )
//{
	//media = document.getElementById("winMediaPlayerID");
	//media.URL = strSource;
//}

function switchVisible(ctrl)
{
	if (ctrl.style.display == "inline")
		ctrl.style.display = "none";
	else
		ctrl.style.display = "inline";
}

function AboutVietAd()
{
	alert("mailto:" + "contact" + "@" + "vietad.vn");
}

function fixChannelVieclamUrl()
{
	var links = document.getElementsByTagName("a"); 
	var tagNum = links.length; 
	var hrefStr = "";
	
	for(i = 0; i < tagNum; i++)
	{                        
		hrefStr = links[i].href;		
		if ( hrefStr == 'http://www.tuoitre.com.vn/Tianyon/Index.aspx?ChannelID=269' )
		{
		    links[i].target="_blank";
			links[i].href = 'http://vieclam.tuoitre.com.vn'; 
		} 
	} 
}

function fixChannelUrl(channelID, findwhat, replacewith)
{
	var links = document.getElementsByTagName("a"); 
	var tagNum = links.length; 
	var hrefStr = "";
	var index = -1; 
	
	var currentChannel = GetPostVariable("ChannelID", -1);
	var currentURL = window.location.href + "&";	
	currentURL = currentURL.toLowerCase(); 
	index = currentURL.indexOf("/tianyon/");	
	if((currentChannel == channelID)  && (index != -1))
	{
		index = currentURL.indexOf("channelid="+channelID+"&", 0); 
		if (index != -1)
		{
			window.location.href = window.location.href.replace(findwhat, replacewith); 			
		} 
		return;
	}
	
	for(i = 0; i < tagNum; i++)
	{                        
		hrefStr = links[i].href + "&";
		
		hrefStr=hrefStr.toLowerCase(); 		
			
		index = hrefStr.indexOf("channelid="+channelID+"&", 0); 
	    if (index != -1)
		{			
			links[i].href = links[i].href.replace(findwhat, replacewith); 
			
			if(   (channelID != 434) && (channelID != 435) && (channelID != 437) && (channelID != 441)
			   && (channelID != 440) && (channelID != 439) && (channelID != 438) && (channelID != 436))
			{
				links[i].target="_blank";
			}
		} 
	} 
} 

function onBodyLoad() 
{    
	fixChannelUrl(142, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Tuyensinh");
	fixChannelUrl(224, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Tuyensinh");
	fixChannelUrl(230, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Tuyensinh");
	fixChannelUrl(101, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Tuyensinh");
	fixChannelUrl(222, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Tuyensinh");
	fixChannelUrl(183, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Tuyensinh");
	fixChannelUrl(225, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Tuyensinh");
	//fixChannelUrl(227, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Tuyensinh");
	fixChannelUrl(228, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Tuyensinh");
	fixChannelUrl(229, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Tuyensinh");
	
	//fixChannelUrl(150, /Tianyon/gi, "thethao");
	fixChannelUrl(14,  /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");
	fixChannelUrl(4,   /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");
	fixChannelUrl(248, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");
	fixChannelUrl(249, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");	
	fixChannelUrl(251, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");
	fixChannelUrl(146, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");
	fixChannelUrl(247, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");
	fixChannelUrl(246, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");
	fixChannelUrl(5,   /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");	
	fixChannelUrl(254, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");
	fixChannelUrl(252, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");
	fixChannelUrl(260, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");
	fixChannelUrl(267, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");
	fixChannelUrl(250, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/thethao");
	
	fixChannelVieclamUrl();
	fixChannelUrl(269, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Vieclam");		
	fixChannelUrl(270, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Vieclam");
	fixChannelUrl(271, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Vieclam");
	fixChannelUrl(272, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Vieclam");
	fixChannelUrl(273, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Vieclam");
	fixChannelUrl(274, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Vieclam");
	fixChannelUrl(275, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Vieclam");
	fixChannelUrl(276, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Vieclam");
	
	fixChannelUrl(279, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames23");
	fixChannelUrl(281, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames23");
	fixChannelUrl(282, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames23");
	fixChannelUrl(283, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames23");
	fixChannelUrl(284, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames23");
	fixChannelUrl(285, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames23");
	fixChannelUrl(286, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames23");
	
	fixChannelUrl(212, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TetOnline2008");
	fixChannelUrl(338, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TetOnline2008");
	fixChannelUrl(207, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TetOnline2008");	
	
	fixChannelUrl(352, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/worldcup2006");
	fixChannelUrl(353, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/worldcup2006");
	fixChannelUrl(354, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/worldcup2006");
	fixChannelUrl(355, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/worldcup2006");
	fixChannelUrl(356, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/worldcup2006");
	fixChannelUrl(357, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/worldcup2006");
	fixChannelUrl(358, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/worldcup2006");
	fixChannelUrl(359, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/worldcup2006");

	fixChannelUrl(103, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TTC");
	fixChannelUrl(372, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TTC");
	fixChannelUrl(373, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TTC");
	fixChannelUrl(374, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TTC");
	fixChannelUrl(375, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TTC");
	fixChannelUrl(376, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TTC");
	fixChannelUrl(377, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TTC");
	fixChannelUrl(378, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TTC");
	fixChannelUrl(380, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TTC");
	fixChannelUrl(117, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TTC");	
	fixChannelUrl(116, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/TTC");
	
	fixChannelUrl(204, /www.tuoitre.com.vn\/Tianyon/gi, "diaoc.tuoitre.com.vn/Tianyon");
	fixChannelUrl(240, /www.tuoitre.com.vn\/Tianyon/gi, "diaoc.tuoitre.com.vn/Tianyon");
	fixChannelUrl(450, /www.tuoitre.com.vn\/Tianyon/gi, "diaoc.tuoitre.com.vn/Tianyon");
	fixChannelUrl(451, /www.tuoitre.com.vn\/Tianyon/gi, "diaoc.tuoitre.com.vn/Tianyon");
	fixChannelUrl(452, /www.tuoitre.com.vn\/Tianyon/gi, "diaoc.tuoitre.com.vn/Tianyon");	
	fixChannelUrl(368, /www.tuoitre.com.vn\/Tianyon/gi, "diaoc.tuoitre.com.vn/Tianyon");
	
	fixChannelUrl(482, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames24");
	fixChannelUrl(488, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames24");
	fixChannelUrl(487, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames24");
	fixChannelUrl(489, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames24");
	fixChannelUrl(491, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames24");
	fixChannelUrl(490, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames24");
	fixChannelUrl(492, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/Seagames24");
	
	// Bau chon
	fixChannelUrl(458, /www.tuoitre.com.vn\/Tianyon\/Index.aspx\?ChannelID=458/gi, "bauchon.tuoitre.com.vn");
	fixChannelUrl(458, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/Tianyon");
	fixChannelUrl(464, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/Tianyon");
	fixChannelUrl(465, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/Tianyon");
	fixChannelUrl(459, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/Tianyon");
	fixChannelUrl(460, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/Tianyon");
	fixChannelUrl(461, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/Tianyon");
	fixChannelUrl(466, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/Tianyon");
	
	// Bau chon English
	fixChannelUrl(462, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonE");
	fixChannelUrl(467, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonE");
	fixChannelUrl(468, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonE");	
	fixChannelUrl(469, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonE");
	fixChannelUrl(470, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonE");
	fixChannelUrl(471, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonE");
	fixChannelUrl(472, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonE");	
	
	// Bau chon English
	fixChannelUrl(463, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonF");
	fixChannelUrl(473, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonF");
	fixChannelUrl(474, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonF");
	fixChannelUrl(475, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonF");	
	fixChannelUrl(476, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonF");
	fixChannelUrl(477, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonF");
	fixChannelUrl(478, /www.tuoitre.com.vn\/Tianyon/gi, "bauchon.tuoitre.com.vn/TianyonF");	
	
	//EURO2008;
	fixChannelUrl(512, /www.tuoitre.com.vn\/Tianyon\/Index.aspx\?ChannelID=512/gi, "www3.tuoitre.com.vn/EURO2008/");
	fixChannelUrl(512, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/EURO2008");
	fixChannelUrl(514, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/EURO2008");
	fixChannelUrl(515, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/EURO2008");
	fixChannelUrl(517, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/EURO2008");	
	fixChannelUrl(518, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/EURO2008");
	fixChannelUrl(519, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/EURO2008");
	fixChannelUrl(520, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/EURO2008");
	fixChannelUrl(522, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/EURO2008");
	fixChannelUrl(523, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/EURO2008");	
	fixChannelUrl(524, /www.tuoitre.com.vn\/Tianyon/gi, "www3.tuoitre.com.vn/EURO2008");
			
	fixChannelUrl(278, /www.tuoitre.com.vn/gi, "media.tuoitre.com.vn?");
		
	fixChannelUrl(371, /www.tuoitre.com.vn\/Tianyon\/Index.aspx\?ChannelID=371/gi, "www3.tuoitre.com.vn/Tusach");
	fixChannelUrl(371, /www.tuoitre.com.vn\/Tianyon\/Index.aspx/gi, "www3.tuoitre.com.vn/Tusach/ArticleView.aspx");
	fixChannelUrl(446, /www.tuoitre.com.vn\/Tianyon\/Index.aspx/gi, "www3.tuoitre.com.vn/Tusach/ArticleList.aspx");
	//fixChannelUrl(172, /www.tuoitre.com.vn\/Tianyon\/Index.aspx/gi, "www3.tuoitre.com.vn/Tusach/ArticleList.aspx");

	fixChannelUrl(401, "www.tuoitre.com.vn/Tianyon/Index.aspx?ChannelID=401", "www3.tuoitre.com.vn/TetOnline2008/");	
	fixChannelUrl(401, /www.tuoitre.com.vn\/Tianyon\/Index.aspx/gi, "www3.tuoitre.com.vn/TetOnline2008/");

	fixChannelUrl(443, /www.tuoitre.com.vn\/Tianyon\/Index.aspx\?ChannelID=443/gi, "ecard.tuoitre.com.vn");
	
	fixChannelUrl(444, /www.tuoitre.com.vn\/Tianyon\/Index.aspx\?ChannelID=444/gi, "www.tuoitre.com.vn/games/index.htm");
	
	fixChannelUrl(447, /www.tuoitre.com.vn\/Tianyon\/Index.aspx\?ChannelID=447/gi, "phapluat.tuoitre.com.vn");

    // Fix Menu Level1
    fixChannelUrl(434, /\/Index.aspx\?ChannelID=434/gi, "/Index.aspx?ChannelID=3");
    fixChannelUrl(435, /\/Index.aspx\?ChannelID=435/gi, "/Index.aspx?ChannelID=2");
    fixChannelUrl(445, /www.tuoitre.com.vn\/Tianyon\/Index.aspx\?ChannelID=445/gi, "www3.tuoitre.com.vn/thethao");
    fixChannelUrl(441, /\/Index.aspx\?ChannelID=441/gi, "/Index.aspx?ChannelID=13");
    fixChannelUrl(440, /\/Index.aspx\?ChannelID=440/gi, "/Index.aspx?ChannelID=17");
    fixChannelUrl(439, /\/Index.aspx\?ChannelID=439/gi, "/Index.aspx?ChannelID=16");
    fixChannelUrl(438, /\/Index.aspx\?ChannelID=438/gi, "/Index.aspx?ChannelID=11");
    fixChannelUrl(436, /\/Index.aspx\?ChannelID=436/gi, "/Index.aspx?ChannelID=10");
    fixChannelUrl(437, /\/Index.aspx\?ChannelID=437/gi, "/Index.aspx?ChannelID=7");
    
    fixChannelUrl(100, "www.tuoitre.com.vn/Tianyon/Index.aspx?ChannelID=100", "dulich.tuoitre.com.vn");	
	fixChannelUrl(100, /www.tuoitre.com.vn/gi, "dulich.tuoitre.com.vn");



 	//setTimeout("location.reload()", timeoutMinute * 60000);
 	//if (location.search=='') showWindow('/Advertisement/thongbao.htm', false, false, false, false, false, false, true, false, 215, 202, 50, 575);
 	
 	setTimeout("ReloadPage()", 600000);
 }
 
 function ReloadPage()
{
	setTimeout("ReloadPage()", 600000);
	if((GetPostVariable("ArticleID", "-1")!="-1")||(GetPostVariable("ContactID", "-1")!="-1"))
	{
		return;
	}
	else
	{
		location.reload();
	}
}

function utf8(wide) {
  var c, s;
  var enc = "";
  var i = 0;
  while(i<wide.length) {
    c= wide.charCodeAt(i++);
    // handle UTF-16 surrogates
    if (c>=0xDC00 && c<0xE000) continue;
    if (c>=0xD800 && c<0xDC00) {
      if (i>=wide.length) continue;
      s= wide.charCodeAt(i++);
      if (s<0xDC00 || c>=0xDE00) continue;
      c= ((c-0xD800)<<10)+(s-0xDC00)+0x10000;
    }
    // output value
    if (c<0x80) enc += String.fromCharCode(c);
    else if (c<0x800) enc += String.fromCharCode(0xC0+(c>>6),0x80+(c&0x3F));
    else if (c<0x10000) enc += String.fromCharCode(0xE0+(c>>12),0x80+(c>>6&0x3F),0x80+(c&0x3F));
    else enc += String.fromCharCode(0xF0+(c>>18),0x80+(c>>12&0x3F),0x80+(c>>6&0x3F),0x80+(c&0x3F));
  }
  return enc;
}

var hexchars = "0123456789ABCDEF";

function toHex(n) 
{
  return hexchars.charAt(n>>4)+hexchars.charAt(n & 0xF);
}

var okURIchars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-";

function encodeURIComponentNew(s) 
{
  var s = utf8(s);
  var c;
  var enc = "";
  for (var i= 0; i<s.length; i++) {
    if (okURIchars.indexOf(s.charAt(i))==-1)
      enc += "%"+toHex(s.charCodeAt(i));
    else
      enc += s.charAt(i);
  }
  return enc;
}

function buildURL(fld)
{
	if (typeof encodeURIComponent == "function")
	{
		// Use JavaScript built-in function
		// IE 5.5+ and Netscape 6+ and Mozilla
		return encodeURIComponent(fld);
	}
	else 
	{
		// Need to mimic the JavaScript version
		// Netscape 4 and IE 4 and IE 5.0
		return encodeURIComponentNew(fld);
	}
}

function destroyURL(fld)
{
	if (typeof decodeURIComponent == "function")
	{
		// Use JavaScript built-in function
		// IE 5.5+ and Netscape 6+ and Mozilla
		return decodeURIComponent(fld);
	}
	else 
	{
		// Need to mimic the JavaScript version
		// Netscape 4 and IE 4 and IE 5.0
		return "Tìm kiếm";
	}
}

function moveCalendar(offset)
{
	var currentDate = new Date();

	var dateString = GetPostVariable('Date', '');
	if (dateString != '')
	{
		var dateElements = dateString.split('-');
		var t = dateElements[0];
		dateElements[0] = dateElements[1];
		dateElements[1] = t;
		currentDate = new Date(dateElements.join('-'));
		
	}
	currentDate = new Date(currentDate.setDate(currentDate.getDate() + offset));
	dateString = currentDate.getDate() + '-' + (currentDate.getMonth() + 1) + '-' + currentDate.getYear();
	
	location.search = 'ChannelID=' + GetPostVariable('ChannelID', 1) + '&Date=' + dateString;
}

function showImage(url)
{
	showDialog('ImageView.htm?' + url.substr(url.indexOf('?') + 1), 524, 524);
}

function showDialog(url, width, height)
{
	return showWindow(url, false, false, false, false, false, false, true, true, width, height, 0, 0);
}

function showWindow(url, isStatus, isResizeable, isScrollbars, isToolbar, isLocation, isFullscreen, isTitlebar, isCentered, width, height, top, left)
{
	if (isCentered)
	{
		top = (screen.height - height) / 2;
		left = (screen.width - width) / 2;
	}

	open(url, '_blank', 'status=' + (isStatus ? 'yes' : 'no') + ','
	+ 'resizable=' + (isResizeable ? 'yes' : 'no') + ','
	+ 'scrollbars=' + (isScrollbars ? 'yes' : 'no') + ','
	+ 'toolbar=' + (isToolbar ? 'yes' : 'no') + ','
	+ 'location=' + (isLocation ? 'yes' : 'no') + ','
	+ 'fullscreen=' + (isFullscreen ? 'yes' : 'no') + ','
	+ 'titlebar=' + (isTitlebar ? 'yes' : 'no') + ','
	+ 'height=' + height + ',' + 'width=' + width + ','
	+ 'top=' + top + ',' + 'left=' + left);
}

function writeTime(s)
{
	var mydate=new Date(s)
	
	var year = mydate.getYear()
	if (year < 1000)
		year += 1900
	var month = mydate.getMonth() + 1
	if (month < 10)
		month = "0" + month
	var day = mydate.getDate()
	if (day < 10)
		day = "0" + day

	var dayw = mydate.getDay()
	
	var hour = mydate.getHours()
	if (hour < 10)
		hour = "0" + hour
	
	var minute=mydate.getMinutes()
	if (minute < 10)
		minute = "0" + minute
	var dayarray=new Array("Chủ  nhật","Thứ hai","Thứ ba","Thứ tư","Thứ năm","Thứ sáu","Thứ bảy")
	document.write(dayarray[dayw]+", ngày "+day+" tháng "+month+" năm "+year +"&nbsp;&nbsp; "+hour+":"+minute+" (GMT+7)")
}

function getTimeString(s)
{
	document.write("<span class=LargeTime2>");
	writeTime(s);
	document.write("</span>")
}

function Trim(s)
{
    var i = 0;
    while ((i < s.length) && (s.charCodeAt(i) == 32))
	    i++;

    var j = s.length - 1;
    while ((j > i) && (s.charCodeAt(j) == 32))
	    j--;

    return s.substr(i, j - i + 1);
}

function GetPostVariable(param, defval)
{
	param = param.toLowerCase();  

	var	s = '&' + location.search.substr(1).toLowerCase(); 
	
	//var	s = '&' + location.search.substr(1);
	
	var	i = s.indexOf('&' + param + '=');
	if (i == -1) return defval;

	s = s.substr(i + param.length + 2);
	i = s.indexOf('&');
	if (i == -1) return s;

	return s.substr(0, i);
}

function DisplaySearchPage(PageCount)
{
    document.write('Trang ');
    j = GetPostVariable('SearchPage', 1);
    for (i = 1; i <= PageCount; i++)
	    if (i != j)
		    document.write('<a class="SearchPage" href=index.aspx?SearchQuery=' + GetPostVariable('SearchQuery', 'Error') + '&SearchPage=' + i + '>' + i + '&nbsp;</a>');
	    else
		    document.write('[' + i + ']&nbsp;');
    i = parseInt(j) + 1;
    if (j < PageCount)
	    document.write('&nbsp;<a class="SearchPage" href=index.aspx?SearchQuery=' + GetPostVariable('SearchQuery', 'Error') + '&SearchPage=' + i + '>Xem ti&#7871;p&nbsp;</a>');
}

function onLinkClick(link)
{
    if (isIE)	//Mozilla and FireFox don't support non-standard attribute
    {	
	    window.open(link.href, '', 
	    'toolbar='+link.toolbar+
	    ',location='+link.location+
	    ',status='+link.statusbar+
	    ',menubar='+link.menubar+
	    ',scrollbars='+link.scrollbars+
	    ',resizable='+link.resizable+
	    ',width='+link.width+
	    ',height='+link.height+
	    ',top='+link.top+
	    ',left='+link.left);
	    return false;
    }
    else{
	    window.open(link.href, 'name', 'height=800, width=1200, left=0, top=0, resizable=yes, scrollbars=yes, toolbar=yes, status=yes');
	    return false;
    }
}

function onLinkClickFull(link)
{
    if (isIE)	//Mozilla and FireFox don't support non-standard attribute
    {	
	    window.open(link.href, '', 
	    'toolbar='+link.toolbar+
	    ',location='+link.location+
	    ',status='+link.statusbar+
	    ',menubar='+link.menubar+
	    ',scrollbars= yes'+
	    ',resizable= yes'+
	    ',width= 770' +
	    ',height= 1000' +
	    ',top='+link.top+
	    ',left='+link.left);
	    return false;
    }
}

function displayInfo(info)
{
	if (info == 'weather')
		showDialog('http://www3.tuoitre.com.vn/transweb/rams.htm', 492, 659);
	if (info == 'forex')	
	    showDialog('http://www.tuoitre.com.vn/tianyon/transweb/TyGia.htm', 305, 415);
	    //showDialog('http://www.eximbank.com.vn/vietnam/exchange.aspx', 460, 432);
		//showDialog('http://www3.tuoitre.com.vn/transweb/tygia.htm', 460, 432);
	if (info == 'gold')
		showDialog('http://www3.tuoitre.com.vn/transweb/giavang.htm', 450, 220);
	if (info == 'tvguide')
		showWindow('http://www3.tuoitre.com.vn/transweb/truyenhinh.htm', false, false, true, false, false, false, true, true, 450, 354, 0, 0);
	if (info == 'lottery')	
	    showDialog('http://www.tuoitre.com.vn/tianyon/transweb/xoso.htm', 400, 665);
	    //showWindow('http://www.xosobinhduong.com.vn/Forms/xemkq_tt.aspx', false, false, true, false, false, false, true, true, 450, 600, 0, 0);
		//showWindow('http://www3.tuoitre.com.vn/Transweb/XoSo.html', false, false, true, false, false, false, true, true, 450, 600, 0, 0);
		//showDialog('http://www3.tuoitre.com.vn/transweb/xoso.htm', 600, 346);
		//showDialog('http://www.xsktcantho.com.vn/xsktcantho.asp', 1024, 1350);
	if (info == 'stock_ho')
		showWindow('http://www3.tuoitre.com.vn/transweb/chungkhoan_ho.htm', false, false, true, false, false, false, true, true, 770, 770);
	if (info == 'stock_ha')
		showWindow('http://www3.tuoitre.com.vn/transweb/chungkhoan_ha.htm', false, false, true, false, false, false, true, true, 770, 770);	
}

function setHomePage(ctrl)
{
	ctrl.style.behavior='url(#default#homepage)';
	ctrl.setHomePage(location.host);
}

function switchDisplay(id)
{
	ctrl = document.getElementById(id);
	if (ctrl.style.display == "")
		ctrl.style.display = "none";
	else
		ctrl.style.display = "";
}

function onCmdSearchClick(SearchQuery)
{
	//var q = Trim(document.SearchSubmit.SearchQuery.value);
	
	var q = Trim(SearchQuery.value);
	
	if (q == '')
		return false;
		
	if ((q.indexOf('AND') == -1) && (q.indexOf('OR') == -1) && (q.indexOf('"') == -1))
		q = '"' + q + '"';
	
	
	SearchQuery.value = q;
	
	//document.SearchSubmit.SearchQuery.value = q;
	
	return true;
}


function DisplayBrowserTitle()
{
	var oContent = document.getElementById("divContent");
	
	var arrayTag = oContent.getElementsByTagName("P");
	
	for (var i = 0; i < arrayTag.length; i++)
	{
		if (arrayTag[i].className == "pTitle")
		{
			var sTitle = arrayTag[i].innerHTML;
			
			// Remove all tag			
			while(true)
			{
				if (sTitle.indexOf("<") == -1 || sTitle.indexOf(">") == -1)
				{
					break;
				}
				var startIndex = sTitle.indexOf("<");
				var endIndex = sTitle.indexOf(">");
				var sRemoval = sTitle.substring(startIndex, endIndex + 1);
				sTitle = sTitle.replace(sRemoval, "");
			}
			break;
		}
	}
	
	document.title = document.title + " - " + sTitle;
}

/***********************************
            String Cut
************************************/
function cutStrExper( head, length )
{
    if(head == "?")
    {
        document.write("");
		return;
    }
        
   	var strLen = head.length;
	if (strLen > length)
	{
		head = head.substr(0, length+5) ;
		
		var lastIndexOfSpace = head.lastIndexOf(' ');
		
		if (lastIndexOfSpace > 0)
        {
            head = head.substr(0, lastIndexOfSpace) ;
        }
        else 
        {
            head = head.substr(0, length) ;
        }
		
		document.write(head + " ...");
		return;
	}
	else
	{
		document.write(head);		
	}		
}

String.prototype.TrimS = function() 
{ 
    var reg = new RegExp("(^(\\s|" + String.fromCharCode(12288) + ")*)|((\\s|" + String.fromCharCode(12288) + ")*$)", "g");
    //var reg = /(^\s*)|(\s*$)/g;
    
    return this.replace(reg, ""); 
}

/***********************************************************************************
Name: normalizeSpace(head)

Arguments: head, a string that is converted.

Descriptions: Returns the whitespace-normalized version of the argument string; 
                all leading and trailing whitespace gets stripped 
                and any sequences of whitespace characters 
                within the argument string get combined to one single space.

Composer: Namhh.   

Ex: head = "  test    text   "; 
    normalizeSpace(head) would rerurn: "test text".
************************************************************************************/
function normalizeSpace(head)
{
    
    // strim string.
    var trimedHead = head.TrimS();
      
    // regular expressions, for replacing sequences of whitespace characters within input-string.
    var pattern = "/ {2,}/"; 
    
    // whitespace charater.
    var replacement = " ";
    
    return trimedHead.replace(pattern, replacement);  
}

function cutStr1( head, length )
{
    // Normallie Space characters of string.
    var normalizedHead = normalizeSpace(head);
    
    // If head is empty.
    if((head == "?")||(normalizedHead == ""))
    {
        document.write("");
		return;
    }
    
    var pattern1 = new RegExp('\'', 'g');
     
    normalizedHead = normalizedHead.replace(pattern1,'"');
   	  	
   	// Get head's length.
   	var strLen = normalizedHead.length;
   	
   	// Head Processing.
	if (strLen < length)
	{
	    document.write(normalizedHead);
	}
	else
	{
	    
	    var tempHead = normalizedHead.substr(0, (length -4));
	    
	    var lastIndexOfSpace = tempHead.lastIndexOf(' ');
	    
	    var outHead = tempHead.substr(0, lastIndexOfSpace);
	    
	    outHead = outHead + " ..."
	    
	    document.write(outHead);
	    
	    return;
	}
}

//Function load ArticleNew, ArticleRank, ArticleToday
function ChangeIndexArticle(value)
{    
    var values = value.split("_");
    var url = "/Tooltip/Ajax/" + values[0] + ".aspx";  
//    
//    for(var i = 1; i<4; i++)
//    {
//        if(document.getElementById('article' + i))
//        {
//            if(values[1] == i)
//            {
//                document.getElementById('article' + i).className = 'articleSelected';  
//                document.getElementById('a_article' + i).className = 'linkMenu';  
//            }else
//            {
//                document.getElementById('article' + i).className = 'articleUnSelected';  
//                document.getElementById('a_article' + i).className = 'linkMenuActive';  
//            }
//        }else
//        {
//            break;
//        }
//    }
                
    ajax_loadContent('showContent', url);
}

function getElementsByClassName(oElm, strTagName, oClassNames)
{
    var arrElements = (strTagName == "*" && oElm.all)? oElm.all : oElm.getElementsByTagName(strTagName);
    var arrReturnElements = new Array();
    var arrRegExpClassNames = new Array();
    if(typeof oClassNames == "object")
    {
        for(var i=0; i<oClassNames.length; i++)
        {
            arrRegExpClassNames.push(new RegExp("(^|\\s)" + oClassNames[i].replace(/\-/g, "\\-") + "(\\s|$)"));
        }
    }
    else
    {
        arrRegExpClassNames.push(new RegExp("(^|\\s)" + oClassNames.replace(/\-/g, "\\-") + "(\\s|$)"));
    }
    
    var oElement;
    var bMatchesAll;    
    for(var j=0; j<arrElements.length; j++)
    {
        oElement = arrElements[j];
        bMatchesAll = true;
        for(var k=0; k<arrRegExpClassNames.length; k++)
        {
            if(!arrRegExpClassNames[k].test(oElement.className))
            {
	            bMatchesAll = false;
	            break;
            }
        }
        if(bMatchesAll)
        {
            arrReturnElements.push(oElement);
        }
    }
    return (arrReturnElements)
}

function SetHeightForBox(divId,className)
{
     var divs = getElementsByClassName(document.getElementById(divId),"div",className);
     var maxHeight = 0;
     for(var i=0; i < divs.length; i++) 
     {
           if(divs[i].offsetHeight > maxHeight) maxHeight = divs[i].offsetHeight;
     }
     for(var i=0; i < divs.length; i++) 
     {
           if(divs[i].offsetHeight != maxHeight) divs[i].style.height = maxHeight + "px";
     }
}