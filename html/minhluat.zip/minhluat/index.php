<?php
define('MINHLUAT', true);
//	echo phpinfo();exit;
//LOAD DEFINE
include_once("common/define.class.php") ;
//LOAD MD5 CLASS
include_once( MD5_CLASS ) ;
$md5Class = new md5Class() ;

//CONTROL GO TO PAGE
// $action = "home" ;
$action_cache = "./" ;
if( isset( $_REQUEST["req"]) && !empty($_REQUEST['req']) ) {		
	$stract = $_REQUEST["req"] ;
	//$action = trim( $md5Class->decode($action) ) ;	
	$action_cache = $_REQUEST["req"] ;
	
	/*$arr = split("/", $_SERVER['REQUEST_URI']);
	$fcontrol = $arr[2] ;
	//$fcontrol = $arr[3] ;
	if(empty($fcontrol) or $fcontrol == '/') {
		$fcontrol = 'index' ;
	}
	$fcontrol = str_replace('.html','',$fcontrol);
	*/
	$arract = split("/", $stract);
	$action = $arract[0] ;
	if(empty($action) or $action == '/') {
		$action = 'home' ;
	}
	//$fcontrol = str_replace('.html','',$fcontrol);
	//echo $act;
	
}
else $action = "home";
// exit($action);

/*
if( empty($action) ) {
	$action = "home" ;
}*/

// exit($action);



if($action == "imagesercurity")			
{			
	ob_end_clean();	
	define('ATN_SYSTEM', true);
	include_once("imagesercur.php") ;
	exit ;
}
try {
	//LOAD CONFIG
	include_once( CONFIG_CLASS ) ;
	$configClass = new configClass() ;
	$configClass->set_php_ini() ;
	//LOAD PDO CLASS
	
	try {		
	    $connect = new PDO( ADODB_DNS , 
	                        ADODB_USER , 
	                        ADODB_PASS ,
	                        array(
	                               PDO::ATTR_PERSISTENT => true
	                             )
	                      );
//	                      echo $connect."__";
	    $connect->setAttribute(
		                      PDO::ATTR_ERRMODE, 
		                      PDO::ERRMODE_EXCEPTION
		                     ) ;
		$connect->setAttribute( PDO::ATTR_AUTOCOMMIT, true ) ;
		$connect->setAttribute( PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true ) ;		
		} 
	
	catch (PDOException $e) {
		exit("not connected!");
	}
	//END PDO CLASS
	//echo $md5Class->encode("divhvu");	
	//LOAD SESSION CLASS
	
	include_once( SESSION_CLASS ) ;
	$sesClass = new sessionClass() ;
	
	//LOAD COMMON CLASS
	include_once( COMMON_CLASS ) ;
	
	$commonClass = new commonClass() ;
	
	//LOAD LOGIN CLASS
	include_once( LOGIN_CLASS ) ;
	$loginClass = new loginClass() ;
	
	include_once ( LOG_CLASS );
	$logClass = new logClass('compiler/log/phuocloc.txt');
	
	// exit("dsadas");
	//////////////////////////////////////////	
	//LOAD LANGUAGE
	
	if($sesClass->getKey("INDEX_LANGUAGE") != "") 
	{						
		if($sesClass->getKey("INDEX_LANGUAGE") == "english") {								
			if(file_exists("compiler/cache/language/english.conf")) include_once("compiler/cache/language/english.conf");	
			if(file_exists("compiler/cache/language/". $action ."/english.conf")) include_once("compiler/cache/language/". $action ."/english.conf") ;
			$flaglang='<img  src=DOCUMENT_ROOT."/images/vn_index.gif"/>';			
			$hdLang = $md5Class->encode("vietnamese") ;
			$isEngLang = true;			
		}
		else {
			$sesClass->setKey("INDEX_LANGUAGE", "vietnam");						
			if(file_exists("compiler/cache/language/vietnamese.conf")) include_once("compiler/cache/language/vietnamese.conf") ;	
			if(file_exists("compiler/cache/language/". $action ."/vietnamese.conf")) include_once("compiler/cache/language/". $action ."/vietnamese.conf") ;				
			$hdLang = $md5Class->encode("english") ;
			$flaglang='<img title="Change to English language" src=DOCUMENT_ROOT."/images/eng_index.gif"/>';
			$isEngLang = false ;
							
		}
	
	}
	else // ngon ngu mac dinh
	{							
			
		if(file_exists("compiler/cache/language/vietnamese.conf"))
		 include_once("compiler/cache/language/vietnamese.conf") ;
		if(file_exists("compiler/cache/language/". $action ."/vietnamese.conf"))
		 include_once("compiler/cache/language/". $action ."/vietnamese.conf") ;
		$flaglang='<img title="Change to English language" src=DOCUMENT_ROOT."//images/eng_index.gif"/>';				
		$hdLang = $md5Class->encode("english") ;	
		$isEngLang = false ;
				
	}	
	
	$link_lang = DOCUMENT_ROOT."/transfer" ;	
	$url_cache = "./?". $_SERVER['QUERY_STRING'] ;
	
	include_once( TEMPLATE_CLASS ) ;
//	$xstl = new templateClass(LINK_HEADER."header.tpl");
	/*$string['flaglang']=$flaglang;
	$string['url_cache'] = $url_cache; 
	$string['linklang'] = $link_lang;
	$string['ngayhientai'] = date("d-m-Y");
	$string['timphuocloc'] = $md5Class->encode("timchuyenxe");
	
	$string['hdLang'] = $hdLang;								 
	$string['lang_name'] = $config["header"]["lang"];	
	//menu header 
	$string['linktrangchu'] = DOCUMENT_ROOT."/trangchu";
	$string['linkvoxe'] = DOCUMENT_ROOT."/voxe";
	$string['linkmamxe'] = DOCUMENT_ROOT."/mamxe";
	$string['linkgioithieu']=DOCUMENT_ROOT."/gioithieu";
	$string['linktintuc'] = DOCUMENT_ROOT."/tintuc";
	$string['linklienhe'] = DOCUMENT_ROOT."/lienhe";
	$string['ngayhientai'] = date("F j, Y, g:i a");
	//kiem tra xem ngay giam gia so voi ngay hien tai con hieu luc hay ko ? 
	$today = time(); 
	//banner 
	$listquangcao2 = $commonClass->getQuangCao($connect, 2, $action);
	$leng_qc2 = sizeof($listquangcao2);  
	if($leng_qc2 > 0)
	{
		$danhsachhinh2 = array();
		$i = 0;
		foreach ($listquangcao2 as $value)
		{
			$array = array(); 
			$ngaybd = $value['qc_batdau']; 
			$ngayhethan = $ngaybd + $value['qc_thoigian']*12*3600;
			if($ngayhethan < $today)
			{
				$array['hinhbanner'] = "";
			}else 
			{
				$array['hinhbanner'] =  $commonClass->showIMG($value['qc_hinh'], 1000, 195);
				$array['linkbanner'] = $value['qc_link'];
			}
			$danhsachhinh2[] = $array;	
			$i++;
		}
		$string['banner'] = $danhsachhinh2;
	}
	//lay tin tuc moi nhat 
	$listtin = $commonClass->getTinmoinhat($connect, 5);
	$leng_tin = sizeof($listtin);  
	if($leng_tin > 0)
	{
		$danhsachtin = array();
		$i = 0;
		foreach ($listtin as $value)
		{
			$array = array(); 
			if($i%2)
				$array['mauchu'] = "FFFFFF";
			else 
				$array['mauchu'] = "FFFF00";
			$array['tieudetin'] = $value['tin_tieude'];
			$array['linkchitiettin'] = DOCUMENT_ROOT."/tintuc/".$md5Class->encode($value['tin_id']); 
			$danhsachtin[] = $array;	
			$i++;
		}
		$string['tinmoinhat'] = $danhsachtin;
	}
	//dang nhap chua ??
	//kiem tra da dang nhap phan quan tri chua? 
	$login_satus = $sesClass->getKey("dangnhapquantri"); 
	if(!empty($login_satus))
	{
		$string['lb_dangnhap'] = "Quản trị";
	}else 
	{
		$string['lb_dangnhap'] = "Đăng nhập";		
	}
	//memu  ngang 
	switch ($action)
	{
		case "lienhe":
			$string['divtrangchu'] = "trangchu";
			$string['divvoxe'] = "voxe";
			$string['divmamxe'] = "mamxe";
			$string['divgioithieu'] = "gioithieu";
			$string['divlienhe'] = "lienhe_choise";
			$string['divtintuc'] = "tintuc";
			break; 
		case "tintuc":
			$string['divtrangchu'] = "trangchu";
			$string['divvoxe'] = "voxe";
			$string['divmamxe'] = "mamxe";
			$string['divgioithieu'] = "gioithieu";
			$string['divlienhe'] = "lienhe";
			$string['divtintuc'] = "tintuc_choise";
			break; 
		case "gioithieu":
			$string['divtrangchu'] = "trangchu";
			$string['divvoxe'] = "voxe";
			$string['divmamxe'] = "mamxe";
			$string['divgioithieu'] = "gioithieu_choise";
			$string['divlienhe'] = "lienhe";
			$string['divtintuc'] = "tintuc";
			break; 
		case "mamxe":
			$string['divtrangchu'] = "trangchu";
			$string['divvoxe'] = "voxe";
			$string['divmamxe'] = "mamxe_choise";
			$string['divgioithieu'] = "gioithieu";
			$string['divlienhe'] = "lienhe";
			$string['divtintuc'] = "tintuc";
			break; 
		case "voxe":
			$string['divtrangchu'] = "trangchu";
			$string['divvoxe'] = "voxe_choise";
			$string['divmamxe'] = "mamxe";
			$string['divgioithieu'] = "gioithieu";
			$string['divlienhe'] = "lienhe";
			$string['divtintuc'] = "tintuc";
			break; 
		default: 
			$string['divtrangchu'] = "trangchu_choise";
			$string['divvoxe'] = "voxe";
			$string['divmamxe'] = "mamxe";
			$string['divgioithieu'] = "gioithieu";
			$string['divlienhe'] = "lienhe";
			$string['divtintuc'] = "tintuc";
			break; 
	}
	
	
	$xstl ->set($string);
	if($action != "index")
		$xstl -> display();
	
	//left 
	
	
	
	switch($action)
	{
		case "mamxe":
		{
			$config["{$action}"]['tabmamxe']['classactivemx'] = "class=\"Active\""; 
			$config["{$action}"]['tabmamxe']['classactivevx'] = ""; 
			$config["{$action}"]['tabmamxe']['noidungtabvx'] = "";
			$config["{$action}"]['tabmamxe']['noidungtabmx'] = "";
			$config["$action"]['tabmamxe']['tabviewmx'] = ""; 		
			$config["$action"]['lb_timkiem'] = "TÌM MÂM XE"; 
			$config["$action"]["formmamxe"]["listhangsx"] = $commonClass->allHangXe($connect, $md5Class, 'MX');
			$config["$action"]["formmamxe"]["listloaixe"] = $commonClass->allLoaiXe($connect, $md5Class, 'MX');
			$config["$action"]["formmamxe"]["postto"] = DOCUMENT_ROOT."/mamxe/".$md5Class->encode("timkiem");
			$config["$action"]["formmamxe"]["ajax_doixe"] = $md5Class->encode('ajax_doixe');
			$config["$action"]["formmamxe"]["ajax_hangmx"] = $md5Class->encode('ajax_hangmx');
			$config["{$action}"]['formmamxe']['view'] = ""; 
			break;
		}
		case "voxe":
		{
			$config["{$action}"]['tabvoxe']['classactivevx'] = "class=\"Active\""; 
			$config["{$action}"]['tabvoxe']['classactivemx'] = ""; 	
			$config["{$action}"]['tabvoxe']['noidungtabvx'] = "";
			$config["{$action}"]['tabvoxe']['noidungtabmx'] = "";	
			$config["$action"]['tabvoxe']['tabviewvx'] = ""; 
			$config["$action"]['lb_timkiem'] = "TÌM VỎ XE"; 
			$config["$action"]["formvoxe"]["listhangsx"] = $commonClass->allHangXe($connect, $md5Class);
			$config["$action"]["formvoxe"]["listloaixe"] = $commonClass->allLoaiXe($connect, $md5Class);
			$config["$action"]["formvoxe"]["postto"] = DOCUMENT_ROOT."/voxe/".$md5Class->encode("timkiem");
			$config["$action"]["formvoxe"]["ajax_quan"] = $md5Class->encode('ajax_quan'); 
			$config["$action"]["formvoxe"]["ajax_hang"] = $md5Class->encode('ajax_hang');
			$config["{$action}"]['formvoxe']['view'] = ""; 
			break;
		}
		default:
		{
			$config["$action"]['lb_timkiem'] = "TÌM NHANH"; 
			$config["$action"]['begindivpage'] = "<div style=\"height:247px;\" class=\"Pages\">"; 
			$config["$action"]['enddivpage'] = "</div>"; 
			$config["$action"]['tabvoxe']['tabviewvx'] = "href=\"javascript:tabview_switch('TabView', 1);\""; 
			$config["$action"]['tabmamxe']['tabviewmx'] = "href=\"javascript:tabview_switch('TabView', 2);\""; 
			
			$config["$action"]["formvoxe"]["ajax_quan"] = $md5Class->encode('ajax_quan');
			$config["$action"]["formvoxe"]["ajax_hang"] = $md5Class->encode('ajax_hang');
			$config["$action"]["formmamxe"]["ajax_doixe"] = $md5Class->encode('ajax_doixe');
			$config["$action"]["formmamxe"]["ajax_hangmx"] = $md5Class->encode('ajax_hangmx');
			$config["$action"]["formvoxe"]["listhangsx"] = $commonClass->allHangXe($connect, $md5Class);
			$config["$action"]["formvoxe"]["listloaixe"] = $commonClass->allLoaiXe($connect, $md5Class);
			$config["$action"]["formvoxe"]["postto"] = DOCUMENT_ROOT."/voxe/".$md5Class->encode("timkiem");
			$config["$action"]["formmamxe"]["listhangsx"] = $commonClass->allHangXe($connect, $md5Class, 'MX');
			$config["$action"]["formmamxe"]["listloaixe"] = $commonClass->allLoaiXe($connect, $md5Class, 'MX');
			$config["$action"]["formmamxe"]["postto"] = DOCUMENT_ROOT."/mamxe/".$md5Class->encode("timkiem");
			$config["{$action}"]['formvoxe']['view'] = ""; 
			//tim kiem vo xe
			$config["{$action}"]['tabvoxe']['classactivevx'] = "class=\"Active\""; 
			$config["{$action}"]['tabmamxe']['classactivemx'] = ""; 		
			$config["{$action}"]['tabvoxe']['noidungtabvx'] = "<div style=\"padding-top: 4px; text-align: center; width: 90px;\"> Vỏ xe <img src=\"".DOCUMENT_ROOT."/images/icon_voxe.png\" align=\"absmiddle\" border=\"0\"  /></div>";
			$config["{$action}"]['tabmamxe']['noidungtabmx'] = "<div style=\"padding-top: 4px; text-align: center; width: 90px;\"> Mâm xe <img src=\"".DOCUMENT_ROOT."/images/icon_mamxe.png\" align=\"absmiddle\" border=\"0\"  /></div>";
			
		
			
			break;
		}
	}
	
	$config["{$action}"]['dienthoai'] = $commonClass->getThongtin(&$connect, 'dienthoai');
	$config["{$action}"]['nickyahoo'] = $commonClass->getThongtin(&$connect, 'nick');
	
	

	//quang cao 6 
	$listquangcao6 = $commonClass->getQuangCao($connect, 6, $action);
	if(sizeof($listquangcao6) > 0)
	{
		$danhsachhinh = array();
		$i = 0;
		foreach ($listquangcao6 as $value)
		{
			$array = array(); 
			$ngaybd = $value['qc_batdau']; 
			$ngayhethan = $ngaybd + $value['qc_thoigian']*12*3600;
			if($ngayhethan < $today)
			{
				$array['hinh'] = "";
			}else {
				$array['hinh'] =  $commonClass->showIMG($value['qc_hinh'], 187, 185); 
				$array['linkbanner'] = $value['qc_link'];
			}	
			$danhsachhinh[] = $array;	
			$i++;
		}
		$config["{$action}"]['list_qc']['quangcao6'] = $danhsachhinh;
	}else 
		$config["{$action}"]['list_qc'] = "";
	//quang cao 7
	$listquangcao7 = $commonClass->getQuangCao($connect, 7, $action);
	if(sizeof($listquangcao7) > 0)
	{
		$danhsachhinh = array();
		$i = 0;
		foreach ($listquangcao7 as $value)
		{
			$array = array(); 
			$ngaybd = $value['qc_batdau']; 
			$ngayhethan = $ngaybd + $value['qc_thoigian']*12*3600;
			if($ngayhethan < $today)
			{
				$array['banner7'] = "";
			}else {
				$array['banner7'] =  $commonClass->showIMG($value['qc_hinh'], 554, '108'); 
				$array['linkbanner'] = $value['qc_link'];
			}	
			$danhsachhinh[] = $array;	
			$i++;
		}
		$config["{$action}"]['list_qc7']['listbanner7'] = $danhsachhinh;
	}else 
		$config["{$action}"]['list_qc7'] = "";
	//quang cao 8
	$listquangcao8 = $commonClass->getQuangCao($connect, 8, $action);
	if(sizeof($listquangcao8) > 0)
	{
		$danhsachhinh = array();
		$i = 0;
		foreach ($listquangcao8 as $value)
		{
			$array = array(); 
			$ngaybd = $value['qc_batdau']; 
			$ngayhethan = $ngaybd + $value['qc_thoigian']*12*3600;
			if($ngayhethan < $today)
			{
				$array['banner8'] = "";
			}else 
			{
				$array['banner8'] =  $commonClass->showIMG($value['qc_hinh'], 554, 108); 
				$array['linkbanner'] = $value['qc_link'];
			}	
			$danhsachhinh[] = $array;	
			$i++;
		}
		$config["{$action}"]['list_qc8']['listbanner8'] = $danhsachhinh;
	}else 
	{
		$config["{$action}"]['list_qc8'] = "";
	}
	//quang cao 4
	$listquangcao4 = $commonClass->getQuangCao($connect, 4, $action);
	if(sizeof($listquangcao4) > 0)
	{
		$danhsachhinh = array();
		$i = 0;
		foreach ($listquangcao4 as $value)
		{
			$array = array(); 
			$ngaybd = $value['qc_batdau']; 
			$ngayhethan = $ngaybd + $value['qc_thoigian']*12*3600;
			if($ngayhethan < $today)
			{
				$array['banner4'] = "";
			}else 
			{
				$array['banner4'] =  $commonClass->showIMG($value['qc_hinh'], 187, 185); 
				$array['linkbanner'] = $value['qc_link'];
			}	
			$danhsachhinh[] = $array;	
			$i++;
		}
		$config["{$action}"]['quangcao4'] = $danhsachhinh;
	}
	$config["{$action}"]['dienthoai'] = $commonClass->getThongtin(&$connect, 'dienthoai');
	$config["{$action}"]['nickyahoo'] = $commonClass->getThongtin(&$connect, 'nick');
		
	
	
	//right
	$listvoxe = $commonClass->getSanPham_QC($connect, 'VX');
	if(sizeof($listvoxe) > 0)
	{
		$danhsachvx = array();
		$i = 0;
		foreach ($listvoxe as $value)
		{
			$array['hinhsp'] = DOCUMENT_ROOT."/".$value['vx_hinh']; 
			$array['tensp'] = $value['vx_ten']; 
			$array['linksp'] =  DOCUMENT_ROOT."/voxe/".$md5Class->encode("chitiet")."/".$md5Class->encode($value['vx_id']);
			$danhsachvx[] = $array;	
			$i++;
		}
		
		$config["{$action}"]['voxe'] = $danhsachvx;
	}
	$listmamxe = $commonClass->getSanPham_QC($connect, 'MX');
	if(sizeof($listmamxe) > 0)
	{
		$danhsachmx = array();
		$i = 0;
		foreach ($listmamxe as $value)
		{
			$array['hinhspmx'] = DOCUMENT_ROOT."/".$value['mx_hinh']; 
			$array['tenspmx'] = $value['mx_ten']; 
			$array['linkspmx'] =  DOCUMENT_ROOT."/mamxe/".$md5Class->encode("chitiet")."/".$md5Class->encode($value['mx_id']);
			$danhsachmx[] = $array;	
			$i++;
		}
		
		$config["{$action}"]['mamxe'] = $danhsachmx;
	}
	//footer
	$xstlf = new templateClass(LINK_HEADER."footer.tpl");	
	$footer['linktrangchu'] = DOCUMENT_ROOT."/trangchu";
	$footer['linkvoxe'] = DOCUMENT_ROOT."/voxe";
	$footer['linkmamxe'] = DOCUMENT_ROOT."/mamxe";
	$footer['linkgioithieu']=DOCUMENT_ROOT."/gioithieu";
	$footer['linktintuc']=DOCUMENT_ROOT."/tintuc";
	$footer['linklienhe']=DOCUMENT_ROOT."/lienhe";
	$footer['tencongty']= $commonClass->getThongtin(&$connect, 'tencongty'); 
	$footer['diachi']= $commonClass->getThongtin(&$connect, 'diachi'); 
	$footer['fax']= $commonClass->getThongtin(&$connect, 'fax'); 
	$footer['dienthoai']= $commonClass->getThongtin(&$connect, 'dienthoai'); 
	$footer['didong']= $commonClass->getThongtin(&$connect, 'didong'); 
	$xstlf ->set($footer);	*/
	/*
	if(!empty($_SERVER['QUERY_STRING']))
		{
			if( isset($_GET["req"]) && $_GET["req"] != "")
			{
	//			$url_cache = "./".$_GET["req"];
				$url_cache = DOCUMENT_ROOT."/".$_GET["req"];
				if(isset($_GET["gid"]) && $_GET["gid"] != "")
				{
					$url_cache .= "/".$_GET["gid"];
					if(isset($_GET["id"]) && $_GET["id"] != "")
					{
						$url_cache .= "/".$_GET["id"];
						if(isset($_GET["type"]) && $_GET["type"] != "")
						{
							$url_cache .= "/".$_GET["type"];						
						}
					}	
				}
			}
			else $url_cache = "./";		
		}
		else $url_cache = "./";
		exit($url_cache);*/
	
	switch ($action) 
	{
		case "imagesercurity" :			
		{			
			ob_end_clean();	
			include_once("imagesercur.php") ;
			break ;
		}
		default:	 
			//LOAD MVC CLASS		
			include_once( MVC_CLASS );
			$mvcClass = new mvcClass() ;
			$mvcClass->action = $action ;
						//exit;
			$mvcClass->path = CLIENT;
			$mvcClass->checkModel() ;
			$mvcClass->checkControl();
			$mvcClass->checkView();				
			//LOAD MODEL AND CONTROL MODULE
			include_once("modules/client/".$mvcClass->action."/".$mvcClass->model) ;							
			include_once("modules/client/".$mvcClass->action."/".$mvcClass->controller) ;			
			$main_path = "modules/client/".
			            $mvcClass->action."/"
			            .$mvcClass->template.XTPL ;	
								
			$template = new XTemplate( $main_path ) ;	
			include_once("modules/client/".$mvcClass->action."/".$mvcClass->view) ;
			//thong ke	
			if(file_exists("modules/client/common/user_online.php")) include_once("modules/client/common/user_online.php") ;					
			//-----------------------MENU------------------//
			/*$file_menu = "compiler/cache/html/category/category_".date("dmy",$today).".xtpl" ;
			$file_menu_js = "compiler/cache/html/category/category_js_".date("dmy",$today).".xtpl" ;
			if(!file_exists($file_menu) || !file_exists($file_menu_js))
				$commonClass->CreatMenuLeft($connect, $md5Class);
			$template->assign('MENUJS', file_get_contents($file_menu_js));			*/
//			$template->assign_file('MENU', $file_menu);

			#$template->assign('MENU', $commonClass->CreatMenuLeftNew($connect));
			#$template->assign('total_online', $total_online);
			#$template->assign('total_visitors', $total_visitors);
			//--------------thong tin chung -------------//
			$file_tt_chung = "compiler/cache/html/quangcao/thongtinchung.php" ;
			if(!file_exists($file_tt_chung))
				$commonClass->TaoFileCacheThôngTinChung($connect);
			include_once($file_tt_chung);
			$template->assign('DIACHI', $thongtinchung['diachi']);
			$template->assign('DIENTHOAI', $thongtinchung['dienthoai']);
			$template->assign('DIDONG', $thongtinchung['didong']);
			$template->assign('TENCONGTY', $thongtinchung['tencongty']);
			$template->assign('EMAIL', $thongtinchung['email']);
			$template->assign('FAX', $thongtinchung['fax']);
			//DISPLAY INTERFACE			
			$template->parse('main');
			$template->out('main');
			break ;
	
	}	
}
catch ( Exception $e ) {
	header("Location:".DOCUMENT_ROOT) ;
	exit() ;
}

ob_end_flush() ;
exit() ;
?>