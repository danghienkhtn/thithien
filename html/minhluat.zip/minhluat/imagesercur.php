<?php
if(!defined('ATN_SYSTEM')) exit;

if(isset ($_REQUEST["gid"]) && isset($_REQUEST["id"]))
{
	$random_num =  $md5Class->decode($_REQUEST["id"]);
	$act = $md5Class->decode($_REQUEST["gid"]);
	if($random_num > 0 && !empty($act))
	{
		switch ($act)
		{
			case 'gfx':
				{
					Header("Content-type: image/jpeg");					
					$datekey = date("F j");
					$sitekey = DOMAIN_ROOT;
					$rcode = hexdec(md5($_SERVER[HTTP_USER_AGENT] . $sitekey . $random_num . $datekey));
					$code = substr($rcode, 2, 6);
					$image = ImageCreateFromJPEG(DOCUMENT_ROOT."/images/code_bg.jpg");
//					$image = ImageCreateFromJPEG("http://thoitrangmilan.com/images/code_bg.jpg");
					if (!$image) {
						$image  = imagecreate (73, 15);
						$bgc = imagecolorallocate ($image, 240, 240, 240);
						imagefilledrectangle ($image, 0, 0, 73, 15, $bgc);
					}
					$text_color = ImageColorAllocate($image, 50, 50, 50);
					ImageString ($image, 5, 11, 1, $code, $text_color);
					ImageJPEG($image, '', 90);
					ImageDestroy($image);	
					die();	
				}
				break;
			case 'thre':
				{
					$datekey = date("F j");
					$rcode = hexdec(md5($_SERVER[HTTP_USER_AGENT] . $sitekey . $random_num . $datekey));					
					$code = substr($rcode, 3, 3);
					$image = ImageCreateFromJPEG("".DOCUMENT_ROOT."/images/code_bg.jpg");
					if (!$image) {
						$image  = imagecreate (73, 115);
						$bgc = imagecolorallocate ($image, 240, 240, 240);
						imagefilledrectangle ($image, 0, 0, 73, 115, $bgc);
					}
					$text_color = ImageColorAllocate($image, 0,63, 150);
					Header("Content-type: image/jpeg");
					ImageString ($image, 5, 20, 1, $code, $text_color);
					ImageJPEG($image, '', 90);
					ImageDestroy($image);
			    	die();				
				}
				break;	
		}		
	}
	else exit("12");	
}
else exit("13");	
?>