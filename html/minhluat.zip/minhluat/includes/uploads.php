<?php

if ((!defined('ATN_SYSTEM')) AND (!defined('ATN_ADMIN'))) { die('Stop!!!'); }
if(!defined('ATN_MAINFILE')) { die('Stop!!!'); }

function thumbs($outpath,$inpath,$outimg,$inimg,$insize) {
	if(@copy("".$outpath."/".$outimg."", "".$inpath."/".$inimg."")) {
		$f_name = end(explode(".", $inimg));
		$f_extension = strtolower($f_name);
		if ($f_extension == "jpg" AND extension_loaded("gd")) {
			$src_img= ImageCreateFromJpeg("".$inpath."/".$inimg."");
			$src_width= ImagesX($src_img);
			$src_height= ImagesY($src_img);
			$dest_width = $insize;
			$dest_height = $src_height/($src_width/$dest_width);
			$dest_img=ImageCreateTrueColor($dest_width, $dest_height);
			ImageCopyResampled($dest_img, $src_img, 0, 0, 0, 0, $dest_width, $dest_height, $src_width, $src_height);
			ImageJpeg($dest_img, "".$inpath."/".$inimg."", 90);
			ImageDestroy($dest_img);	
		}
	}
}

function uploadimg($images, $delpic, $thumb, $thumb_width, $upath) {
	global $max_size, $width;
	if ($delpic == "yes") {
    @unlink("".INCLUDE_PATH."".$upath."/".$images."");
    @unlink("".INCLUDE_PATH."".$upath."/small_".$images."");
    $images = "";
    }
    if (is_uploaded_file($_FILES['userfile']['tmp_name'])) {
    	@unlink("".INCLUDE_PATH."".$upath."/".$images."");
    @unlink("".INCLUDE_PATH."".$upath."/small_".$images."");
    $images = "";
    	$realname = $_FILES['userfile']['name'];
	$file_size = $_FILES['userfile']['size'];
	$file_type = $_FILES['userfile']['type'];
	$f_name = end(explode(".", $realname));
	$f_extension = strtolower($f_name);
	$loaiimg_ext = array("gif","jpg","jpeg","pjpeg","png","bmp");
	$loaiimg_mime = array("image/gif", "image/pjpeg", "image/jpeg", "image/png", "image/bmp");
    if ($file_size > $max_size) {
    info_exit("<br><br><center>"._EROR1." ".$file_size." "._EROR2." $max_size byte.<br><br>"._GOBACK."</center><br><br>");
    }
    if(!in_array($file_type,$loaiimg_mime) || !in_array($f_extension,$loaiimg_ext)) {
    	info_exit("<br><br><center>"._EROR6."<br><br>"._GOBACK."</center><br><br>");
    }
    $datakod = date(U);
    $picname = "atn_".$datakod.".".$f_extension."";
    if(! @copy($_FILES['userfile']['tmp_name'], "".INCLUDE_PATH."".$upath."/".$picname."") ) {
		if (! move_uploaded_file($_FILES['userfile']['tmp_name'], "".INCLUDE_PATH."".$upath."/".$picname."")) {
			info_exit("<br><br>"._UPLOADFAILED."<br>");
		}
	}
	if (file_exists("".INCLUDE_PATH."".$upath."/".$picname."")) {
	$images = $picname;
	if ($f_extension == "jpg" AND extension_loaded("gd")) {
		$size = @getimagesize("".INCLUDE_PATH."".$upath."/".$images."");
		$thc = 0;
		if ($size[0] > $width) {
			$thc = 1; $sizemoi = $width;
		} elseif($size[0] > $thumb_width AND $size[0] < ($thumb_width+20)) {
			$thc = 1; $sizemoi = $thumb_width;
		}
		if ($thc == 1) {
			$src_img= ImageCreateFromJpeg("".INCLUDE_PATH."".$upath."/".$images."");
			$src_width= ImagesX($src_img);
			$src_height= ImagesY($src_img);
			$dest_width = $sizemoi;
			$dest_height = $src_height/($src_width/$dest_width);
			$dest_img=ImageCreateTrueColor($dest_width, $dest_height);
			ImageCopyResampled($dest_img, $src_img, 0, 0, 0, 0, $dest_width, $dest_height, $src_width, $src_height);
			ImageJpeg($dest_img, "".INCLUDE_PATH."".$upath."/".$images."", 90);
			ImageDestroy($dest_img);
		}
		$size = @getimagesize("".INCLUDE_PATH."".$upath."/".$images."");
		if($thumb==1 AND $size[0] > $thumb_width) {
			$picname_thumb = "small_".$picname."";
			if(! @copy($_FILES['userfile']['tmp_name'], "".INCLUDE_PATH."".$upath."/".$picname_thumb."") ) {
				@move_uploaded_file($_FILES['userfile']['tmp_name'], "".INCLUDE_PATH."".$upath."/".$picname_thumb."");
			}
			if (file_exists("".INCLUDE_PATH."".$upath."/".$picname_thumb."")) {
					$src_img= ImageCreateFromJpeg("".INCLUDE_PATH."".$upath."/".$picname_thumb."");
					$src_width= ImagesX($src_img);
					$src_height= ImagesY($src_img);
					$dest_width = $thumb_width;
					$dest_height = $src_height/($src_width/$dest_width);
					$dest_img=ImageCreateTrueColor($dest_width, $dest_height);
					ImageCopyResampled($dest_img, $src_img, 0, 0, 0, 0, $dest_width, $dest_height, $src_width, $src_height);
					ImageJpeg($dest_img, "".INCLUDE_PATH."".$upath."/".$picname_thumb."", 90);
					ImageDestroy($dest_img);
			}
		}
	}
	}
	}
	return($images);
}

function imgsize_check($img){
	global $up_img_min_wid, $up_img_min_hei, $up_img_max_wid, $up_img_max_hei;
	// get original sizes
	
	//feed_back($img);
	$srcImg = imagecreatefromjpeg($img);//"$imageDirectory/$imageName");
	$origWidth = imagesx($srcImg);
	$origHeight = imagesy($srcImg);
	
	$ratio = $origHeight/$origWidth;
	//echo "$imageDirectory/$imageName , $thumbDirectory, $thumbName , ratio = $ratio, origWidth = $origWidth, origHeight = $origHeight";
	if($ratio > 10 || $ratio < 0.1 || $origWidth > $up_img_max_wid || $origHeight > $up_img_max_hei || $origWidth < $up_img_min_wid || $origHeight < $up_img_min_hei ){
		feed_back(_KICHTHUOCANHKHONGHOPLE." (".$origWidth."x".$origHeight.") "._PHAILA." ( Min : $up_img_min_wid x $up_img_min_hei) - ( Max : $up_img_max_wid x $up_img_max_hei)");
		return 0;
	}
	return 1;
}

function do_upload($path, $newname, $filtered_type){
	// $filtered_type = 1 :jpg accepted
	// $filtered_type = 2 :xls accepted
	if($_FILES["userfile"]["type"] == "image/jpeg" || $_FILES["userfile"]["type"] == "image/jpg" || $_FILES["userfile"]["type"] == "image/pjpeg") $ext = ".jpg";
	if($_FILES["userfile"]["type"] == "application/vnd.ms-excel") $ext = ".xls";
	// check if need to create new folder each month.
	
	$month_fold = "".INCLUDE_PATH.$path."/".date("dmY");
	
	if(!is_dir($month_fold)){
		//feed_back("khong ton tai:".$month_fold);
		if (!mkdir($month_fold)) {
			feed_back("Can not create folder: ".$month_fold);
			return "none";
		}
	}
	@chmod($month_fold, 0777);
	$filename = $month_fold."/".$newname.$ext;
	
	if (($_FILES["userfile"]["type"] == "application/vnd.ms-excel" || $_FILES["userfile"]["type"] == "image/pjpeg" || $_FILES["userfile"]["type"] == "image/jpeg" || $_FILES["userfile"]["type"] == "image/jpg")&& ($_FILES["userfile"]["size"] < 200000) && !(($ext == ".jpg" and $filtered_type != 1) or ($ext == ".xls" and $filtered_type != 2))){
	  	if ($_FILES["userfile"]["error"] > 0){
	  		feed_back("Error: " . $_FILES["userfile"]["error"] . "<br />");
		}else{
			if($_FILES["userfile"]["type"] != "application/vnd.ms-excel"){// it is an jpg file.
				if(!imgsize_check($_FILES["userfile"]["tmp_name"]))return "none" ;
				move_uploaded_file($_FILES["userfile"]["tmp_name"],$filename);
				add_log("Upload Image '".$_FILES["userfile"]["name"]);
			}else{
				move_uploaded_file($_FILES["userfile"]["tmp_name"],$filename);
				add_log("Upload Excel '".$_FILES["userfile"]["name"]);
			}
			return $filename;
		}
	}
	feed_back(_KIEUFILEKHONGHOPLE);
	return "none";
}
function upload_banner_img($path, $imgID="",$type="prod", $thumb=true, $sSource="", $sFileName="")
{	
	if($sSource=="")
		$sSource=$_FILES["userfile"]["tmp_name"];
	$sDest="".INCLUDE_PATH."".$path;
	if($sFileName=="")
		$sFileName=$_FILES["userfile"]["name"];
	$fView=false;
	//process
	//
	$sNewFileThum = $imgID."_".date("dmyHis"). "t" . substr($sFileName,strrpos($sFileName,"."),strlen($sFileName));
	$sNewFileName = $imgID."_".date("dmyHis").substr($sFileName,strrpos($sFileName,"."),strlen($sFileName));
	//echo $sNewFileName;
	@chmod($sDest."/", 0777);
	if(!is_dir($sDest."/")){
		if (@mkdir($sDest)) {
			$handle =fopen($sDest . "/index.html","w+");
		}else
			echo ("Can not create folder: ".$sDest);					
	}
	
	if(!empty($sDest)){
		if(substr($sDest, -1, 1)!="\\" && substr($sDest, -1, 1) !="/")
			$sDest .= "/";
		else
			$sDest = str_replace("\\","/",$sDest);
	}
	
	if(! copy($sSource, $sDest . $sFileName) ) {
	//echo "da vao day:" . $sDest . $sFileName;
		move_uploaded_file($sSource, $sDest . $sFileName);
	}
	if(file_exists($sDest.$sFileName)) return $sDest.$sFileName;
	else return "none";	
}//end function upload file
function upload_prod_img($path, $imgID="",$type="prod", $thumb=true, $sSource="", $sFileName=""){
	/*
	$sSource="C:/AppServ/www/imagefunction/thu1.jpg";//$_FILES['userfile']['tmp_name'];
	$sDest="hinh";//$_POST["sDest"];
	$sFileName="hinh.hinh.jpg";//$_FILES['userfile']['name'];
	$imgID="123";//123
	$fView=false;
	//
	*/
	if($sSource=="")
		$sSource=$_FILES["userfile"]["tmp_name"];
	$sDest="".INCLUDE_PATH."".$path;
	if($sFileName=="")
		$sFileName=$_FILES["userfile"]["name"];
	$fView=false;
	//process
	//
	$sNewFileThum = $imgID."_".date("dmyHis"). "t" . substr($sFileName,strrpos($sFileName,"."),strlen($sFileName));
	$sNewFileName = $imgID."_".date("dmyHis").substr($sFileName,strrpos($sFileName,"."),strlen($sFileName));
	$sTemFileName = $imgID."_".date("dmyHis"). "g" .substr($sFileName,strrpos($sFileName,"."),strlen($sFileName));
	//echo $sNewFileName;	
	if(!is_dir($sDest)){
		if (@mkdir($sDest)) {
			$handle =fopen($sDest . "/index.html","w+");
		}else
			echo ("Can not create folder: ".$sDest);					
	}
	
	if(!empty($sDest)){
		if(substr($sDest, -1, 1)!="\\" && substr($sDest, -1, 1) !="/")
			$sDest .= "/";
		else
			$sDest = str_replace("\\","/",$sDest);
	}
	@chmod($sDest, 0777);
	if(! copy($sSource, $sDest . $sFileName) ) {
	//echo "da vao day:" . $sDest . $sFileName;
		move_uploaded_file($sSource, $sDest . $sFileName);
	}
//echo "uploads.php-->".	$sDest . $sFileName;
	if (file_exists($sDest . $sFileName)) {
	//echo ("file da ton tai");
//echo $sNewFileThum."/". $sNewFileName."/".	$sFileName;
		include("".INCLUDE_PATH.""."includes/imageresize.php");
		$im = new ImageResize();
		$im->SetDest($sDest);
		$im->SetFileName($sFileName);
		
		$im->ViewImage($fView);
		$im->SetPercent(1);
		$w=$im->GetWidth();
		$h=$im->GetHeight();
		if($type=="logo"){
			$im->SetNewHeight(90);
			$im->SetNewFileName($sNewFileName);
			$im->ResizeIMG();
		}elseif($type=="banner"){
			$im->SetNewHeight(0);
			$im->SetNewWidth(600);
			$im->SetNewFileName($sNewFileName);
			$im->ResizeIMG();
		}else{
			//create small file
			if($thumb){
				$im->SetNewWidth(150);
				$im->SetNewFileName($sNewFileThum);
				$im->ResizeIMG();
			}
			$im->SetNewHeight(0);
			$im->SetNewWidth(0);
			$im->SetNewFileName($sNewFileName);
			if($w>500){
				$im->SetNewWidth(500);
			}elseif($h>375){
				$im->SetNewHeight(375);
			}else{
				$im->SetNewWidth(300);
			}
			$im->ResizeIMG();
		}
		//delete file tamp
		@rename($sDest . $sFileName, $sDest . $sTemFileName);
		return $im->GetURL();
	}else
		echo "Try agian, don't moving file";
	return "none";
}//end function upload file
	function scale_other($iw, $ih, $ow, $oh ){
		if(!$ow) return round(($iw * $oh)/ $ih);
		return round(($ow*$ih/$iw));
	}
	
	function createThumbnail($imageName, $thumbName, $thumbWidth = 0)
	{
		global $force_thumb_wid, $force_thumb_hei;
	
		$thumbName = dirname($imageName)."/".$thumbName;
		//feed_back("img name : $imageName, newname ".$thumbName);
		
		
		if(!$thumbWidth){ // use setting values
			$new_width =  $force_thumb_wid;
			$new_height = $force_thumb_hei;
		}else{ // apply new width
			$new_width = $thumbWidth;
			$new_height = $thumbWidth;
		}
		
		if(!imgsize_check($imageName)) return 0;
		$srcImg = imagecreatefromjpeg($imageName);
		$origWidth = imagesx($srcImg);
		$origHeight = imagesy($srcImg);
	
		if($origWidth > $origHeight) { // use width : optimized
			$thumbWidth = $new_width;
			$thumbHeight = scale_other($origWidth, $origHeight, $thumbWidth, 0);
		}else{
			$thumbHeight = $new_height;
			$thumbWidth = scale_other($origWidth, $origHeight, 0, $thumbHeight);
		}
	
		$thumbImg = ImageCreateTrueColor($thumbWidth, $thumbHeight);
		ImageCopyResampled($thumbImg, $srcImg, 0, 0, 0, 0, $thumbWidth, $thumbHeight, $origWidth, $origHeight);
		@chmod($month_fold, 0777);
		imagejpeg($thumbImg, "$thumbName");
		ImageDestroy($thumbImg);
		return 1;
}

?>