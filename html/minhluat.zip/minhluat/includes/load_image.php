<?php
$isLogin = $loginClass->isLogin() ;
if($isLogin)
{
	$isKind = $loginClass->getUserTypeID() ;
	$fullname = $loginClass->getFullName() ;
	$userID = $loginClass->getID() ;
	switch($isKind)
	{
		case 0:
		$array["login"]["linkaccount"]="./?req=VGMGYlc4BjhQbgEMXTwDaVduWg4GNloxBGJVbw_3D_3D";
		break;
		case 1:
		$array["login"]["linkaccount"]="./?req=VWIEYAZpVGoEOlJfXyAHZ1FtAGdTYVAg";
		break;
		case 2:
		$array["login"]["linkaccount"]="./?req=W2wEYFc4AT8DPVZbAW8Dc1lwDWMBJA_3D_3D﻿";
		break;
		
	}
	$array["login"]["username"]= $fullname;
	$xstl-> set(array("login"=>$array["login"]));
}
$strtmp="";
if($currentlang=="english") $strtmp="_E";
	switch($action)
	{
		case "index":
		{			
			$arrimage["image1"]="images/button".$strtmp."_over_02.gif";
			$arrimage["image2"]="images/button".$strtmp."_03.gif";
			$arrimage["image3"]="images/button".$strtmp."_04.gif";
			$arrimage["image4"]="images/button".$strtmp."_05.gif";
			$arrimage["image5"]="images/button".$strtmp."_06.gif";
			$arrimage["image6"]="images/button".$strtmp."_07.gif";
			$arrimage["image7"]="images/button".$strtmp."_09.gif";
			break;
		}
		case "mua_doanh_nghiep":
		{
			$arrimage["image1"]="images/button".$strtmp."_02.gif";
			$arrimage["image2"]="images/button".$strtmp."_over_03.gif";
			$arrimage["image3"]="images/button".$strtmp."_04.gif";
			$arrimage["image4"]="images/button".$strtmp."_05.gif";
			$arrimage["image5"]="images/button".$strtmp."_06.gif";
			$arrimage["image6"]="images/button".$strtmp."_07.gif";
			$arrimage["image7"]="images/button".$strtmp."_09.gif";
			break;
		}
		case "ban_doanh_nghiep":
		{
			$arrimage["image1"]="images/button".$strtmp."_02.gif";
			$arrimage["image2"]="images/button".$strtmp."_03.gif";
			$arrimage["image3"]="images/button".$strtmp."_over_04.gif";
			$arrimage["image4"]="images/button".$strtmp."_05.gif";
			$arrimage["image5"]="images/button".$strtmp."_06.gif";
			$arrimage["image6"]="images/button".$strtmp."_07.gif";
			$arrimage["image7"]="images/button".$strtmp."_09.gif";
			break;
		}
		case "tim_thuong_hieu":
		{
			$arrimage["image1"]="images/button".$strtmp."_02.gif";
			$arrimage["image2"]="images/button".$strtmp."_03.gif";
			$arrimage["image3"]="images/button".$strtmp."_04.gif";
			$arrimage["image4"]="images/button".$strtmp."_over_05.gif";
			$arrimage["image5"]="images/button".$strtmp."_06.gif";
			$arrimage["image6"]="images/button".$strtmp."_07.gif";
			$arrimage["image7"]="images/button".$strtmp."_09.gif";
			break;
		}
		case "tim_nha_moi_gioi":
		{
			$arrimage["image1"]="images/button".$strtmp."_02.gif";
			$arrimage["image2"]="images/button".$strtmp."_03.gif";
			$arrimage["image3"]="images/button".$strtmp."_04.gif";
			$arrimage["image4"]="images/button".$strtmp."_05.gif";
			$arrimage["image5"]="images/button".$strtmp."_over_06.gif";
			$arrimage["image6"]="images/button".$strtmp."_07.gif";
			$arrimage["image7"]="images/button".$strtmp."_09.gif";
			break;
		}
		case "tim_moi_gioi":
		{
			$arrimage["image1"]="images/button".$strtmp."_02.gif";
			$arrimage["image2"]="images/button".$strtmp."_03.gif";
			$arrimage["image3"]="images/button".$strtmp."_04.gif";
			$arrimage["image4"]="images/button".$strtmp."_05.gif";
			$arrimage["image5"]="images/button".$strtmp."_06.gif";
			$arrimage["image6"]="images/button".$strtmp."_over_07.gif";
			$arrimage["image7"]="images/button".$strtmp."_09.gif";
			break;
		}
		case "faq":
		{
			$arrimage["image1"]="images/button".$strtmp."_02.gif";
			$arrimage["image2"]="images/button".$strtmp."_03.gif";
			$arrimage["image3"]="images/button".$strtmp."_04.gif";
			$arrimage["image4"]="images/button".$strtmp."_05.gif";
			$arrimage["image5"]="images/button".$strtmp."_06.gif";
			$arrimage["image6"]="images/button".$strtmp."_07.gif";
			$arrimage["image7"]="images/button".$strtmp."_over_09.gif";
			break;
		}
		default:
		{
			$arrimage["image1"]="images/button".$strtmp."_02.gif";
			$arrimage["image2"]="images/button".$strtmp."_03.gif";
			$arrimage["image3"]="images/button".$strtmp."_04.gif";
			$arrimage["image4"]="images/button".$strtmp."_05.gif";
			$arrimage["image5"]="images/button".$strtmp."_06.gif";
			$arrimage["image6"]="images/button".$strtmp."_07.gif";
			$arrimage["image7"]="images/button".$strtmp."_09.gif";
			break;
		}	
	}
	$string["MENU"]=$arrimage;
?>