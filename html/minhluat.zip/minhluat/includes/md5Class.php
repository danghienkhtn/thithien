<?php
//class md5Class implements security {
class md5Class {
	//variable member	
		
	//construct and destruct
	
	//FOR PHP4
	function  md5Class() {
		md5Class::__construct();
	}
	
	//FOR PHP5	
	function __construct() {		
	}
	
	function __destruct() {		
	}
	
	function __toString() {
		return get_class(__CLASS__) ;
	}
	
	function __wakeup()
	{
  		$class = get_class($this);
  		new $class;
	}
	
	//create a key
	 function key($value,$key="thaihoa") {	
		$key = md5($key) ;
		$ctr=0 ;
		$tmp = "" ;
		for ($i=0;$i<strlen($value);$i++){
				if ($ctr==strlen($key)) {
					$ctr=0 ;
				}
				$tmp.= substr($value,$i,1) ^ substr($key,$ctr,1) ;
				$ctr++ ;
		}
		return $tmp ;
	}
	
	//encode a value
	 function encode($value,$key="security") {	
		srand((double)microtime()*1000000) ;
		$encrypt = md5(rand(0,32000)) ;			
		$ctr=0 ;
		$tmp = "" ;
		for ($i=0;$i<strlen($value);$i++)	{
			if ($ctr==strlen($encrypt)) {
				$ctr=0 ;
			}
			$tmp.= substr($encrypt,$ctr,1).(substr($value,$i,1) ^ substr($encrypt,$ctr,1)) ;
			$ctr++ ;
		}
		return base64_encode($this->key($tmp,$key)) ;
	}
	
	//encode a value static
	 function encodeStatic($value,$key="security") {			
		$encrypt = md5("mt_company") ;			
		$ctr=0 ;
		$tmp = "" ;
		for ($i=0;$i<strlen($value);$i++)	{
			if ($ctr==strlen($encrypt)) {
				$ctr=0 ;
			}
			$tmp.= substr($encrypt,$ctr,1).(substr($value,$i,1) ^ substr($encrypt,$ctr,1)) ;
			$ctr++ ;
		}
		return base64_encode($this->key($tmp,$key)) ;
	}
	
	//decode a value
	 function decode($value,$key="security") {
		$value = $this->key(base64_decode($value),$key) ;
		$tmp = "" ;
		for ($i=0;$i<strlen($value);$i++){
				$md5 = substr($value,$i,1);
				$i++;
				$tmp.= (substr($value,$i,1) ^ $md5);
		}
		return $tmp;
	}
	
	//radom a password	
	 function randPass($start=0,$length=10,$flag=0) {
		$randomPassword = "";	
		srand((double)microtime()*1000000) ;	
		for($i=0;$i<8;$i++)	{
				$randnumber = rand(48,120);
				while (($randnumber >= 58 && $randnumber <= 64) || ($randnumber >= 91 && $randnumber <= 96)) {
						$randnumber = rand(48,120);
				}
				$randomPassword .= chr($randnumber);
		}
		
		$password = substr(md5($randomPassword),$start,$length) ;
		if($flag == 0) {
			$password = strtoupper($password) ;
		}
		else {
			$password = strtolower($password) ;
		}
		
		return $password ;	
	}
}
?>