<?php
/***********************************************************************/
/*                                                                     */
/*   Copyright (C) 2008-2010  My Tran company.                         */
/*   Author     : rocachi - Do Van Chien - rocachien@yahoo.com.        */
/*   Powered By : My Tran company.                                     */
/*                                                                     */
/*   Created    : 20-03-2008 22:32:05.                                 */
/*   Modified   : 20-03-2008 17:27:22.                                 */
/*   Description: config.php, config total.                            */
/*                                                                     */  
/***********************************************************************/
$itemnews=6;
$itemprod=3;
$itemservice=3;
$itempord_mt=12;
$itempord_l=9;
$katimkiem=15;
$money_de=",";
$money_co=".";
$strfmdate="d/m/Y";
$sitename="http://ypvip.com";
$adminmail="support@ypvip.com";
?>