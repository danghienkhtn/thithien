<?php
global $datafold;
$banner_folder = "upload/quangcao/";
if (file_exists("$datafold/config_ads_setting.php")) {
	include_once("$datafold/config_ads_setting.php");
}
function static_ver_banners_1($banners, $ban_width="115", $ban_height="242")
{ // display an array of the same banner, vertical arrangement
	global $module_name, $go, $banner_folder;
	$is_ads = 0;
	$str = "";
	if(sizeof($banners))
	{												 
		for($i = 1; $i<=sizeof($banners) ; $i++)
		{
			//if(($banners[$i]['mod'] == $module_name) and ($banners[$i]['goto'] == "" ||  $banners[$i]['goto'] == $go) and file_exists($banner_folder.$banners[$i]['img'])){
			//echo $banner_folder.$banners[$i]['img']."+++++++++++++++++++<br />";
			if(file_exists($banner_folder.$banners[$i]['img']) && $banners[$i]['mod'] == $module_name)
			{
				$str .= "<div class=\"tk_area_2b\">";
				$is_ads++;
				$name = $banners[$i]['name'];
				$img = $banners[$i]['img'];
				$url = $banners[$i]['url'];
				$ext = substr($img,strlen($img)-3);
				if($ext == 'swf')
				{
					$displayed = "<a href=\"$url\" target=\"_blank\"><embed name=\"flash\"  src=\""."$banner_folder"."$img\" quality=\"high\" bgcolor=\"#96BCE3\"\n";
					$displayed .= " z-index=\"0\" wmode=\"transparent\" width=\"$ban_width\" height=\"$ban_height\"\n";
					$displayed .= "    type=\"application/x-shockwave-flash\"\n";
					$displayed .= "    pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">\n";
					$displayed .= "</embed></a>\n";
				}
				else $displayed = "<a href=\"$url\" target=\"_blank\"><img src=\""."$banner_folder"."$img\" border=\"0\" alt=\"$name\" width=\"$ban_width\" height=\"$ban_height\"></a>";
				$str.= $displayed;
				$str .= "</div>\n";				
				$str .="<div style=\"text-transform:capitalize; text-align:center; margin-top:5px !important; margin-top:5px; margin-bottom:5px;\"><span><a class=\"tk_button\" href=\"#\">".$banners[$i]['name']."</a></span>";                           			
               $str .="</div>";
			}
		}		
	}
	return $str;
}
function static_ver_banners_2($banners, $ban_width="115", $ban_height="242")
{ // display an array of the same banner, vertical arrangement
	global $module_name, $go, $banner_folder;
	$is_ads = 0;
	$str = "";
	if(sizeof($banners))
	{												 
		for($i = 1; $i<=sizeof($banners) ; $i++)
		{						
			if(file_exists($banner_folder.$banners[$i]['img']) && $banners[$i]['mod'] == $module_name)
			{				
				$is_ads++;				
				$name = $banners[$i]['name'];
				$img = $banners[$i]['img'];
				$url = $banners[$i]['url'];
				$ext = substr($img,strlen($img)-3);
				if($ext == 'swf')
				{
					$displayed = "<a href=\"$url\" target=\"_blank\"><embed name=\"flash\"  src=\""."$banner_folder"."$img\" quality=\"high\" bgcolor=\"#96BCE3\"\n";
					$displayed .= " z-index=\"0\" wmode=\"transparent\" width=\"$ban_width\" height=\"$ban_height\"\n";
					$displayed .= "    type=\"application/x-shockwave-flash\"\n";
					$displayed .= "    pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">\n";
					$displayed .= "</embed></a>\n";
				}
				else $displayed = "<a href=\"$url\" target=\"_blank\"><img src=\""."$banner_folder"."$img\" border=\"0\" alt=\"$name\" width=\"$ban_width\" height=\"$ban_height\"></a>";
				$str.= $displayed;				                           			               
			}
		}		
	}
	return $str;
}
function static_ver_banners($banners, $ban_width="115", $ban_height="242"){ // display an array of the same banner, vertical arrangement
	global $module_name, $go, $banner_folder;
	$is_ads = 0;
	if(sizeof($banners)){		
		echo "<div><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
		for($i = 1; $i<=sizeof($banners) ; $i++){
			//if(($banners[$i]['mod'] == $module_name) and ($banners[$i]['goto'] == "" ||  $banners[$i]['goto'] == $go) and file_exists($banner_folder.$banners[$i]['img'])){			
			if(file_exists($banner_folder.$banners[$i]['img']) && $banners[$i]['mod'] == $module_name)
			{
				$is_ads++;
				$name = $banners[$i]['name'];
				$img = $banners[$i]['img'];
				$url = $banners[$i]['url'];
				$ext = substr($img,strlen($img)-3);
				if($ext == 'swf'){
					$displayed = "<a href=\"$url\" target=\"_blank\"><embed name=\"flash\"  src=\""."$banner_folder"."$img\" quality=\"high\" bgcolor=\"#96BCE3\"\n";
					$displayed .= " z-index=\"0\" wmode=\"transparent\" width=\"$ban_width\" height=\"$ban_height\"\n";
					$displayed .= "    type=\"application/x-shockwave-flash\"\n";
					$displayed .= "    pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">\n";
					$displayed .= "</embed></a>\n";
				}else $displayed = "<a href=\"$url\" target=\"_blank\"><img src=\""."$banner_folder"."$img\" border=\"0\" alt=\"$name\" width=\"$ban_width\"></a>";
				echo "<tr><td align='left' valign='top'>\n";
				echo $displayed;
				echo "</td></tr>\n";
				echo "<tr><td height='2'></td></tr>\n";
			}
		}
		echo "<tr><td height='2' width=\"$ban_width\" ></td></tr>\n";
		echo "</table></div>\n";
	}
}

function static_ver_banner($banners, $index=1, $ban_width="115", $ban_height="242"){ // display an array of the same banner, vertical arrangement
	global $module_name, $go, $banner_folder;
	$is_ads = 0;
	if(sizeof($banners)>=$index){
		$bn= "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n";
		//for($i = 1; $i<=sizeof($banners) ; $i++){
			if(($banners[$index]['mod'] == $module_name) and ($banners[$index]['goto'] == "" ||  $banners[$index]['goto'] == $go) and file_exists($banner_folder.$banners[$index]['img'])){
				$is_ads++;
				$name = $banners[$index]['name'];
				$img = $banners[$index]['img'];
				$url = $banners[$index]['url'];
				$ext = substr($img,strlen($img)-3);
				if($ext == 'swf'){
					$displayed = "<a href=\"$url\" target=\"_blank\"><embed name=\"flash\"  src=\""."$banner_folder"."$img\" quality=\"high\" bgcolor=\"#96BCE3\"\n";
					$displayed .= " z-index=\"0\" wmode='transparent' width=\"$ban_width\" height=\"$ban_height\"\n";
					$displayed .= "    type=\"application/x-shockwave-flash\"\n";
					$displayed .= "    pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">\n";
					$displayed .= "</embed></a>\n";
				}else $displayed = "<a href=\"$url\" target=\"_blank\"><img src=\""."$banner_folder"."$img\" border=\"0\" alt=\"$name\" width=\"$ban_width\"></a>";
				$bn.= "<tr><td align='left' valign='top'>\n";
				$bn.= $displayed;
				$bn.= "</td></tr>\n";
				$bn.= "<tr><td height='2'></td></tr>\n";
			}
		//}
		$bn.= "<tr><td height='2' width=\"$ban_width\" ></td></tr>\n";
		$bn.= "</table>\n";
	return $bn;
	}else return "";
}
function static_ver_banners_new($banners, $ban_width="115", $ban_height="242"){ // display an array of the same banner, vertical arrangement
	global $module_name, $go, $banner_folder;
	$is_ads = 0;
	$str_adv = "";
	if(sizeof($banners))
	{				
		for($i = 1; $i<=sizeof($banners) ; $i++)
		{
			//if(($banners[$i]['mod'] == $module_name) and ($banners[$i]['goto'] == "" ||  $banners[$i]['goto'] == $go) and file_exists($banner_folder.$banners[$i]['img'])){			
			if(file_exists($banner_folder.$banners[$i]['img']) && $banners[$i]['mod'] == $module_name)
			{
				$is_ads++;
				$name = $banners[$i]['name'];
				$img = $banners[$i]['img'];
				$url = $banners[$i]['url'];
				$ext = substr($img,strlen($img)-3);
				if($ext == 'swf'){
					$displayed = "<a href=\"$url\" target=\"_blank\"><embed name=\"flash\"  src=\""."$banner_folder"."$img\" quality=\"high\" bgcolor=\"#96BCE3\"\n";
					$displayed .= " z-index=\"0\" wmode=\"transparent\" width=\"$ban_width\" height=\"$ban_height\"\n";
					$displayed .= "    type=\"application/x-shockwave-flash\"\n";
					$displayed .= "    pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">\n";
					$displayed .= "</embed></a>\n";
				}else $displayed = "<a href=\"$url\" target=\"_blank\"><img src=\""."$banner_folder"."$img\" border=\"0\" alt=\"$name\" width=\"$ban_width\" height=\"".$ban_height."\" ></a>";
				$str_adv .= "<div align='center' style='margin-top:2px; width:".$ban_width."px; height:".$ban_height."px float:left; margin-left:0px'";
				$str_adv .= $displayed;
				$str_adv .= "</div>";			}
			}
	}
	return $str_adv;
}

function slide_ver_banners($banners, $ban_width="115", $ban_height="242", $startx, $starty, $pos_name){
	global $module_name, $go, $banner_folder;
	$is_ads = 0;
	echo "vao day"; 
	exit();
	echo "<SCRIPT>\n";
	echo "function FloatTopDiv$pos_name(aObject, startX, startY)\n";
	echo "{\n";
	echo "	var ns = (navigator.appName.indexOf(\"Netscape\") != -1);\n";
	echo "	var d$pos_name = document;\n";
	echo "\n";
	echo "	function ml$pos_name(id)\n";
	echo "	{\n";
	echo "		var el=d$pos_name.getElementById?d$pos_name.getElementById(id):d$pos_name.all?d$pos_name.all[id]:d$pos_name.layers[id];\n";
	echo "		if(d$pos_name.layers)el.style=el;\n";
	echo "		el.sP=function(x,y){this.style.left=x;this.style.top=y;};\n";
	echo "		el.x = startX;\n";
	echo "		el.y = startY;\n";
	echo "		return el;\n";
	echo "	}\n";
	echo "	window.stayTop$pos_name=function()\n";
	echo "	{\n";
	echo "		\n";
	echo "		if (document.documentElement && document.documentElement.scrollTop)\n";
	echo "			var pY = ns ? pageYOffset : document.documentElement.scrollTop;\n";
	echo "		else if (document.body)\n";
	echo "			var pY = ns ? pageYOffset : document.body.scrollTop;\n";
	echo "\n";
	echo "		\n";
	echo "		floatingObject$pos_name.y += (pY + startY - floatingObject$pos_name.y)/8;\n";
	echo "		floatingObject$pos_name.sP(floatingObject$pos_name.x, floatingObject$pos_name.y);\n";
	echo "		setTimeout(\"stayTop$pos_name()\", 1);\n";
	echo "	}\n";
	echo "	floatingObject$pos_name = ml$pos_name(aObject);\n";
	echo "	stayTop$pos_name();\n";
	echo "}\n";
	echo "if (window.screen.availWidth > 1023) {\n";
	echo "	if (!document.layers)\n";
	echo "	document.write('<div id=\"div$pos_name\" style=\"position:absolute\" >');\n";
	echo "	\n";

	if(sizeof($banners)){
		for($i = 1; $i<=sizeof($banners) ; $i++){
			if(($banners[$i]['mod'] == $module_name) and ($banners[$i]['goto'] == "" ||  $banners[$i]['goto'] == $go) and file_exists($banner_folder.$banners[$i]['img'])){
				$is_ads++;
				$name = $banners[$i]['name'];
				$img = $banners[$i]['img'];
				$url = $banners[$i]['url'];
				$ext = substr($img,strlen($img)-3);

				$displayed .= "	document.write('<layer id=\"div$pos_name\"><a href=\"$url\" target=\"_blank\">";
				if($ext == 'swf'){
				
					$displayed .= "<embed name=\"flash\"  src=\"$banner_folder$img\" quality=\"high\" bgcolor=\"#96BCE3\" ";
					$displayed .= "    width=\"$ban_width\" height=\"$ban_height\" z-index=\"0\" wmode=\"transparent\" ";
					$displayed .= "    type=\"application/x-shockwave-flash\"";
					$displayed .= "    pluginspage=\"http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash\">";
					$displayed .= "</embed>";
				}else $displayed .= "<img src=\"$banner_folder$img\" width=\"$ban_width\" border=\"0\" alt=\"$name\" >";
				$displayed .= "</a></layer><br>');\n";
				$displayed .= "document.write('<div id=\"div$pos_name\" style=\"height:2px; width:2px;\"></div>');\n";
			}
		}
	}
	/*
	if(!$is_ads){
		$displayed = "	document.write('<layer id=\"div$pos_name\"><a href=\"$url\" target=\"_blank\"><img src=\"images/qc_130180.gif\" border=\"0\" alt=\"$name\" width=\"$ban_width\"></a></layer>');\n";
	}*/
	echo $displayed;
	echo "	\n";
	echo "	if (!document.layers)\n";
	echo "	document.write('</div>');\n";
	echo "}\n";

	echo "if (window.screen.availWidth > 1023) {\n";
	echo "	FloatTopDiv$pos_name(\"div$pos_name\", $startx, $starty);\n";
	echo "}\n";
	echo "</SCRIPT>\n";
}

function top_banners($banners)
{
	global $top_ads, $module_name, $go, $banner_folder, $slide_delay;
	$is_ads = 0;
	echo "<SCRIPT>\n";
	echo "NewImg = new Array (\n";

	if(sizeof($banners)){
		for($i = 1; $i<=sizeof($banners) ; $i++){
			if(($banners[$i]['mod'] == $module_name) and ($banners[$i]['goto'] == "" ||  $banners[$i]['goto'] == $go) and file_exists($banner_folder.$banners[$i]['img'])){
				$is_ads++;
				if($is_ads > 1) echo ",\n";
				$name = $banners[$i]['name'];
				$img = $banners[$i]['img'];
				$url = $banners[$i]['url'];
				$ext = substr($img,strlen($img)-3);

				$item[$is_ads] = "\"<a href='$url' target='_blank'>";
				if($ext == 'swf'){
					$item[$is_ads] .= "<embed name='flash'  src='$banner_folder$img' quality='high' bgcolor='#96BCE3'";
					$item[$is_ads] .= "    width='468' height='60' ";
					$item[$is_ads] .= "    type='application/x-shockwave-flash'";
					$item[$is_ads] .= "    pluginspage='http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash'>";
					$item[$is_ads] .= "</embed>";
				}else $item[$is_ads] .= "<img src='$banner_folder$img' border='0' alt='$name' >";
				$item[$is_ads] .= "</a>\"";
				echo $item[$is_ads];
			}
		}
	}	
	if(!$is_ads) {
		$item[1] .= "\"<img src='images/sttm_02.gif' border='0' alt='Dành cho quảng cáo' >\"";		
		echo "\"<img src='images/sttm_02.gif' border='0' alt='Dành cho quảng cáo' >\"";
	}
	$first_item = str_replace("\"", "", $item[1]);
	echo "\n);\n";
	echo "var ImgNum = 0;\n";
	echo "var ImgLength = NewImg.length - 1;\n";
	echo "\n";
	echo "var delay = $slide_delay;\n";
	echo "\n";
	echo "var lock = false;\n";
	echo "var run;\n";
	echo "\n";
	echo "function chgImg(direction) {\n";
	echo "		ImgNum = ImgNum + direction;\n";
	echo "		if (ImgNum > ImgLength) ImgNum = 0;\n";
	echo "		if (ImgNum < 0) ImgNum = ImgLength;\n";
	echo "		slideshow1 = document.getElementById(\"slideshow\");\n";
	echo "		slideshow1.innerHTML = NewImg[ImgNum];\n";
	echo "}\n";
	echo "\n";
	echo "function auto() {\n";
	echo "	if (lock == true) {\n";
	echo "		lock = false;\n";
	echo "		window.clearInterval(run);\n";
	echo "	}else if (lock == false) {\n";
	echo "		lock = true;\n";
	echo "		run = setInterval(\"chgImg(1)\", delay);\n";
	echo "	}\n";
	echo "}\n";
	echo "\n";
	echo "auto()\n";

	echo "</SCRIPT>\n";
	echo "<div id=\"slideshow\">$first_item</div>";
}

?>