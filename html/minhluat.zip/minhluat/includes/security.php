<?php
/***********************************************************************/
/*                                                                     */
/*   Copyright (C) 2008-2010  My Tran company.                         */
/*   Author     : rocachi - Do Van Chien - rocachien@yahoo.com.        */
/*   Powered By : My Tran company.                                     */
/*                                                                     */
/*   Created    : 19-03-2008 22:32:05.                                 */
/*   Modified   : 19-03-2008 17:27:22.                                 */
/*   Description: admin, trang quan ly tin tuc.                        */
/*                                                                     */  
/***********************************************************************/
if ((!defined('ATN_SYSTEM')) AND (!defined('ATN_ADMIN'))) { die('Stop!!!'); }
if(!defined('ATN_MAINFILE')) { die('Stop!!!'); }

$phpver = phpversion();
if (phpversion() < "4.1.0") {
	$_GET = $HTTP_GET_VARS;
	$_POST = $HTTP_POST_VARS;
	$_SERVER = $HTTP_SERVER_VARS;
	$_FILES = $HTTP_POST_FILES;
	$_ENV = $HTTP_ENV_VARS;
	if($_SERVER['REQUEST_METHOD'] == "POST") {
		$_REQUEST = $_POST;
	} elseif($_SERVER['REQUEST_METHOD'] == "GET") {
		$_REQUEST = $_GET;
	}
	if(isset($HTTP_COOKIE_VARS)) {
		$_COOKIE = $HTTP_COOKIE_VARS;
	}
	if(isset($HTTP_SESSION_VARS)) {
		$_SESSION = $HTTP_SESSION_VARS;
	}
}

if($phpver >= '4.1.0') {
	$HTTP_GET_VARS = $_GET;
	$HTTP_POST_VARS = $_POST;
	$HTTP_SERVER_VARS = $_SERVER;
	$HTTP_POST_FILES = $_FILES;
	$HTTP_ENV_VARS = $_ENV;
	$PHP_SELF = $_SERVER['PHP_SELF'];
	if(isset($_SESSION)) {
	$HTTP_SESSION_VARS = $_SESSION;
	}
	if(isset($_COOKIE)) {
		$HTTP_COOKIE_VARS= $_COOKIE;
	}
}

if (stristr($_SERVER['SCRIPT_NAME'], "mainfile.php") || stristr(htmlentities($_SERVER['PHP_SELF']), "mainfile.php")) { die(); }
if ($_SERVER['HTTP_USER_AGENT'] == "" || $_SERVER['HTTP_USER_AGENT'] == "-") { exit; }

if (!function_exists("floatval")) {
	function floatval($inputval) {
		return (float)$inputval;
	}
}

unset($matches);
unset($loc);
if(isset($_SERVER['QUERY_STRING'])) {
	if (preg_match("/([OdWo5NIbpuU4V2iJT0n]{5}) /", rawurldecode($loc=$_SERVER['QUERY_STRING']), $matches)) {
	die("".error("Illegal Operation")."");
  }
}

if(!function_exists('stripos')) {
  function stripos_clone($haystack, $needle, $offset=0) {
    $return = strpos(strtoupper($haystack), strtoupper($needle), $offset);
  if ($return === false) {
    return false;
    } else {
    return true;
    }
  }
} else {
  function stripos_clone($haystack, $needle, $offset=0) {
    $return = stripos($haystack, $needle, $offset=0);
  if ($return === false) {
    return false;
    } else {
    return true;
    }
  }
}

if(isset($_SERVER['QUERY_STRING']) && (!stripos_clone($_SERVER['QUERY_STRING'], "ad_click") || !stripos_clone($_SERVER['QUERY_STRING'], "url"))) {
    $queryString = $_SERVER['QUERY_STRING'];
    if (stripos_clone($queryString,'%20union%20') OR stripos_clone($queryString,'/*') OR stripos_clone($queryString,'*/union/*') OR stripos_clone($queryString,'c2nyaxb0') OR stripos_clone($queryString,'+union+') OR stripos_clone($queryString,'http://') OR (stripos_clone($queryString,'cmd=') AND !stripos_clone($queryString,'&cmd')) OR (stripos_clone($queryString,'exec') AND !stripos_clone($queryString,'execu')) OR stripos_clone($queryString,'concat')) {
      die('Illegal Operation');
    }
}

$postString = "";
foreach ($_POST as $postkey => $postvalue) {
   if ($postString > "") {
    $postString .= "&".$postkey."=".$postvalue;
   } else {
    $postString .= $postkey."=".$postvalue;
   }
}
str_replace("%09", "%20", $postString);
$postString_64 = base64_decode($postString);
if (stristr($postString,'%20union%20') OR stristr($postString,'*/union/*') OR stristr($postString,' union ') OR stristr($postString_64,'%20union%20') OR stristr($postString_64,'*/union/*') OR stristr($postString_64,' union ')) {
header("Location: index.php");
die();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	foreach ($_POST as $FormFieldName => $FormFieldValue) {
	if (gettype($FormFieldValue) == 'array') {
		$iCount = count($_POST[$FormFieldName]);
		for ($i=0;$i < $iCount;$i++) 	{
			$FormFieldValue = $_POST[$FormFieldName][$i];
			$sTemp .= "name=\"" . $FormFieldName . "[$i]\" value=\"$FormFieldValue\"\r\n";
		}
	} else {$sTemp .= "name=\"$FormFieldName\" value=\"$FormFieldValue\"\r\n"; }
	$sTemp = urldecode($sTemp);
	}
}
if($_SERVER["REQUEST_METHOD"] == "POST" && (preg_match("/mod_authors/", $sTemp) || preg_match("/displayadmins/", $sTemp) || preg_match("/updateadmin/", $sTemp) || preg_match("/modifyadmin/", $sTemp) || preg_match("/deladmin/", $sTemp) || preg_match("/deladmin2/", $sTemp))) {
	die("".error("Illegal Operation")."");
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
	if (isset($_SERVER['HTTP_REFERER'])) {
		if (!stripos_clone($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST'])) {
			die("".error("Posting from another server not allowed!")."");
		}
	} else {
		die("".error("<b>Warning:</b> your browser doesn't send the HTTP_REFERER header to the website.<br>This can be caused due to your browser, using a proxy server or your firewall.<br>Please change browser or turn off the use of a proxy<br>or turn off the 'Deny servers to trace web browsing' in your firewall and you shouldn't have problems when sending a POST on this website.")."");
	}
}

$htmlerr = "Error in Html";//"<center><img src=\"".INCLUDE_PATH."images/logo.gif\"><br><br><b>";
$htmlerr .= " - The html tags you attempted to use are not allowed</b><br><br>";
$htmlerr .= " [ <a href=\"javascript:history.go(-1)\"><b>Go Back</b></a> ]</center>";
$filerr = //"<center><img src=\"".INCLUDE_PATH."images/logo.gif\"><br><br><b>";
$filerr .= "Forbidden File detected </b><br><br>";
$filerr .= "[ <a href=\"javascript:history.go(-1)\"><b>Go Back</b></a> ]</center>";

foreach ($_GET as $var_name => $var_value) {
	if($security_tags!="") {
		if (preg_match("/<.*?(".$security_tags.").*?>/", urldecode($var_value)) || preg_match("/\([^>]*\"?[^)]*\)/", $var_value) || preg_match("/\"/", $var_value)) {
			die ($htmlerr);
		}
	}
	if($security_url_get==1) {
	if (preg_match("/^(http\:\/\/|ftp\:\/\/|\/\/|https:\/\/|php:\/\/|\/\/)/i", $var_value)) die ("Warning: Url is not allowed ");// - ".$var_name." = ". $var_value);
	}
	if($security_union_get==1) {
	$security_string = "/UNION|OUTFILE|SELECT|ALTER|INSERT|DROP|FROM|WHERE|UPDATE|".$prefix."_authors|".$prefix."_users|UpdateAuthor|AddAuthor|mod_authors|modifyadmin|deladmin|deladmin2/i";
	$security_decode = base64_decode($var_value);
	if (preg_match($security_string, $security_decode)) die ("Warning, bad attempting found while getting");// base64 in url ");//- ".$var_name." = ". $var_value."");
	if (preg_match($security_string, $var_value)) die ("Warning, sensitive keywords detected while getting data.");//- ".$var_name." = ". $var_value."");
	$security_slash = preg_replace("/\/\*.*?\*\//", "", $var_value);
	if (preg_match($security_string, $security_slash)) die ("Warning, sensitive keywords detected while getting data.");//die ("Hack in GET ");//- ".$var_name." = ". $var_value."");
	}
}
foreach ($_POST as $var_name => $var_value) {
	if($security_tags!="") {
		if (preg_match("/<.*?(".$security_tags.").*?>/", urldecode($var_value))) die ($htmlerr);
		}
	if($security_url_post==1) {
	if (preg_match("/^(http\:\/\/|ftp\:\/\/|\/\/|https:\/\/|php:\/\/|\/\/)/i", $var_value)) die ("URL in POST - ".$var_name." = ". $var_value);
	}
	if($security_union_post==1) {
	$security_string = "/UNION|OUTFILE|SELECT|ALTER|INSERT|DROP|FROM|WHERE|UPDATE|".$prefix."_authors|".$prefix."_users|UpdateAuthor|AddAuthor|mod_authors|modifyadmin|deladmin|deladmin2/i";
	$security_decode = base64_decode($var_value);

	if (preg_match($security_string, $security_decode)) die ("Warning, bad attempting found while posting");// base64 in url ");//- ".$var_name." = ". $var_value."");
	//echo "<br>-->" . 	$security_string ."<br>".$var_value;	
	if (preg_match($security_string, $var_value)) die ("Warning: sensitive keywords detected while postting data. ");//- ".$var_name." = ". $var_value."");
	//$security_slash = preg_replace("/\/\*.*?\*\//", "", $var_value);
	//if (preg_match($security_string, $security_slash)) die ("Warning, sensitive keywords detected while postting data.");//- ".$var_name." = ". $var_value."");
	}
}

foreach ($_SESSION as $var_name => $var_value) {
	if (preg_match("/<.*?(script|object|iframe|applet|meta|style|form|img|onmouseover|body).*?>/", $var_value)) die ($htmlerr);
	if (preg_match("/^(http\:\/\/|ftp\:\/\/|\/\/|https:\/\/|php:\/\/|\/\/)/i", $var_value)) {
		session_destroy();
		die ("Hacking attempt via session ");
	}//- ".$var_name." = ". $var_value);
	$security_string = "/UNION|OUTFILE|SELECT|ALTER|INSERT|DROP|FROM|WHERE|UPDATE|".$prefix."_authors|".$prefix."_users|UpdateAuthor|AddAuthor|mod_authors|modifyadmin|deladmin|deladmin2/i";
	$security_decode = base64_decode($var_value);
	if (preg_match($security_string, $security_decode)) {
		session_destroy();
		die ("Warning, Hacking attempt via session ");//die("Hack base64 in SESSION ");//- ".$var_name." = ". $var_value."");
	}
	if (preg_match($security_string, $var_value)){
		session_destroy();
		die ("Warning, Hacking attempt via session ");//die ("Hack in SESSION ");//- ".$var_name." = ". $var_value."");
	}
	$security_slash = preg_replace("/\/\*.*?\*\//", "", $var_value);
	if (preg_match($security_string, $security_slash)) {
		session_destroy();
		die ("Warning, Hacking attempt via session ");
	}//die ("Hack in SESSION ");//- ".$var_name." = ". $var_value."");
}

$security_files = "php|php3|php4|pl|phtml|html|htm|asp|cgi";
foreach ($_FILES as $var_name => $var_value) {
	$var_value = end(explode(".", $_FILES['userfile']['name']));
	if (preg_match("/".$security_files."/", $var_value)) {
		die($filerr);
	}
}

reset($_GET);
reset($_POST);
reset($_SESSION);
reset($_FILES);//END

?>