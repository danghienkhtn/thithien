<?php
include_once("md5Class.php");
class sessionClass extends md5Class {
	//variable member		
	var $md5 ;	
	var $expried = 0 ;
	var $path= "/" ;
	var $secure = 0 ;	
		
	//construct and destruct
	
	//FOR PHP4
	function  sessionClass() {
		sessionClass::__construct();
	}
	
	//FOR PHP5	
	function __construct() {		
		if(!isset($this->expried)) {
			$this->expried = 0 ;	
		}
		
		if(!isset($this->path)) {
			$this->path = "/" ;	
		}		
		
		if(!isset($this->secure)) {
			$this->secure = 0 ;	
		}
		
		parent::__construct() ;
	}
	
	function __destruct() {				
		if(isset($this->expried)) {
			unset($this->expried) ;
		}
		
		if(isset($this->path)) {
			unset($this->path) ;
		}
				
		if(isset($this->secure)) {
			unset($this->secure) ;
		}
		
		parent::__destruct() ;
	}
	
	function __toString() {
		return get_class(__CLASS__) ;
	}	
	
	function __wakeup()
	{
  		$class = get_class($this);
  		new $class;
	}
		
	//create a session key security
	 function setSessionKey($name,$value) {	
		$name = $this->encodeStatic($name) ;
		$name = substr($name,0,-2) ;		
		$value = $this->encodeStatic($value) ;
		//remove old session
		if(isset($_SESSION[$name])) {
			unset($_SESSION[$name]) ;
		}
		//set a new session
		$_SESSION[$name] = $value ;
	}
	
	//create a cookie key security
	 function setCookieKey($name,$value) {		
		$name = $this->encodeStatic($name) ;	
		$name = substr($name,0,-2) ;	
		$value = $this->encodeStatic($value) ;
		$isOK = false ;
		//remove old cookie
		if(isset($_COOKIE[$name])) {
			$this->delKey($name);			
		}
		//set a new cookie				
		//if(setcookie($name,$value,$this->expried,"/","toursvietnam.vn",0)) {	
		if(setcookie($name,$value,$this->expried)) {	
			$isOK = true ;			
		}
		return $isOK ;
	}
	
	//set session key
	 function setKey($name,$value) {				
		if($this->setCookieKey($name,$value)===false) {			
			$this->setSessionKey($name,$value) ;
		}
	}
	
	//get session key
	 function getKey($name) {	
		$name = $this->encodeStatic($name) ;
		$name = substr($name,0,-2) ;		
		$value = "" ;
		if(isset($_COOKIE[$name])) {
			$value = $_COOKIE[$name] ;	
			$value = $this->decode($value) ;		
		}
		else {
			if(isset($_SESSION[$name])) {
				$value = $_SESSION[$name] ;	
				$value = $this->decode($value) ;		
			}
		}		
		return $value ;
	}
	
	//del session key
	 function delKey($name) {	
		$name = $this->encodeStatic($name) ;	
		$name = substr($name,0,-2) ;			
		if(isset($_COOKIE[$name])) {			
			//setcookie($name,"",mktime(12,0,0,1,1,1990),"/","toursvietnam.vn",0);				
			setcookie($name,"",mktime(12,0,0,1,1,1990));				
		}
		elseif(isset($_SESSION[$name])) {
			unset($_SESSION[$name]) ;			
		}
	}	
}
?>