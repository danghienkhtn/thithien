<?php
/***********************************************************************/
/*                                                                     */
/*   Copyright (C) 2008-2010  My Tran company.                         */
/*   Author     : rocachi - Do Van Chien - rocachien@yahoo.com.        */
/*   Powered By : My Tran company.                                     */
/*                                                                     */
/*   Created    : 20-03-2008 22:32:05.                                 */
/*   Modified   : 20-03-2008 17:27:22.                                 */
/*   Description: session.calss.php, session class.                    */
/*                                                                     */  
/***********************************************************************/
global $session_limit,$session_by;
$session_limit = 5000;
$session_by = "auto";//ses//auto//data
$_SESSION['sys']=true;
class sessionClass extends md5Class{
	//session
	var $sid;
	var $sname;
	var $svalue;
	var $sbegin;
	
	//FOR PHP4
	function  sessionClass() {
		sessionClass::__construct();
	}
	//FOR PHP5	
	function __construct() {		
		if(empty($this->sid)) {
			$this->sid = session_id();	
		}
		parent::__construct() ;
	}
	function __destruct() {				
		if(isset($this->sid)) {
			unset($this->sid);
		}
		if(isset($this->sname)) {
			unset($this->sname);
		}
		if(isset($this->svalue)) {
			unset($this->svalue);
		}
		if(isset($this->sbegin)) {
			unset($this->sbegin);
		}		
		parent::__destruct();
	}
	function __toString() {
		return get_class(__CLASS__) ;
	}	
	function __wakeup(){
  		$class = get_class($this);
  		new $class;
	}
		
	//create a session key security
	
	function getKey($name) {
		global $session_limit,$session_by;
		$this->sname = $name;
		switch($session_by){
			case "data": {return $this->getSessionKeyFromData(); break;}
			case "ses": {return $this->getSessionKeyFromSession(); break;}
			default : {
				if(empty($_SESSION['sys']))
					return $this->getSessionKeyFromData();
				else
					return $this->getSessionKeyFromSession();
			}
		}
	}
	//get session key
	function getSessionKeyFromSession() {
		$value = $_SESSION[$this->sname] ;	
		$value = $this->decode($value) ;
		return $value;
	}
	function getSessionKeyFromData() {
		global $db;
		$id = $this->sid;
		$name = $this->encodeStatic($this->sname);
		$value = "" ;
		$sql="SELECT ss_value FROM sys_session WHERE ss_id='$id' AND ss_name='$name'";
		$resulttt = $db->sql_query($sql);
		list($value) = $db->sql_fetchrow($resulttt);
		$value = $this->decode($value) ;			
		return $value ;
	}
	//set session key
	function setKey($name,$value) {
		global $session_limit,$session_by;
		$this->sname = $name;
		$this->svalue = $value;
		switch($session_by){
			case "data": {$err=$this->setSessionKeyToData(); break;}
			case "ses": {$err=$this->setSessionKeyToSession(); break;}
			default : {
				if(empty($_SESSION['sys']))
					$err=$this->setSessionKeyToData();
				else
					$err=$this->setSessionKeyToSession();
			}
		}
		
		return $err;
	}
	function setSessionKeyToSession () {
		$svalue = $this->encodeStatic($this->svalue);
		$_SESSION[$this->sname]=$svalue;
		return $_SESSION[$this->sname];
	}
	function setSessionKeyToData () {
		global $session_limit,$db;
		$id = $this->sid;
		$name = $this->encodeStatic($this->sname);
		$svalue = $this->encodeStatic($this->svalue);
		$sql="SELECT ss_begin FROM sys_session WHERE ss_id='$id' AND ss_name='$name'";
		$resulttt = $db->sql_query($sql);
		list($begin) = $db->sql_fetchrow($resulttt);
		$time=time();
		if (empty($begin)) {
			$sql  =  "INSERT INTO sys_session (ss_id, ss_name, ss_value, ss_begin) "
					."VALUES ('$id', '$name', '$svalue', '$time')";			
		}else{
			$sql  =  "UPDATE sys_session SET ss_begin= '". $time
					."', ss_value='".$svalue."' WHERE ss_id='$id' AND ss_name='$name'";	
		}
		$err=($db->sql_query($sql))? true : false;
		//Xoa session cu
		$sql="DELETE FROM sys_session WHERE (`ss_begin` + $session_limit < $time)";
		$err=($db->sql_query($sql))? true : false;
		return $err;
	}
	//del session
	function delKey($name){
		global $db,$session_limit,$session_by;
		$this->sname = $name;
		$this->svalue = $value;
		$id = $this->sid;
		$name = $this->encodeStatic($this->sname);
		switch($session_by){
			case "data": {
				$sql="DELETE FROM sys_session WHERE ss_id='$id' AND ss_name='$name'";
				$err=($db->sql_query($sql))? true : false;
			}
			case "ses": {
				unset($_SESSION[$this->sname]);
			}
			default : {
				if(empty($_SESSION['sys'])){					
					$sql="DELETE FROM sys_session WHERE ss_id='$id' AND ss_name='$name'";
					$err=($db->sql_query($sql))? true : false;
				}else
					unset($_SESSION[$this->sname]);
			}
		}
		return $err;
	}
	
	function checkSID(){
		global $db;
		$id = $this->sid;
		$sql="SELECT DISTINCT ss_id FROM sys_session WHERE ss_id='$id'";
		$resulttt = $db->sql_query($sql);
		$err=($db->sql_numrows($resulttt))? true : false;
		return $err;
	}
	function setOnline() {
		global $session_limit,$db;
		$id = $this->sid;
		$name="online";
		$time = time();
		//ranh gioi xoa
		$tmupd = $time - $session_limit;
		//ranh gioi update
		$tmdel = $time - 2 * $session_limit;
		$tm=(int)$this->getKey("Timeonline");
		if($tm < 1){
			$this->setKey("Timeonline",$time);			
			//insert
			$sql  =  "INSERT INTO sys_session (ss_id, ss_name, ss_value, ss_begin) "
				."VALUES ('$id', '$name', '$name', '$time')";
		}elseif($tm < $tmdel){			
			//Xoa nhung cai qua han
			$sql  =  "DELETE FROM sys_session WHERE ss_id='".$id."' AND ss_name='online'";			
		}elseif($tm < $tmupd){
			//update lai thoi gian
			$sql  =  "UPDATE sys_session SET ss_begin= '". $time
				."', ss_value='".$svalue."' WHERE ss_id='$id' AND ss_name='$name'";
		}else
			return true;
		$db->sql_query($sql);		
	}
	function getOnline() {
		global $session_limit,$db;
		$timenow = time();
		//tu ss limit toi hien tai
		$tmp = $timenow - $session_limit;
		$sql  = "SELECT DISTINCT ss_id FROM sys_session WHERE ss_name='online' AND ss_begin >= $tmp";
		$resulttt = $db->sql_query($sql);
		$n = $db->sql_numrows($resulttt);
		return $n;
	}
	function getVisitor() {
		global $session_limit,$db;
		$time = time();
		$tmupd = $time - $session_limit;
		$tm=(int)$this->getKey("Timeonline");
		$vst=(int)$this->getKey("ssVisitor");
		if($vst < 1){
			//update so visitor
			$sql  =  "UPDATE sys_global SET glb_value= glb_value + 1 WHERE glb_name='visitor'";
			$db->sql_query($sql);
			$sql="SELECT glb_value FROM sys_global WHERE glb_name='visitor'";
			$res = $db->sql_query($sql);
			list($vst) = $db->sql_fetchrow($res);
			$this->setKey("ssVisitor",$vst);
		}elseif($vst < $tmupd){
			//Lay so visitor cho vao session
			$sql="SELECT glb_value FROM sys_global WHERE glb_name='visitor'";
			$res = $db->sql_query($sql);
			list($vst) = $db->sql_fetchrow($res);
			$this->setKey("ssVisitor",$vst);
		}
		return $vst;		
	}
};
$session =& new sessionClass();
?>