<?php

// File: sanphammoi.php
// Created: 01-12-2009 18:17:11.
// Do not change anything in this file!

if (!defined('ATN_ADMIN')) {
die('Stop!!!');
}

$sanphammoi[0]['sp_id'] = '107';
$sanphammoi[0]['sp_ma'] = 'RETR001';
$sanphammoi[0]['sp_hinh'] = 'compiler/upload/products/93/1259666110.jpg';
$sanphammoi[0]['sp_ten'] = 'Retrack system';
$sanphammoi[0]['sp_giaban'] = '12.0';
$sanphammoi[0]['sp_giacu'] = '-1.0';
$sanphammoi[0]['sp_donvi'] = '2';
$sanphammoi[0]['sp_loai_id'] = '93';
$sanphammoi[1]['sp_id'] = '105';
$sanphammoi[1]['sp_ma'] = 'SERTPRO01';
$sanphammoi[1]['sp_hinh'] = 'compiler/upload/products/80/1259657201.jpg';
$sanphammoi[1]['sp_ten'] = 'Tower Pro 09MG';
$sanphammoi[1]['sp_giaban'] = '10.0';
$sanphammoi[1]['sp_giacu'] = '-1.0';
$sanphammoi[1]['sp_donvi'] = '0';
$sanphammoi[1]['sp_loai_id'] = '80';
$sanphammoi[2]['sp_id'] = '103';
$sanphammoi[2]['sp_ma'] = 'ESCHIMO01';
$sanphammoi[2]['sp_hinh'] = 'compiler/upload/products/51/1259646466.jpg';
$sanphammoi[2]['sp_ten'] = 'ESC 12A';
$sanphammoi[2]['sp_giaban'] = '14.0';
$sanphammoi[2]['sp_giacu'] = '-1.0';
$sanphammoi[2]['sp_donvi'] = '0';
$sanphammoi[2]['sp_loai_id'] = '51';
$sanphammoi[3]['sp_id'] = '102';
$sanphammoi[3]['sp_ma'] = 'ESCHIMO04';
$sanphammoi[3]['sp_hinh'] = 'compiler/upload/products/51/1259646091.jpg';
$sanphammoi[3]['sp_ten'] = 'ESC Profestional 10A';
$sanphammoi[3]['sp_giaban'] = '14.5';
$sanphammoi[3]['sp_giacu'] = '-1.0';
$sanphammoi[3]['sp_donvi'] = '0';
$sanphammoi[3]['sp_loai_id'] = '51';
$sanphammoi[4]['sp_id'] = '100';
$sanphammoi[4]['sp_ma'] = 'ESCHWIN01';
$sanphammoi[4]['sp_hinh'] = 'compiler/upload/products/44/1259644776.jpg';
$sanphammoi[4]['sp_ten'] = 'ESC FY 30A';
$sanphammoi[4]['sp_giaban'] = '28.0';
$sanphammoi[4]['sp_giacu'] = '-1.0';
$sanphammoi[4]['sp_donvi'] = '0';
$sanphammoi[4]['sp_loai_id'] = '44';

?>