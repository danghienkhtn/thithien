<?php

// File: sanphamflash.php
// Created: 01-12-2009 14:45:45.
// Do not change anything in this file!

if (!defined('ATN_ADMIN')) {
die('Stop!!!');
}

$sanphamflash['sp_id'] = '1';
$sanphamflash['sp_ma'] = 'TOOTAOB01';
$sanphamflash['sp_hinh'] = 'compiler/upload/products_flash/1259652705.jpg';
$sanphamflash['sp_ten'] = 'Cân Điện tử 7kg/0,1g';
$sanphamflash['sp_giaban'] = '20';
$sanphamflash['sp_giacu'] = '30';
$sanphamflash['sp_donvi'] = '0';
$sanphamflash['sp_mota'] = '<p><span style="font-size: xx-large"><span style="font-family: Comic Sans MS"><b>&#160;</b><span style="color: #ff0000"><b>Super Sale 30% </b></span></span></span></p>
<p><span style="font-size: xx-large"><span style="font-family: Comic Sans MS"><span style="color: #ff0000"><b>on Openning Day</b></span></span></span></p>
<p>●Equipped with a high precision strain gauge sensor system<br />
●Auto power off function<br />
●LCD display<br />
●Auto zero resetting <br />
●Mode function: g/oz<br />
●Over-load/Low battery indicator<br />
Model number: SF-400 7kg Version<br />
Capacity: 7000g<br />
Division: 1g<br />
Weighing modes: gram, oz<br />
Dimension: 24 x 17 x 3.6 cm<br />
Platter diameter: 14.8 cm <br />
Net weight:442g / 15.6 oz ( with battery )<br />
Power Source:2 x AA size Batteries (battery not included)</p>';
$sanphamflash['sp_soluong'] = '5';
$sanphamflash['sp_khuyenmai'] = '1';

?>