<?php

// File: sanphamquangcaotrai.php
// Created: 01-12-2009 17:31:58.
// Do not change anything in this file!

if (!defined('ATN_ADMIN')) {
die('Stop!!!');
}

$sanphamquangcaotrai[0]['sp_id'] = '42';
$sanphamquangcaotrai[0]['sp_ma'] = 'KITTAOB15';
$sanphamquangcaotrai[0]['sp_hinh'] = 'compiler/upload/products/59/1259391168.jpg';
$sanphamquangcaotrai[0]['sp_ten'] = 'Kit EPO - F4U - Corsaire';
$sanphamquangcaotrai[0]['sp_giaban'] = '92.0';
$sanphamquangcaotrai[0]['sp_giacu'] = '-1.0';
$sanphamquangcaotrai[0]['sp_donvi'] = '0';
$sanphamquangcaotrai[0]['sp_loai_id'] = '59';
$sanphamquangcaotrai[1]['sp_id'] = '41';
$sanphamquangcaotrai[1]['sp_ma'] = 'KITTAOB05';
$sanphamquangcaotrai[1]['sp_hinh'] = 'compiler/upload/products/61/1259384129.jpg';
$sanphamquangcaotrai[1]['sp_ten'] = 'F 16 Fancol EDF 64mm';
$sanphamquangcaotrai[1]['sp_giaban'] = '102.0';
$sanphamquangcaotrai[1]['sp_giacu'] = '-1.0';
$sanphamquangcaotrai[1]['sp_donvi'] = '0';
$sanphamquangcaotrai[1]['sp_loai_id'] = '61';
$sanphamquangcaotrai[2]['sp_id'] = '38';
$sanphamquangcaotrai[2]['sp_ma'] = 'MTOTURG05';
$sanphamquangcaotrai[2]['sp_hinh'] = 'compiler/upload/products/87/1259381933.jpg';
$sanphamquangcaotrai[2]['sp_ten'] = 'Turnigy 2830 - 1100 KV';
$sanphamquangcaotrai[2]['sp_giaban'] = '14.5';
$sanphamquangcaotrai[2]['sp_giacu'] = '-1.0';
$sanphamquangcaotrai[2]['sp_donvi'] = '0';
$sanphamquangcaotrai[2]['sp_loai_id'] = '87';

?>