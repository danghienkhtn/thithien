<?php

// File: binhchonchung.php
// Created: 01-12-2009 12:55:22.
// Do not change anything in this file!

if (!defined('ATN_ADMIN')) {
die('Stop!!!');
}

$binhchonchung['bbc_chude'] = 'Khi mua một sản phẩm, Yếu tố nào khiến bạn quyết định mua sản phấm?';
$binhchonchung['bbc_luachon1'] = 'Chất lượng,';
$binhchonchung['bbc_luachon2'] = 'Giá thành';
$binhchonchung['bbc_luachon3'] = 'Nơi bán uy tính';
$binhchonchung['bbc_luachon4'] = 'Những yếu tố khách quan khác';
$binhchonchung['bbc_tinhtrang'] = '1';
$binhchonchung['bbc_solan1'] = '1';
$binhchonchung['bbc_solan2'] = '10';
$binhchonchung['bbc_solan3'] = '0';
$binhchonchung['bbc_solan4'] = '1';
$binhchonchung['bbc_tongsolan'] = '12';

?>