<?php

// File: sanphamtop.php
// Created: 01-12-2009 18:17:11.
// Do not change anything in this file!

if (!defined('ATN_ADMIN')) {
die('Stop!!!');
}

$sanphamtop[0]['sp_id'] = '79';
$sanphamtop[0]['sp_ma'] = 'PROEP003';
$sanphamtop[0]['sp_hinh'] = 'compiler/upload/products/97/1259561912.jpg';
$sanphamtop[0]['sp_ten'] = 'EP 10 x 8';
$sanphamtop[0]['sp_giaban'] = '1.2';
$sanphamtop[0]['sp_giacu'] = '-1.0';
$sanphamtop[0]['sp_donvi'] = '0';
$sanphamtop[0]['sp_loai_id'] = '97';
$sanphamtop[1]['sp_id'] = '104';
$sanphamtop[1]['sp_ma'] = 'SERTPRO02';
$sanphamtop[1]['sp_hinh'] = 'compiler/upload/products/80/1259656947.jpg';
$sanphamtop[1]['sp_ten'] = 'Tower Pro 90';
$sanphamtop[1]['sp_giaban'] = '3.7';
$sanphamtop[1]['sp_giacu'] = '-1.0';
$sanphamtop[1]['sp_donvi'] = '0';
$sanphamtop[1]['sp_loai_id'] = '80';
$sanphamtop[2]['sp_id'] = '44';
$sanphamtop[2]['sp_ma'] = 'CHAHOTA01';
$sanphamtop[2]['sp_hinh'] = 'compiler/upload/products/30/1259424708.jpg';
$sanphamtop[2]['sp_ten'] = 'GE POWER B6';
$sanphamtop[2]['sp_giaban'] = '52.5';
$sanphamtop[2]['sp_giacu'] = '-1.0';
$sanphamtop[2]['sp_donvi'] = '0';
$sanphamtop[2]['sp_loai_id'] = '30';
$sanphamtop[3]['sp_id'] = '54';
$sanphamtop[3]['sp_ma'] = 'ESCHIMO10';
$sanphamtop[3]['sp_hinh'] = 'compiler/upload/products/35/1259499245.jpg';
$sanphamtop[3]['sp_ten'] = 'ESC HIMODEL GX 30A';
$sanphamtop[3]['sp_giaban'] = '16.6';
$sanphamtop[3]['sp_giacu'] = '-1.0';
$sanphamtop[3]['sp_donvi'] = '0';
$sanphamtop[3]['sp_loai_id'] = '35';
$sanphamtop[4]['sp_id'] = '56';
$sanphamtop[4]['sp_ma'] = 'ESCHIMO08';
$sanphamtop[4]['sp_hinh'] = 'compiler/upload/products/35/1259513843.jpg';
$sanphamtop[4]['sp_ten'] = 'HIMODEL 30A-40A Profestional';
$sanphamtop[4]['sp_giaban'] = '22.0';
$sanphamtop[4]['sp_giacu'] = '-1.0';
$sanphamtop[4]['sp_donvi'] = '0';
$sanphamtop[4]['sp_loai_id'] = '35';
$sanphamtop[5]['sp_id'] = '63';
$sanphamtop[5]['sp_ma'] = 'SPIBLS01';
$sanphamtop[5]['sp_hinh'] = 'compiler/upload/products/95/1259555071.jpg';
$sanphamtop[5]['sp_ten'] = 'Spinner Nhựa 38mm';
$sanphamtop[5]['sp_giaban'] = '25.0';
$sanphamtop[5]['sp_giacu'] = '-1.0';
$sanphamtop[5]['sp_donvi'] = '0';
$sanphamtop[5]['sp_loai_id'] = '95';

?>