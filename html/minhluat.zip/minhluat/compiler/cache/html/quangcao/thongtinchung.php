<?php

// File: thongtinchung.php
// Created: 09-11-2012 09:11:23.
// Do not change anything in this file!

if (!defined('ATN_ADMIN')) {
die('Stop!!!');
}

$thongtinchung['tencongty'] = 'Công ty Tư Vấn Minh Luật';
$thongtinchung['diachi'] = '221/41/1G Vườn Lài, phường Phú Thọ Hòa, quận Tân Phú, TPHCM';
$thongtinchung['dienthoai'] = '08.38123032';
$thongtinchung['didong'] = '0983886769';
$thongtinchung['fax'] = '08.38123032 - Tổng đài 19006236';
$thongtinchung['nick'] = 'quoctoan189';
$thongtinchung['email'] = 'quoctoan189@yahoo.com';
$thongtinchung['gioithieu'] = '<p style=\"text-align: justify; \"><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \"><a href=\"http://minhluat.net/dev/lien-he.html\"><span style=\"color: rgb(255, 0, 0); \">Công ty Tư Vấn Minh Luật</span></a> được thành lập với:<br />
<br />
<b>Phương châm</b> mang đến cho khách hàng “<b>hiệu quả cao, lợi ích lớn</b>”.<br />
<br />
Giá trị: Với nhóm luật sư, luật gia giàu kinh nghiệm, có tư duy mới, chuyên nghiệp, nhiệt tình,&#160;đam mê và có tâm huyết với nghề… là những yếu tố cơ bản để tạo nên một giá trị lớn –&#160;<b>Giá trị Minh Luật</b><br />
<br />
</span></span><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">Công  ty Tư Vấn Minh Luật luôn mang đến cho khách hàng những dịch vụ, giúp  khách&#160;hàng cởi bỏ những khó khăn tài chính, tránh rủi ro pháp lý trong  hoạt động kinh doanh&#160;mở ra một sự <b>hợp tác vững bền</b>.</span></span></p>
<p style=\"text-align: justify; \"><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">Quan điểm của chúng tôi là có thể chưa thành công trong vụ đơn lẻ, nhưng tuyệt đối&#160;không dối trá, làm việc tận tâm, không đánh mất lương tâm để trục lợi và nghiêm túc tuân&#160;thủ pháp luật.&#160;Thế nên, tầm vóc của Minh Luật sẽ lớn mạnh không chỉ đơn thuần là những thành công,&#160;mà quan trọng hơn, chính là khả năng trưởng thành vượt bậc từ thất bại và bước qua&#160;thách thức để mang lại cho khách hàng một dịch vụ ngày càng hoàn hảo.<br />
<br />
Trân trọng kính chào</span></span></p>';
$thongtinchung['dichvu'] = '<p style=\"text-align: justify;\"><b><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">Phương châm</span></span></b><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \"> mang đến cho khách hàng “<b>hiệu quả cao, lợi ích lớn</b>”.</span></span></p>
<p style=\"text-align: justify;\"><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \"><a href=\"http://minhluat.net/dev/lien-he.html\">Chúng tôi </a>hiện cung cấp các dịch vụ sau:</span></span></p>
<p style=\"text-align: justify;\"><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">- <b>Tư vấn doanh nghiệp</b>: Dịch vụ tư vấn thành lập doanh nghiệp, thay đổi nội dung kinh doanh,&#160; giải thể doanh nghiệp, thành lập trung tâm ngoại ngữ tin học và bồi dưỡng văn hoá</span></span>, <span style=\"font-size: larger;\"><span style=\"font-family: Arial;\">hồ sơ kế toán, đăng ký logo, nhãn hiệu</span></span></p>
<p style=\"text-align: justify;\"><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">- <b>Tư vấn nhà đất</b>: Hợp thức hoá, xin phép xây dựng, hoàn công xây dựng, tách thửa, chuyển mục đích</span></span></p>
<p style=\"text-align: justify;\"><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">- Tư vấn và hỗ trợ thu hồi nợ khó</span></span></p>
<p style=\"text-align: justify;\"><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">- Tư vấn, hướng dẫn kê khai di sản</span></span></p>
<p style=\"text-align: justify;\"><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">&#160;- Tư vấn pháp luật, đại diện cho khách hàng trong các vụ việc dân sự: C<span style=\"background-color: rgb(249, 250, 252); \">ác quan hệ <b>dân sự, hôn nhân và gia đình, kinh doanh, thương mại, lao động</b>.</span></span></span></p>
<p style=\"text-align: justify;\">---------------------------------------------------------</p>
<p>&#160;<b><i><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">* Khởi nghiệp</span></span></i></b></p>
<p style=\"text-align: justify;\"><i><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">&#160;Khi bạn đã suy nghĩ mình bắt đầu khởi nghiệp từ đâu, sản phẩm nào… bạn tìm hiểu, nghiên cứu và bắt đầu bước vào công việc kinh doanh… Việc trước tiên không thể thiếu, bạn thành lập một doanh nghiệp, xây dựng bộ máy hoạt động, xây dựng hình ảnh thương hiệu… và ngay bây giờ</span></span></i></p>
<p style=\"text-align:justify\"><i><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">Chúng tôi có thể giúp bạn trong bước đường khởi nghiệp. Chúng tôi hỗ trợ bạn trong việc thành lập doanh nghiệp, xây dựng hồ sơ pháp lý, đặc biệt:</span></span></i></p>
<p style=\"text-align:justify\">&#160;<i><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">Xây dựng hình ảnh thương hiệu nhất quán từ tên thương hiệu, logo, slogan, hệ thống nhận diện thương hiệu, chiến dịch quảng cáo truyền thông cho đến thiết kế không gian thương mại, chuỗi showroom bán hàng, văn phòng hay các không gian chức năng phục vụ hiệu quả công việc kinh doanh.</span></span></i></p>
<p><i> <span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">  Hãy “<a href=\"http://minhluat.net/dev/lien-he.html\"><span style=\"color: rgb(255, 0, 0);\">Liên hệ” với chúng tôi </span></a>để được tư vấn chi tiết</span></span></i></p>
<p>&#160;</p>
<p><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">&#160;</span></span></p>
<p><span style=\"font-size: larger; \"><span style=\"font-family: Arial; \">&#160;</span></span></p>';
$thongtinchung['bando'] = 'compiler/upload/bando/1227485566.jpg';

?>