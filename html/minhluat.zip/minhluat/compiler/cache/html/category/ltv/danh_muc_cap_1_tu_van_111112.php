<?php

// File: danh_muc_cap_1_tu_van_111112.php
// Created: 11-11-2012 06:32:56.
// Do not change anything in this file!

if (!defined('ATN_ADMIN')) {
die('Stop!!!');
}

$loaituvan['0'] = array('loaitv_id'=>'1', 'loaitv_ten'=>'Lĩnh vực  Hình Sự', 'loaitv_ghichu'=>'Lĩnh vực liên quan dân sự');
$loaituvan['1'] = array('loaitv_id'=>'2', 'loaitv_ten'=>'Lĩnh vực dân sự', 'loaitv_ghichu'=>'');
$loaituvan['2'] = array('loaitv_id'=>'4', 'loaitv_ten'=>'khác', 'loaitv_ghichu'=>'');

?>